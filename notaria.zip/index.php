<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title id="nombreempresa"></title>
	<link rel="shortcut icon" id="iconoempresa" href="" />

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg skin-2">

    <div class="middle-box text-center loginscreen ">
        <div>
			<div class='m-t' id='inilog'>
				<img class='logo-name' width='100%' id="logoempresa" src=''>
			</div>
			<h3>INGRESO SISTEMA</h3>
			<div class="m-t" role="form" >
                <div class="form-group">
					<input type="text" class="form-control"  id="usr" placeholder="Usuario" required="" />
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" id="pwd" placeholder="Contraseña" required="" />
                </div>
                <button class="btn btn-primary block full-width m-b" onclick="ingresarSistema()"><i class='fa fa-sign-in'></i> Ingresar</button>
                <a class="btn btn-sm btn-white btn-block" href="login"><i class='fa fa-vcard'></i>  Olvide mi contraseña </a>
            </form>
            <p class="m-t"> <small><a href="#"> Derechos Reservados &copy; 2023 </a> </small> </p>
            
        </div>
    </div>
	<footer>
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/empresa.js"></script>
	</footer>
</body>
<script>
    function ingresarSistema(){
        var funcion = "login";
        var usr = document.getElementById("usr").value;
        var pwd = document.getElementById("pwd").value;
        
        var body = {funcion: funcion , usuario: usr, contrasena: pwd};
        Empresa.rest(
        {
            verbo: 'POST',
			url: Empresa.armarUrl("api/usuario/funcionesUsuarios.php"),
			data: body,
            funcionExito: function (respuesta) 
            {
                var sesion = respuesta.sesion;
                var idr = respuesta.idr;
                if(sesion=='1'){
                    if(idr == '1'){
                        window.location="menu";  
                    }
                    if(idr == '2'){
                        window.location="perfil";  
                    }                    
                }
                if(sesion=='0'){
                    alert(" contraseña o usuarios incorrectos.");     
                }  
            }
        })
    }
	function cargarDatosWeb(){
		var funcion = "editEmpresa";
		var body = { funcion: funcion};
		Empresa.rest({
			verbo: 'POST',
			url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
			data: body,
			funcionExito: function (respuesta) {
				var empresa = respuesta.empresa;
				var sucursal = respuesta.sucursal;
				document.getElementById("nombreempresa").innerHTML = empresa.EMPRESA;
				document.getElementById("logoempresa").src="img/empresa/"+empresa.LOGO+"";
				document.getElementById("iconoempresa").href="img/empresa/"+empresa.ICONO+"";
			}
		});
	}
	this.cargarDatosWeb();	
</script>
</html>

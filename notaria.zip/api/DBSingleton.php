<?php

include_once('../../controlador/conexion.php');

class ManejadorDeBaseDeDatos
{
    private static $instance;
    public static function singleton()
    {
        if (!isset(self::$instance)) {
            self::$instance = new ManejadorDeBaseDeDatos();
        }
        return self::$instance;
    }
    
    public static function consultaAll($consultaSql){
        $resultado = array();
        $coleccionDeDatos = array();
        $resultadoConsulta = self::consulta($consultaSql);
        while ($dato = self::convertirAObjeto($resultadoConsulta)) {
            array_push($coleccionDeDatos, $dato);
        }
        $resultado["size"] = self::obtenerNumeroFilas($resultadoConsulta);
        $resultado["data"] = $coleccionDeDatos;
        return $resultado;
    }
    
    public static function consultaOne($consultaSql){
        return self::convertirAObjeto(self::consulta($consultaSql));
    }
    
    public static function consulta($consultaSql){
        $conexion = Conectar();
        $resultadoConsulta = EjecutarConsulta($consultaSql);
        Desconectar($conexion);
        if($resultadoConsulta == false) {
            throw  new Exception('[DB error] '.$consultaSql, 500);
        }
        return $resultadoConsulta;
    }
    
    public static function convertirAObjeto($variable) {
        return mysql_fetch_object($variable);
    }
    
    public static function obtenerNumeroFilas($resultadoConsulta) {
        return 0 + mysql_num_rows($resultadoConsulta);
    }
    
    public static function begin(){
        mysql_query("BEGIN");
    }
    
    public static function commit(){
        mysql_query("COMMIT");
    }
    
    public static function rollback(){
        mysql_query("ROLLBACK");
    }
    
}

$DB = ManejadorDeBaseDeDatos::singleton();
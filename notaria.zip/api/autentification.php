<?php

try{
    //TODO implementar la logica para para saber si el usuario esta con sesion activa
    $autentificado = true;
    if(!$autentificado) {
        throw new Exception("el usuario no esta autentificado",401);
    }
} catch (Exception $e){
    Response::sendError($e," no tiene autorizacion para ver esta pagina ");
}

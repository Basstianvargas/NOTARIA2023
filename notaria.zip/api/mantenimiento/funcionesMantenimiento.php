<?php
date_default_timezone_set("America/La_Paz"); 
header('Content-Type: text/html; charset=UTF-8');  
include "../api.php";
try {
	
    $body = Response::getBody();
	/* ---------------------------------------------------- */
    $DB = new DB();
    $DB->conectar();
    $DB->begin();
	/* ---------------------------------------------------- */
	
	$fechareg= date("Y-m-d H:i:s");
	$newfecha = date("Y-m-d");
	$newhora = date("G:i:s");	
	$funcion = $body["funcion"];
	switch($funcion) {
		/* ---------------------Roles---------------------------- */
		case 'listarRol': 
			$c00 = "SELECT * from rol";
			$roles = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["roles"] = $roles;
		break;
		case 'newRol': 
			$rol = $body["rol"]; 
			$descripcion = $body["descripcion"]; 
			
			$c00 = " INSERT INTO rol values(default,'".$rol."','".$descripcion."');";
			$insertRol= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertRol;
		break;		
		case 'editRol': 
			$idr = $body["idrol"]; 
			$c00 = "SELECT * from rol where id_rol='".$idr."'";
			$rol = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["rol"] = $rol;
		break;
		case 'updRol': 
			$idr = $body["idrol"];  
			$rol = $body["rol"]; 
			$descripcion = $body["descripcion"];
			
			$c00 = "UPDATE rol set rol = '".$rol."', descripcion = '".$descripcion."' WHERE id_rol = '".$idr."';";
			$updRol = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updRol;
		break;
		/* ---------------------Modulos---------------------------- */
		case 'listarModulo': 
			$c00 = "SELECT * from modulo";
			$modulos = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["modulos"] = $modulos;
		break;
		case 'newModulo': 
			$modulo = $body["modulo"]; 
			$icono = $body["icono"]; 
			$descripcion = $body["descripcion"]; 
			
			$c00 = " INSERT INTO modulo values(default,'".$modulo."','".$descripcion."','".$icono."');";
			$insertModulo= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertModulo;
		break;		
		case 'editModulo': 
			$idm = $body["idmodulo"]; 
			$c00 = "SELECT * from modulo where id_modulo='".$idm."'";
			$modulo = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["modulo"] = $modulo;
		break;
		case 'updModulo': 
			$idm = $body["idmodulo"];  
			$modulo = $body["modulo"];
			$icono = $body["icono"]; 			
			$descripcion = $body["descripcion"];
			
			$c00 = "UPDATE modulo set modulo = '".$modulo."', descripcion = '".$descripcion."' , icono = '".$icono."' WHERE id_modulo = '".$idm."';";
			$updModulo = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updModulo;
		break;
		/* ---------------------Modulos---------------------------- */
		case 'listarModulo': 
			$c00 = "SELECT * from modulo";
			$modulos = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["modulos"] = $modulos;
		break;
		case 'newModulo': 
			$modulo = $body["modulo"]; 
			$icono = $body["icono"]; 
			$descripcion = $body["descripcion"]; 
			
			$c00 = " INSERT INTO modulo values(default,'".$modulo."','".$descripcion."','".$icono."');";
			$insertModulo= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertModulo;
		break;		
		case 'editModulo': 
			$idm = $body["idmodulo"]; 
			$c00 = "SELECT * from modulo where id_modulo='".$idm."'";
			$modulo = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["modulo"] = $modulo;
		break;
		case 'updModulo': 
			$idm = $body["idmodulo"];  
			$modulo = $body["modulo"];
			$icono = $body["icono"]; 			
			$descripcion = $body["descripcion"];
			
			$c00 = "UPDATE modulo set modulo = '".$modulo."', descripcion = '".$descripcion."' , icono = '".$icono."' WHERE id_modulo = '".$idm."';";
			$updModulo = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updModulo;
		break;
		
		/* ---------------------Formularios---------------------------- */
		case 'listarFormulario': 
			$c00 = "SELECT * from formulario";
			$formularios = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["formularios"] = $formularios;
		break;
		case 'newFormulario': 
			$formulario = $body["formulario"]; 
			$ruta = $body["ruta"]; 
			$descripcion = $body["descripcion"]; 
			
			$c00 = " INSERT INTO formulario values(default,'".$formulario."','".$descripcion."','".$ruta."');";
			$insertFormulario= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertFormulario;
		break;		
		case 'editFormulario': 
			$idf = $body["idformulario"]; 
			$c00 = "SELECT * from formulario where id_form='".$idf."'";
			$formulario = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["formulario"] = $formulario;
		break;
		case 'updFormulario': 
			$idf = $body["idformulario"];  
			$formulario = $body["formulario"];
			$ruta = $body["ruta"]; 			
			$descripcion = $body["descripcion"];
			
			$c00 = "UPDATE formulario set formulario = '".$formulario."', descripcion = '".$descripcion."' , ruta = '".$ruta."' WHERE id_form = '".$idf."';";
			$updFormulario = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updFormulario;
		break;
		/* ---------------------Asignacion Formulario-Modulo---------------------------- */
		case 'listarFormMod': 	
			$formModulos = array();		
			$c00 = " select m.id_modulo, m.modulo from modulo m ,formulario_modulo fm where m.id_modulo = fm.id_modulo group by m.id_modulo";
			$formMod= $DB->consultaAll($c00);
			for ($i = 0; $i < $formMod["size"]; $i++) {
				$id = $formMod["data"][$i]->id_modulo;
				$modulo = $formMod["data"][$i]->modulo;
				
				$c01 = "SELECT fm.id_form_mod as id, f.formulario as item from formulario f , formulario_modulo fm where f.id_form = fm.id_formulario and fm.id_modulo='".$id."'";
				$forms = $DB->consultaAll($c01);
				
				$detItems = new stdClass();
				$detItems->modulo = $modulo;
				$detItems->datos = $forms;
				
				array_push($formModulos, $detItems);	
			}
			$resultado = array();
			$resultado["formModulos"] = $formModulos;
		break;		
		case 'newFormMod': 
			$formulario = $body["formulario"]; 
			$modulo = $body["modulo"]; 
			
			$c00 = " INSERT INTO formulario_modulo values(default,'".$modulo."','".$formulario."');";
			$insert= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insert;
		break;
		case 'deleteFormMod': 
			$id = $body["id"];
			$c00 = " delete from formulario_modulo where id_form_mod='".$id."';";
			$delete= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $delete;
		break;
		/* ---------------------Asignacion Modulo-Rol---------------------------- */
		case 'listarModRol': 	
			$modRoles = array();		
			$c00 = " select r.id_rol, r.rol from rol r ,modulo_rol mr where mr.id_rol = r.id_rol group by r.id_rol";
			$modRol= $DB->consultaAll($c00);
			for ($i = 0; $i < $modRol["size"]; $i++) {
				$id = $modRol["data"][$i]->id_rol;
				$rol = $modRol["data"][$i]->rol;
				
				$c01 = "SELECT mr.id_mod_rol as id, m.modulo as item from modulo m , modulo_rol mr where m.id_modulo = mr.id_modulo and mr.id_rol='".$id."'";
				$mods = $DB->consultaAll($c01);  
				
				$detItems = new stdClass();
				$detItems->rol = $rol;
				$detItems->datos = $mods;
				
				array_push($modRoles, $detItems);	
			}
			$resultado = array();
			$resultado["modRoles"] = $modRoles;
		break;		
		case 'newModRol': 
			$modulo = $body["modulo"]; 
			$rol = $body["rol"];
			
			$c00 = " INSERT INTO modulo_rol values(default,'".$rol."','".$modulo."');";
			$insert= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insert;
		break;
		case 'deleteModRol': 
			$id = $body["id"];
			$c00 = " delete from modulo_rol where id_mod_rol ='".$id."';";
			$delete= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $delete;
		break;	
	}
	
	$DB->commit();
    $DB->close();
    Response::sendOne($resultado);
} catch (Exception $e) {

	$DB->rollback();
    $DB->close();
    Response::sendError($e);
}
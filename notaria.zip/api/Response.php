<?php

class Response
{
    private static $instance;
    
    public static function singleton()
    {
        if (!isset(self::$instance)) {
            self::$instance = new Response();
        }
        return self::$instance;
    }
    
    /**
     * Devuelve una respuesta en formato jeson
     * @param null $data un array que contenido de la respuesta
     * @param string $status el estado para la respuesta
     */
    public static function sendOne($data = null, $status = "200")
    {
        if ($data == null) {
            $data = array();
            $data['data'] = new stdClass();
        }
        //cabecera de la respuesta
        header("HTTP/1.1 " . $status);
        header('Content-type: application/json');
        echo json_encode($data);
        exit;
    }
    
    public static function sendAll($data = null, $status = "200")
    {
        header("HTTP/1.1 " . $status);
        header('Content-type: application/json');
        if ($data == null) {
            echo json_encode(array());
        } else {
            echo json_encode($data);
        }
        exit;
    }
    
    /**
     * Devuelve una respuesta de error por defecto con error 500
     * @param string $data texto del mensaje
     * @param string $status estado de la respuesta
     */
    public static function sendError($exception, $mensajeParaUsuario = "desconocido")
    {
        _log($exception->getMessage(), "./response.log");
        $code = $exception->getCode();
        if ($code == 0) {
            $code = 500;
        }
        header("HTTP/1.1 " . $code);
        header('Content-type: application/json');
        $mensaje = array();
        $mensaje['codigo'] = $code;
        $mensaje['mensaje'] = $exception->getMessage();
        $mensaje['mensajeParaUsuario'] = "Ocurrio un error: " . $mensajeParaUsuario . ", si el error persiste comuniquese con el adminstrador del sistema";
        
        if ($exception->getCode() == 500) {
            $mensaje['rastro'] = $exception->getTrace();
        }
        echo json_encode($mensaje);
        exit;
    }
    
    /**
     * Recupera el body de un request post u otro verbo que contenga un cuerpo (body)
     * @return array un arreglo php con el contenido del body parseado
     */
    public static function getBody()
    {
        return (array)json_decode(file_get_contents('php://input'));
    }
    
    public static function getQuery()
    {
        $otros = array();
        $queries = explode("&", $_SERVER['QUERY_STRING']);
        foreach ($queries as $tupla) {
            $query = explode("=", $tupla);
            if ($query[1] <> null) {
                $otros[$query[0]] = explode(",", $query[1]);
            }
        }
        return (object)$otros;
    }
    
    public static function getField()
    {
        $query = self::getQuery();
        $resultado = "*";
        if (isset($query->fields)) {
            $resultado = "";
            foreach ($query->fields as $field) {
                if ($resultado == "") {
                    $resultado = $resultado . $field;
                } else {
                    $resultado = $resultado . "," . $field;
                }
            }
        }
        return $resultado;
    }
    
    public static function getParamas()
    {
        return explode("/", $_SERVER['PATH_INFO']);
    }
    
    public static function getMetodo()
    {
        return $_SERVER['REQUEST_METHOD'];
    }
    
    public static function getVariable($nombreVariable)
    {
        $query = json_decode(json_encode(self::getQuery()), true);
        if (isset($query[$nombreVariable])) {
            $resultado = $query[$nombreVariable];
            if (count($resultado) == 1) return $resultado[0];
            return $query[$nombreVariable];
        } else {
            throw new Exception("la variable: " . $nombreVariable . " es obligatorio");
        }
        
    }
    
}

$Response = Response::singleton();


<?php

class CONFIGURACION
{
    private static $instance;
    
    public static function singleton()
    {
        if (!isset(self::$instance)) {
            self::$instance = new Configuracion();
        }
        return self::$instance;
    }
    
    public static function getRutaBase()
    {
        return "http://localhost/inicial/";
    }
    
    public static function sqlHost($host = null)
    {
        if ($host == null) return "localhost";
        return $host;
        
    }
    
    public static function sqlUser($user = null)
    {
        if ($user == null) return "root";
        return $user;
    }
    
    public static function sqlPassword($password = null)
    {
        if ($password == null) return "";
        return $password;
    }
    
    public static function sqlDataBase($database = null)
    {
        if ($database == null) return "sistema_inicial";
        return $database;
    }
    
}


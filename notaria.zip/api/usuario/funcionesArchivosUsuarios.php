<?php
session_start(); 
date_default_timezone_set("America/La_Paz"); 
header('Content-Type: text/html; charset=UTF-8');  
include "../api.php";
try {
	
    $body = Response::getBody();
	/* ---------------------------------------------------- */
    $DB = new DB();
    $DB->conectar();
    $DB->begin();
	/* ---------------------------------------------------- */
	$fechareg= date("Y-m-d H:i:s");
	$newfecha = date("Y-m-d");
	$newhora = date("G:i:s");
	$resultado = array();
	$mensaje = "";
	$funcion = $_POST['funcion'];
	
	switch($funcion) {
		/* --------------------- Foto Usuario ---------------------------- */
		case 'updFotoUser': 
			$id = $_POST['iduser'];
			$foto = $_FILES["newFoto"]["name"];
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_FILES["newFoto"]["type"])){
				$target_dir = "../../img/usuario/";
				$carpeta=$target_dir;
				if (!file_exists($carpeta)) {
					mkdir($carpeta, 0777, true);
				}
				$target_file = $carpeta . basename($_FILES["newFoto"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check file size
				if ($_FILES["newFoto"]["size"] > 524288) {
					$mensaje = "Lo sentimos, el archivo es demasiado grande.  Tamaño máximo admitido: 0.5 MB";
					$uploadOk = 0;
				}else{
					if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
					&& $imageFileType != "gif" ) {
						$mensaje = "Lo sentimos, sólo archivos JPG, JPEG, PNG & GIF  son permitidos.";
						$uploadOk = 0;
					}else{
						if (move_uploaded_file($_FILES["newFoto"]["tmp_name"], $target_file)) {
							$c00 = "UPDATE user set foto = '".$foto."' WHERE id_user = '".$id."';";
							$updUser = $DB->consulta($c00);
							$mensaje = "El Archivo ha sido subido correctamente.";
						} else {
							$mensaje = "Lo sentimos, hubo un error subiendo el archivo.";
						}
					}
				}
			}
			$resultado["subido"] = $uploadOk;
			$resultado["mensaje"] = $mensaje;
		break;
	
	}
	
	$DB->commit();
    $DB->close();
    Response::sendOne($resultado);
	
} catch (Exception $e) {
	$DB->rollback();
    $DB->close();
    Response::sendError($e);
}
?>
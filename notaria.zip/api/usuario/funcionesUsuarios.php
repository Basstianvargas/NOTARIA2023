<?php
session_start(); 
date_default_timezone_set("America/La_Paz"); 
header('Content-Type: text/html; charset=UTF-8');
require '../librerias/phpMailer/Exception.php';
require '../librerias/phpMailer/PHPMailer.php';
require '../librerias/phpMailer/SMTP.php'; 
include "../api.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
try {
    $body = Response::getBody();
	/* ---------------------------------------------------- */
    $DB = new DB();
    $DB->conectar();
    $DB->begin();
	/* ---------------------------------------------------- */
	$fechareg= date("Y-m-d H:i:s");
	$newfecha = date("Y-m-d");
	$newhora = date("G:i:s");	
	$funcion = $body["funcion"];

	switch($funcion) {
		/* ---------------------login - logout---------------------------- */
		case 'login': 
			$user = $body["usuario"];
			$pwd = md5($body["contrasena"]);
			$c00 = "SELECT u.usuario , u.nombres as nomuser, u.apellidos, u.id_user, u.foto, s.id_sucursal, s.sucursal as sucursal FROM user as u, user_sucursal as us ,sucursal as s WHERE u.id_user = us.id_user AND us.id_sucursal = s.id_sucursal AND u.usuario='".$user."' and u.password='".$pwd."';";
			$autentificacion = $DB->consultaAll($c00);
			if($autentificacion["size"]>0){
				for ($i = 0; $i < $autentificacion["size"]; $i++){
					$c01 = "select r.id_rol, r.rol from user as u , user_rol as ur , rol as r where u.id_user = ur.id_user and ur.id_rol = r.id_rol and u.id_user='".$autentificacion["data"][$i]->id_user."'";
					$selectResRol = $DB->consultaOne($c01);
					$c02 = "SELECT e.empresa, e.id_empresa, e.sigla, e.icono , e.logo FROM empresa as e";
					$empresa = $DB->consultaOne($c02);
					
					$_SESSION['log'] = true; 
					$_SESSION['usr'] = $autentificacion["data"][$i]->usuario;
					$_SESSION['idu'] = $autentificacion["data"][$i]->id_user;
					$_SESSION['suc'] = $autentificacion["data"][$i]->sucursal;
					$_SESSION['ids'] = $autentificacion["data"][$i]->id_sucursal;
					$_SESSION['nom'] = $autentificacion["data"][$i]->nomuser;
					$_SESSION['aps'] = $autentificacion["data"][$i]->apellidos;
					$_SESSION['foto'] = $autentificacion["data"][$i]->foto;
					$_SESSION['rol'] = $selectResRol->rol;
					$_SESSION['idr'] = $selectResRol->id_rol;
					$_SESSION['emp'] = $empresa->empresa;
					$_SESSION['ide'] = $empresa->id_empresa;
					$_SESSION['sig'] = $empresa->sigla;
					$_SESSION['ico']= $empresa->icono;
					$_SESSION['logo']= $empresa->logo;
					$sesion = '1';
				}
			}else{
				$sesion = '0';
			}
			$resultado = array();
			$resultado["idr"] = $_SESSION['idr'];
			$resultado["sesion"] = $sesion;
		break;
		case 'logout': 
			session_destroy();
			$sesion = '0';
			$resultado = array();
			$resultado["sesion"] = $sesion;
		break;
		/* --------------------- Usuarios ---------------------------- */
		
		case 'listarUsuarios': 
			$usuarios = array();		
			$c00 = " select * from user u , user_rol as ur where u.id_user= ur.id_user group by u.id_user";
			$users = $DB->consultaAll($c00);
			for ($i = 0; $i < $users["size"]; $i++) {
				$id = $users["data"][$i]->ID_USER;

				$c01 = "SELECT ur.id_user_rol as id, r.rol as item from rol r , user_rol ur where ur.id_rol = r.id_rol and ur.id_user='".$id."'";
				$roles = $DB->consultaAll($c01);
				
				$c02 = "SELECT us.id_user_suc as id, s.sucursal as item from sucursal s , user_sucursal us where us.id_sucursal = s.id_sucursal and us.id_user='".$id."'";
				$sucursales = $DB->consultaAll($c02);
				
				$c03 = "SELECT id_direccion as id, direccion as item from direccion where id_user='".$id."' and estado<>'ELIMINADO'";
				$direcciones = $DB->consultaAll($c03);
				
				$detItems = new stdClass();
				$detItems->id_user = $users["data"][$i]->ID_USER;
				$detItems->id_rol = $users["data"][$i]->ID_ROL;
				$detItems->user = $users["data"][$i]->USUARIO;
				$detItems->ci = $users["data"][$i]->CI;
				$detItems->noms = $users["data"][$i]->NOMBRES;
				$detItems->aps = $users["data"][$i]->APELLIDOS;
				$detItems->email = $users["data"][$i]->EMAIL;
				$detItems->telf = $users["data"][$i]->TELEFONO;
				$detItems->foto = $users["data"][$i]->FOTO;
				$detItems->estado = $users["data"][$i]->ESTADO;
				$detItems->roles = $roles;
				$detItems->sucursales = $sucursales;
				$detItems->direcciones = $direcciones;
				
				array_push($usuarios, $detItems);	
			}
			$resultado = array();
			$resultado["users"] = $usuarios;
			$resultado["query"] = $c00;
		break;
		case 'newUser': 
			$rol = $body["rol"]; 
			$sucursal = $body["sucursal"]; 
			$user = $body["user"]; 
			$ci = $body["ci"]; 
			$noms = $body["noms"]; 
			$aps = $body["aps"]; 
			$email = $body["email"]; 
			$telf = $body["telf"]; 
			$cel = $body["cel"]; 
			$fecnac = isset($body["fecnac"]) ? $body["fecnac"]:"0000-00-00";
			$genero = $body["genero"]; 
			$pwd = md5($body["ci"]);
			$valor=0;
			
			$c00 = "SELECT usuario FROM user where usuario = '".$user."' ";
			$usersis = $DB->consultaOne($c00);
			$existe = isset($usersis->usuario) ? $usersis->usuario:"";
			
			if($existe == ""){
				$c00 = "SELECT max(id_user)+1 AS maxuser FROM user";
				$maxUser = $DB->consultaOne($c00);
				$idus= $maxUser->maxuser;
				
				$c01 = " INSERT INTO user VALUES ('".$idus."', '".$user."', '".$pwd."', '".$ci."', '".$noms."', '".$aps."','".$genero."','".$fecnac."', '".$email."', '".$telf."','".$cel."', 'usr.png', 'INACTIVO');";
				$insertUser= $DB->consulta($c01);
				
				$c02 = " INSERT INTO user_rol VALUES ( default, '".$idus."', '".$rol."');";
				$insertUserR= $DB->consulta($c02);
				
				$c03 = " INSERT INTO user_sucursal VALUES ( default, '".$idus."', '".$sucursal."');";
				$insertUserS= $DB->consulta($c03);
			}else{
				$valor=1;
			}
			$resultado = array();
			$resultado["valor"] = $valor;
		break;		
		case 'editUser': 
			$idus = $body["iduser"]; 
			$c00 = "SELECT * from user where id_user='".$idus."'";
			$user = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["user"] = $user;
		break;
		case 'updUser': 
			$iduser = $body["iduser"];  
			$user = $body["user"]; 
			$ci = $body["ci"]; 
			$noms = $body["noms"]; 
			$aps = $body["aps"]; 
			$email = $body["email"]; 
			$telf = $body["telf"]; 
			$cel = $body["cel"]; 
			$fecnac = $body["fecnac"]; 
			$genero = $body["genero"]; 
			
			$c00 = "UPDATE user set usuario = '".$user."', ci = '".$ci."' , nombres = '".$noms."' , apellidos = '".$aps."' , email = '".$email."' , telefono = '".$telf."', celular = '".$cel."', genero = '".$genero."', fecha_nac = '".$fecnac."' WHERE id_user = '".$iduser."';";
			$updUser = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updUser;
		break;
		case 'deleteUserRol': 
			$id = $body["id"];
			$c00 = " delete from user_rol where id_user_rol ='".$id."';";
			$delete= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $delete;
		break;
		case 'deleteUserSuc': 
			$id = $body["id"];
			$c00 = " delete from user_sucursal where id_user_suc='".$id."';";
			$delete= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $delete;
		break;
		case 'cambiarEstadoUser': 
			$iduser = $body["iduser"];  
			$estado = $body["estado"]; 
			if($estado=='A'){$nestado='INACTIVO';}else{$nestado='ACTIVO';}
			
			$c00 = "UPDATE user set estado = '".$nestado."' WHERE id_user = '".$iduser."';";
			$updUser = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updUser;
		break;
		
		case 'updPwdUser': 
			$resultado = array();
			$iduser = $body["iduser"];  
			$apwd = $body["apwd"]; 
			$npwd = md5($body["npwd"]);
			$valor=1;
			
			$c00 = "SELECT password FROM user where id_user='".$iduser."'";
			$password = $DB->consultaOne($c00);
			$pwd= $password->password;
			
			if($apwd==$pwd){
				$c01 = "UPDATE user set password = '".$npwd."' WHERE id_user = '".$iduser."';";
				$updUser = $DB->consulta($c01);
			}else{
				$valor=0;
			}
			$resultado["valor"] = $valor;
		break;
		/* --------------------- Actualizar Fotografia ---------------------------- */
		case 'actualizarFoto': 
			$iduser = $body["iduser"]; 
			$foto = $body["archivo"];
			
			$c00 = "UPDATE user set foto = '".$foto."' WHERE id_user = '".$iduser."';";
			$updUser = $DB->consulta($c00);
			$resultado = array();
			$resultado["foto"] = $foto;
		break;
		
		/* --------------------- Direccion ---------------------------- */
		case 'listarDireccion': 
			$iduser = $body["iduser"]; 
			$c00 = "SELECT * from direccion where id_user='".$iduser."' and estado<>'ELIMINADO'";
			$direcciones = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["direcciones"] = $direcciones;
		break;
		case 'newDireccion': 
			$iduser = $body["iduser"];
			$latitud = $body["latitud"]; 
			$longitud = $body["longitud"]; 
			$etiqueta = $body["etiqueta"]; 
			$direccion = $body["direccion"];
			$pais = $body["pais"];
			$ciudad = $body["ciudad"];
			$localidad = $body["localidad"];
			
			$c00 = " INSERT INTO direccion values(default,'".$iduser."','".$etiqueta."','".$direccion."','".$latitud."','".$longitud."','".$pais."','".$ciudad."','".$localidad."','ACTIVO');";
			$insertDireccion= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertDireccion;
		break;	
		case 'deleteDireccion': 
			$id = $body["id"];
			$c00 = " UPDATE direccion set estado = 'ELIMINADO' WHERE id_direccion = '".$id."';";
			$delete= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $delete;
		break;
		case 'verDireccion': 
			$id = $body["id"]; 
			$c00 = "SELECT * from direccion where id_direccion = '".$id."'";
			$direccion = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["direccion"] = $direccion;
		break;
		case 'recuperarContrasena': 
			$correo= $body["mail"];
			
			// ----------------------------- Enviar Email ------------------------------
			//Create an instance; passing `true` enables exceptions
			$mail = new PHPMailer(true);
			try {
				//Server settings
				$mail->SMTPDebug = 0;                     					//Enable verbose debug output
				$mail->isSMTP();                                            //Send using SMTP
				$mail->Host       = 'smtp.gmail.com';                       //Set the SMTP server to send through
				$mail->SMTPAuth   = true;                                   //Enable SMTP authentication
				$mail->Username   = 'smgfacturacioncomp@gmail.com';                 //SMTP username
				$mail->Password   = 'xvjxuybmmuunzivw';                     //SMTP password
				$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
				$mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

				//Recipients
				$mail->setFrom('smgfacturacioncomp@gmail.com', 'SISTEMA NOTARIA');
				$mail->addAddress($correo);     //Add a recipient
			  
				//Content
				$mail->isHTML(true);                                  //Set email format to HTML
				$mail->Subject = 'Datos Recuperacion';
				$mail->Body    = '<b>Siga el siguiente enlace para cambiar su contraseña</b><br><p>
				Recuperar Aqui
				</p>';

				$mail->send();
			} catch (Exception $e) {
				echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
		
			$resultado = array();
			$resultado["correo"] = $correo;
		break;
	}

	$DB->commit();
    $DB->close();
    Response::sendOne($resultado);
	
} catch (Exception $e) {
	$DB->rollback();
    $DB->close();
    Response::sendError($e);
}
?>
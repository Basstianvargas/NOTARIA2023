<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title id="nombreempresa"> </title>
		<link rel="shortcut icon" id="iconoempresa" href="" />

		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!-- Tables -->
		<link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">
		<link href="css/plugins/datatables/jquery.dataTables.css" rel="stylesheet">
		
	</head>
	<?php
		error_reporting(0);
		session_start(); 
		$yes = $_SESSION['log']; 
		$aps = $_SESSION['aps'];
		$nom = $_SESSION['nom'];
		$rol = $_SESSION['rol'];
		$emp = $_SESSION['emp'];
		$sig = $_SESSION['sig'];
		$logo = $_SESSION['logo'];
		$img = $_SESSION['img'];
		$idu = $_SESSION['idu'];
	?>
	<body >
		<div id="printForm">
			<table border="1" >
				<thead>
					<tr >
						<th style=" width:35%;">
							<p style="margin:10px; font-size:12px;">N° DE DOCUMENTO NOTARIAL RELACIONADO: <b id="nidc"></b></p>
						</th>
						<th style="line-height: 8px; width:65%;"><br>
							<center>
								<p style="font-size:10px;"><b>DEBIDA DILIGENCIA: CLIENTE PERSONA NATURAL - BENEFICIARIO FINAL - PEP </b></p>
								<p style="font-size:10px;"><b>INSTRUCTIVO PARA NOTARIAS Y NOTARIOS DE FE PÚBLICA </b></p>
								<p style="font-size:10px;"><b>(R.A. N° UIF/015/2021)</b></p>
							</center>
							
						</th>
					</tr>
					<tr >
						<th>
							<center><h2><b>FORM. – <span id="nroform">2 </span></b></h2></center>
						</th>
						<th>
							<table border="1" >
								<thead>
									<tr>
										<th colspan="3" style="width:300px;"><p style="margin:10px ;font-size:12px;"> Lugar y N° de Notaria </p></th>
										<th style="width:100px;font-size:12px;text-align:center;"><p>Dia</p></th>
										<th style="width:100px;font-size:12px;text-align:center;"><p>Mes</p></th>
										<th style="width:100px;font-size:12px;text-align:center;"><p>Año</p></th>
									</tr>
									<tr>		
										<th colspan="3" style="width:300px;"><p style="margin:10px;font-size:12px;"> NOTARIA Nro 42 Cochabamba &nbsp; &nbsp; &nbsp;</p></th>
										<th style="width:100px;font-size:12px;text-align:center;"><p id="fdia"></p></th>
										<th style="width:100px;font-size:12px;text-align:center;"><p id="fmes"></p></th>
										<th style="width:100px;font-size:12px;text-align:center;"><p id="fanio"></p></th>
									</tr>
									<tr>
										<th colspan="6" style="width:100%;"> <p style="margin:10px;font-size:12px;"> Sujeto Obligado: Gonzalo Alfonso La Torre Heredia </p></th>
									</tr>
								</thead>
							</table>
							
						</th>
					</tr>
					<tr>
						<table border="1" >
							<thead>
								<tr>
									<th style="width:70%;">
										<span style="margin:10px; font-size:12px;"> SERVICIO NOTARIAL (Art. 4 y Art. 11 Par. II):</span>
										<ul style="margin-left:-10px;">
											<li style="list-style:none; font-size:10px;">a) Compra/Venta de bienes inmuebles o bienes muebles sujetos a registro. <input type="checkbox" id="cbox1"> </li>
											<li style="list-style:none; font-size:10px;">b) Constitución, modificación o disolución de sociedad. <input type="checkbox" id="cbox2">  </li>
										</ul>
									</th>
									<th style="width:30%;"><p style="margin:10px; font-size:10px;"> Número de personas que participan del Servicio Notarial. <input type="text"  id="nropersonas" size="2" style="width:20px"> </p></th>
								</tr>
							</thead>
						</table>
					</tr>
					<tr>
						<table border="1" >
							<thead>
								<tr>
									<th style="width:100%;">
										<p style="margin:10px; font-size:12px;">I. INFORMACIÓN CORROBORADA PARA LA IDENTIFICACIÓN DEL CLIENTE PERSONA NATURAL Y BENEFICIARIO FINAL - (Arts.3, 12, 13, 15 y 17)</p>
									</th>	
								</tr>
							</thead>
						</table>
					</tr>
					<tr>
						<table border="1" >
							<thead>
								<tr>
									<th style="width:50%;">
										<p style="margin:10px; font-size:12px;"> INFORMACIÓN DEL CLIENTE (Art. 13 Par. I): </p>
									</th>
									<th style="width:50%;">
										<p style="margin:10px; font-size:12px;"> INFORMACIÓN DEL BENEFICIARIO FINAL: (Art.13 Par. I y Art.15) </p>
									</th>	
								</tr>
								<tr>
									<th style="width:50%;">
										<table border="1" >
											<thead id="percli">
												
											</thead>
										</table>
									</th>
									<th style="width:50%;">
										<table  >
											<thead>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" >Datos del BENEFICIARIO FINAL (Art. 3 inc. b), Art. 13 Par. I, Art. 14, y Art. 15) proporcionados por el cliente y corroborados</label></p>
													</th>	
												</tr>
											</thead>
										</table>
									</th>	
								</tr>
								<tr>
									<th style="width:50%;">
										<table style="line-height=10px" border="1">
											<thead>
												<tr>
													<th style="width:500px;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Tipo de persona jurídica </label></p>
													</th>	
												</tr>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Actividad principal u objeto social </label></p>
													</th>	
												</tr>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Fotocopia de la matrícula de inscripción en el Registro de Comercio, FUNDEMPRESA o registro en los Gobiernos Autónomos Departamentales del Estado Plurinacional de Bolivia u otra institución pública que acredite su existencia legal </label></p>
													</th>	
												</tr>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Domicilio de la oficina principal y sucursales </label></p>
													</th>	
												</tr>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Fotocopia de la escritura o Testimonio de Constitución Social, Resolución u otro documento equivalente que acredite la personalidad jurídica. </label></p>
													</th>	
												</tr>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Fotocopia del poder del Representante Legal </label></p>
													</th>	
												</tr>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Fotocopia de la Cédula de Identidad del Representante Legal. </label></p>
													</th>	
												</tr>
												<tr>
													<th style="width:100%;">
														<p style="margin:10px; font-size:10px;"><label><input type="checkbox" > Detalle de Accionistas o Socios que tengan una participación accionaria o societaria igual o mayor al 5%, que contenga la siguiente información:
															<p style="margin:10px; font-size:10px;">i. Nombres y Apellidos y/o Razón Social o denominación.</p>
															<p style="margin:10px; font-size:10px;">ii. Cuando se trate de persona jurídica, nombre del o los Representantes Legales.</p>
															<p style="margin:10px; font-size:10px;">iii. Número del documento de identificación (si corresponde).</p>
															<p style="margin:10px; font-size:10px;">iv. Número de Identificación Tributaria - NIT (si corresponde).</p>
															<p style="margin:10px; font-size:10px;">v. Actividad económica principal.</p>
															<p style="margin:10px; font-size:10px;">vi. Domicilio de la oficina principal (si corresponde)</p> </label></p>
													</th>	
												</tr>												
											</thead>
										</table>
									</th>
									
									<th style="width:50%;">
										<table style="line-height=10px" >
											<thead>
												<tr>
													<th style="width:1000px;">
														<center>
															<br>
															<p style="margin:10px; font-size:10px; text-align:center; "> Firma y C.I. del Cliente (Art. 12 Par. II) </p>
														</center>
													</th>	
												</tr>
											</thead>
										</table>
										
									</th>	
								</tr>
								
							</thead>
						</table>
					</tr>
					<tr>
						<table border="1" >
							<thead>
								<tr>
									<th style="width:1000px">
										<p style="margin:10px; font-size:12px; padding: .1em;"> II. IDENTIFICACIÓN DE LA PERSONA EXPUESTA POLITICAMENTE – PEP. (Art. 17 Par. I, II y III)  </p>
										<p style="margin:10px; font-size:10px; padding: .1em;"> El Beneficiario Final es una PEP? (Según lista de cargos de la UIF) <label> <input type="checkbox" > SI  </label> <label> <input type="checkbox" checked > NO</label> </p>
										<p style="margin:10px; font-size:10px; padding: .1em;"> Si la respuesta es afirmativa, complementar la siguiente información: </p>
										
									</th>	
								</tr>
								<tr>
									<th style="width:1000px">
										<p style="margin:10px; font-size:10px;"> ¿Cuál es el origen de los fondos? </p>
										<p style="margin:10px; font-size:10px;"><input type="text" id="cbox1" style="width:100%"></p>
									</th>	
								</tr>
								<tr>
									<th style="width:100%;">
										<p style="margin:10px; font-size:10px;"> ¿Cuál es el origen de los fondos? </p>
										<p style="margin:10px; font-size:10px;"><input type="text" id="cbox1" style="width:100%"></p>
									</th>	
								</tr>
							</thead>
						</table>
					</tr>
				</thead>
			</table>
			
		</div>
	</body>
	<footer>
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/empresa.js"></script>
		<script src="js/sistema.js"></script>
	</footer>
	<script > 
		var idc= "<?php echo $_GET['idc'];?>";
		var ide= "<?php echo $_GET['ide'];?>";
		function initializer() {
			verFormulario(); 
		}
		
		function verFormulario(){
			Empresa.showSpinner();
			var funcion = "verFormulario1";
			var body = { funcion: funcion , idc: idc, ide: ide };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/notaria/funcionesNotaria.php"),
				data: body,
				funcionExito: function (respuesta) {
					Empresa.hideSpinner();
					var certificado = respuesta.certificado;
					var escritura = respuesta.escritura;
					if(ide=="0"){
						var datos = certificado;
					}else{
						var datos = escritura;	
					}
					var percli = respuesta.percli.data;
					var perben = respuesta.perben.data;
					var nclis = percli.length;
					var nbens = perben.length;
					var npers = nclis + nbens;

					var fec = datos.FECHA;
					var nfecha = fec.split('-');
					if(ide=="0"){
						document.getElementById('nidc').innerHTML = datos.ID_CERTIFICACION;
					}else{
						document.getElementById('nidc').innerHTML = datos.ID_ESCRITURA;
					}
					document.getElementById('fdia').innerHTML = nfecha[2];
					document.getElementById('fmes').innerHTML = nfecha[1];
					document.getElementById('fanio').innerHTML = nfecha[0];
					$("#nropersonas").val(npers);
					var itemfila = $("#percli"); 
					itemfila.show();
					for (var i = 0; i < percli.length; i++){ 
						var fila = "<tr><th style='width:500px;'><p style='margin:10px; font-size:10px;'>Nombre, Razón Social o denominación : <span >" + percli[i].NOMBRES +" "+ percli[i].AP_PATERNO +" "+percli[i].AP_MATERNO + " </span></p></th><th style='width:300px;'><p style='margin:10px; font-size:10px;'> NIT : <span > "+ percli[i].CI +" "+ percli[i].CIUDAD +" </span></p></th></tr>";
						itemfila.append(fila);
					};
					itemfila.show();
					for (var i = 0; i < perben.length; i++){ 
						document.getElementById('nomben'+i).innerHTML = perben[i].NOMBRES +' '+ perben[i].AP_PATERNO +' '+perben[i].AP_MATERNO;
						document.getElementById('ciben'+i).innerHTML = perben[i].CI +' '+perben[i].CIUDAD;
					};
					
				}
			});
		}
		this.initializer();		
	</script> 
</html>

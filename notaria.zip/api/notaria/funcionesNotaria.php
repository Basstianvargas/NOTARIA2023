<?php
session_start(); 
date_default_timezone_set("America/La_Paz"); 
header('Content-Type: text/html; charset=UTF-8');  
include "../api.php";
try {
	
    $body = Response::getBody();
	/* ---------------------------------------------------- */
    $DB = new DB();
    $DB->conectar();
    $DB->begin();
	/* ---------------------------------------------------- */
	$fechareg= date("Y-m-d H:i:s");
	$newfecha = date("Y-m-d");
	$newhora = date("G:i:s");	
	$funcion = $body["funcion"];

	switch($funcion) {
		case 'configuracionInicial': 
			$c00 = "SELECT * from empresa ";
			$configuracion = $DB->consultaAll($c00);
			if($configuracion["size"]>0){
				$conf = '1';
			}else{
				$conf = '0';
			}
			$resultado = array();
			$resultado["configuracion"] = $conf;
		break;
		case 'newDocumento': 
			$concepto = $body["concepto"]; 
			$concepto1 = $body["concepto1"];
			$c00 = "INSERT INTO documento values(default, '".$concepto."', '".$concepto1."');";
			$insertDoc = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertDoc;
		break;
		case 'newEntidad': 
			$entidad = $body["entidad"]; 
			$c00 = "INSERT INTO entidad values(default, '".$entidad."');";
			$insertEnt = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertEnt;
		break;
		case 'newTipoDoc': 
			$tipodoc = $body["tipodoc"]; 
			$tipo = $body["tipo"];
			$c00 = "INSERT INTO tipo_documento values(default, '".$tipodoc."', '".$tipo."');";
			$insertTdoc = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertTdoc;
		break;
		
		/* ---------------------Formularios---------------------------- */
		case 'verFormulario': 
			$idc = $body["idc"];
			$ide = $body["ide"];
			$c00 = "select * from certificacion where id_certificacion='".$idc."' ;";
			$certificado = $DB->consultaOne($c00);
			$c01 = "select * from escritura where id_escritura='".$ide."';";
			$escritura = $DB->consultaOne($c01);
			$c02 = "select * from persona where id_certificacion='".$idc."' and id_escritura='".$ide."' and tipo_cliente='CLIENTE' and tipo_persona='NATURAL' ";
			$percli = $DB->consultaAll($c02);
			$c03 = "select * from persona where id_certificacion='".$idc."' and id_escritura='".$ide."' and tipo_cliente='BENEFICIARIO' and tipo_persona='NATURAL'";
			$perben = $DB->consultaAll($c03);
			$resultado = array();
			$resultado["certificado"] = $certificado;
			$resultado["escritura"] = $escritura;
			$resultado["percli"] = $percli;
			$resultado["perben"] = $perben;
		break;
		case 'verFormulario1': 
			$idc = $body["idc"];
			$ide = $body["ide"];
			$c00 = "select * from certificacion where id_certificacion='".$idc."' ;";
			$certificado = $DB->consultaOne($c00);
			$c01 = "select * from escritura where id_escritura='".$ide."';";
			$escritura = $DB->consultaOne($c01);
			$c02 = "select * from persona where id_certificacion='".$idc."' and id_escritura='".$ide."' and tipo_cliente='CLIENTE' and tipo_persona='JURIDICA'";
			$percli = $DB->consultaAll($c02);
			$c03 = "select * from persona where id_certificacion='".$idc."' and id_escritura='".$ide."' and tipo_cliente='BENEFICIARIO' and tipo_persona='JURIDICA'";
			$perben = $DB->consultaAll($c03);
			$resultado = array();
			$resultado["certificado"] = $certificado;
			$resultado["escritura"] = $escritura;
			$resultado["percli"] = $percli;
			$resultado["perben"] = $perben;
		break;

		/* --------------------- Poderes ---------------------------- */
		case 'newPoder': 
			$iduser = $body["iduser"];
			$c00 = "select gestion from gestion where estado= 'ACTIVO';";
			$selectgestion = $DB->consultaOne($c00);
			$ngestion = isset($selectgestion ->gestion) ? $selectgestion->gestion : '2022';
			
			$c01 = "select max(nro)+1 as nroesc from escritura where tipo= 'PODER';";
			$selectEsc = $DB->consultaOne($c01);
			$nroesc = isset($selectEsc ->nroesc) ? $selectEsc->nroesc : '1';
			
			$c02 = " SELECT max(id_escritura) as maxesc FROM escritura";
			$maxesc = $DB->consultaOne($c02);
			$idesc = isset($maxesc ->maxesc) ? $maxesc->maxesc : '1';
			
			$c03 = " INSERT INTO escritura_new VALUES (NULL, '".$idesc."', '0', '".$ngestion."', now(), now(), 'PODER', '0',  '".$nroesc."', '-', '-', '-', '-','-');";
			$insertEsc = $DB->consulta($c03);
			
			$resultado = array();
			$resultado["ok"] = $insertEsc;
			$resultado["idesc"] = $idesc;
			$resultado["nroesc"] = $nroesc;
		break;

		/* ---------------------Escrituras---------------------------- */
		case 'newEscritura': 
			$iduser = $body["iduser"];
			$c00 = "select gestion from gestion where estado= 'ACTIVO';";
			$selectgestion = $DB->consultaOne($c00);
			$ngestion = isset($selectgestion ->gestion) ? $selectgestion->gestion : '2022';
			
			$c01 = "select max(nro)+1 as nroesc from escritura_new where tipo= 'ESCRITURA';";
			$selectEsc = $DB->consultaOne($c01);
			$nroesc = isset($selectEsc ->nroesc) ? $selectEsc->nroesc : '1';
			
			$c02 = " SELECT max(id_escritura) as maxesc FROM escritura_new";
			$maxesc = $DB->consultaOne($c02);
			$idesc = isset($maxesc ->maxesc) ? $maxesc->maxesc : '1';
			
			$c03 = " INSERT INTO escritura_new VALUES (NULL, '".$idesc."', '0', '".$ngestion."', now(), now(), 'ESCRITURA', '0',  '".$nroesc."', '-', '-', '-', '-','-');";
			$insertEsc = $DB->consulta($c03);
			
			$resultado = array();
			$resultado["ok"] = $insertEsc;
			$resultado["idesc"] = $idesc;
			$resultado["nroesc"] = $nroesc;
		break;
		case 'listarEscrituras':
			$fecini = $body["fecini"]; 
			$fecfin = $body["fecfin"];
			$datos = array();
			$c00 = "SELECT * FROM escritura_new as e where e.fecha>='".$fecini."' and e.fecha<='".$fecfin."' group by e.id_escritura order by fecha desc";
			$all = $DB->consultaAll($c00);
			
			for ($i = 0; $i < $all["size"]; $i++){
				$ide = $all["data"][$i]->ID_ESCRITURA;
				$fecha = $all["data"][$i]->FECHA;
				$hora = $all["data"][$i]->HORA;
				$nro = $all["data"][$i]->NRO;
				$estado = $all["data"][$i]->ESTADO;
				$obs = $all["data"][$i]->OBSERVACION;
				$idtipodoc = $all["data"][$i]->ID_TIPO_DOC;
				$tipo = $all["data"][$i]->TIPO;
				$cabecera = $all["data"][$i]->CABECERA;
				$cuerpo = $all["data"][$i]->CUERPO;
				$pie = $all["data"][$i]->PIE;
				
				$c01 = " SELECT nombre_documento FROM tipo_documento WHERE ID_TIPO_DOC='".$idtipodoc."';";
				$resSelect = $DB->consultaOne($c01);
				$tipdoc = isset($resSelect->nombre_documento) ? $resSelect->nombre_documento : '';
				$c02 = "SELECT * from persona where id_escritura='".$ide."' and rol = '1' ";
				$personasafavor = $DB->consultaAll($c02);
				$c03 = "SELECT * from persona where id_escritura='".$ide."' and rol = '2' ";
				$personassolicitantes = $DB->consultaAll($c03);

				$escritura = new stdClass();
				$escritura->ide = $ide;
				$escritura->fecha = $fecha;
				$escritura->tipo = $tipo;
				$escritura->hora = $hora;
				$escritura->nro = $nro;
				$escritura->cabecera = $cabecera;
				$escritura->cuerpo = $cuerpo;
				$escritura->pie = $pie;
				$escritura->estado = $estado;
				$escritura->personas1 = $personasafavor;
				$escritura->personas2 = $personassolicitantes;
				$escritura->tipodoc = $tipdoc;
				$escritura->observacion = $obs;
				array_push($datos, $escritura);
			}
			$resultado = array();
			$resultado["escrituras"] = $datos;
		break;
		case 'updEscrituras': 
			$idesc = $body["idesc"];
			$nroesc = $body["nroesc"];
			$tipodoc = $body["tipodoc"];
			$c00 = " UPDATE escritura_new  SET id_escritura='".$idesc."' ,id_tipo_doc='".$tipodoc."', nro = '".$nroesc."' where id_escritura='".$idesc."'";
			$updEsc = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updEsc;
		break;
		case 'updEscritura1': 
			$idesc = $body["idesc"];
			$nroesc = $body["nroesc"];
			$tipodoc = $body["tipodoc"];
			$fecha= $body["fecha"];
			$hora = $body["hora"];
			$obs = $body["obs"];
			$c00 = " UPDATE escritura_new  SET id_escritura='".$idesc."' ,id_tipo_doc='".$tipodoc."', nro = '".$nroesc."', FECHA='".$fecha."', HORA='".$hora."' , observacion='".$obs."' where id_escritura='".$idesc."'";
			$updEsc = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updEsc;
		break;
		case 'editEscritura': 
			$ide = $body["idesc"]; 
			$c00 = "SELECT * from escritura_new where id_escritura = '".$ide."'";
			$escritura = $DB->consultaOne($c00);

			$c01 = "SELECT * from tipo_documento where id_tipo_doc ='".$escritura->ID_TIPO_DOC."'";
			$tipo = $DB->consultaOne($c01);

			$c02 = "SELECT * from persona where id_escritura ='".$ide."' and rol='1'";
			$deudor = $DB->consultaAll($c02);

			$c03 = "SELECT * from persona where id_escritura ='".$ide."' and rol='2'";
			$acreedor = $DB->consultaAll($c03);

			$resultado = array();
			$resultado["escritura"] = $escritura;
			$resultado["tipo"] = $tipo;
			$resultado["deudor"] = $deudor;
			$resultado["acreedor"] = $acreedor;
		break;
		case 'guardarCabecera': 
			$idesc = $body["idesc"];
			$cabecera = $body["cabecera"];
			$c00 = " UPDATE escritura_new  SET cabecera='".$cabecera."' where id_escritura='".$idesc."'";
			$updEsc = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updEsc;
		break;
		case 'guardarCuerpo': 
			$idesc = $body["idesc"];
			$cuerpo = $body["cuerpo"];
			$c00 = " UPDATE escritura_new  SET cuerpo='".$cuerpo."' where id_escritura='".$idesc."'";
			$updEsc = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updEsc;
		break;
		/* ---------------------Certificaciones---------------------------- */
		case 'newCertificacion': 
			$iduser = $body["iduser"];
			$c00 = "select gestion from gestion where estado= 'ACTIVO';";
			$selectgestion = $DB->consultaOne($c00);
			$ngestion = isset($selectgestion ->gestion) ? $selectgestion->gestion : '2022';
			
			$c01 = "select max(nro)+1 as nrocer from certificacion_new ;";
			$selectCer = $DB->consultaOne($c01);
			$nrocer = isset($selectCer ->nrocer) ? $selectCer->nrocer : '1';
			
			$c02 = " SELECT max(id_certificacion) as maxcer FROM certificacion_new;";
			$maxcer = $DB->consultaOne($c02);
			$idcer = isset($maxcer ->maxcer) ? $maxcer->maxcer : '1';
			
			$c03 = " INSERT INTO certificacion_new values(default,'".$idcer."','1','1','".$ngestion."',now(),now(),'','','0','".$iduser."','".$nrocer."','');";
			$insertCer = $DB->consulta($c03);
			
			$resultado = array();
			$resultado["ok"] = $insertCer;
			$resultado["idc"] = $idcer;
			$resultado["nrocer"] = $nrocer;
		break;
		case 'updCertificacion': 
			$documento = $body["documento"]; 
			$entidad = $body["entidad"]; 
			$fecdoc = $body["fecdoc"];
			$idcer = $body["idcer"];
			$nrocer = $body["nrocer"];
			$tipodoc = $body["tipodoc"];
			$c00 = " UPDATE certificacion_new AS c SET c.ID_DODUMENTO='".$documento."' ,c.ID_TIPO_DOC='".$tipodoc."', c.ENTIDAD='".$entidad."' , c.FECHA_DOC ='".$fecdoc."' , c.NRO = '".$nrocer."' where ID_CERTIFICACION='".$idcer."'";
			$updCer = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updCer;
			$resultado["query"] = $c00;
		break;
		case 'updCertificacion1': 
			$documento = $body["documento"]; 
			$entidad = $body["entidad"]; 
			$fecdoc = $body["fecdoc"];
			$fecha= $body["fecha"];
			$hora = $body["hora"];
			$idcer = $body["idcer"];
			$tipodoc = $body["tipodoc"];
			$nrocer = $body["nrocer"];
			$obs = $body["obs"];
			$c00 = " UPDATE certificacion_new AS c SET c.OBSERVACION='".$obs."', c.ID_DODUMENTO='".$documento."' , c.ID_TIPO_DOC='".$tipodoc."', c.ENTIDAD='".$entidad."' , c.FECHA_DOC ='".$fecdoc."' , c.FECHA='".$fecha."', c.HORA='".$hora."', c.NRO = '".$nrocer."' where ID_CERTIFICACION='".$idcer."'";
			$updCer = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updCer;
			$resultado["query"] = $c00;
		break;
		case 'editCertificacion': 
			$idc = $body["idcer"]; 
			$c00 = "SELECT * from certificacion_new where id_certificacion='".$idc."'";
			$certificacion = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["certificacion"] = $certificacion;
		break;
		case 'editPersona': 
			$idp = $body["idp"]; 
			$c00 = "SELECT * from persona where id_persona='".$idp."'";
			$persona = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["persona"] = $persona;
		break;
		case 'anularCertificacion': 
			$idc = $body["idc"]; 
			$c00 = "update certificacion_new set estado='1' where id_certificacion='".$idc."'";
			$updCer= $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updCer;
		break;
		case 'listarCertificacion':
			$fecini = $body["fecini"]; 
			$fecfin = $body["fecfin"];
			$datos = array();
			$c00 = "SELECT * FROM certificacion_new as c, documento as d where c.id_dodumento= d.id_documento and fecha>='".$fecini."' and fecha<='".$fecfin."' group by c.id_certificacion order by fecha desc";
			$all = $DB->consultaAll($c00);
			
			for ($i = 0; $i < $all["size"]; $i++){
				$idc = $all["data"][$i]->ID_CERTIFICACION;
				$concepto = $all["data"][$i]->CONCEPTO;
				$fecha = $all["data"][$i]->FECHA;
				$hora = $all["data"][$i]->HORA;
				$entidad = $all["data"][$i]->ENTIDAD;
				$fecha_doc = $all["data"][$i]->FECHA_DOC;
				$estado = $all["data"][$i]->ESTADO;
				$obs = $all["data"][$i]->OBSERVACION;
				$idtipodoc = $all["data"][$i]->ID_TIPO_DOC;
				$c01 = "SELECT * from persona where id_certificacion='".$idc."' ";
				$personas = $DB->consultaAll($c01);
				$c02 = " SELECT nombre_documento FROM tipo_documento WHERE ID_TIPO_DOC='".$idtipodoc."';";
				$resSelect = $DB->consultaOne($c02);
				$tipdoc = isset($resSelect->nombre_documento) ? $resSelect->nombre_documento : '';
				$certificacion = new stdClass();
				$certificacion->idc = $idc;
				$certificacion->concepto = $concepto;
				$certificacion->fecha = $fecha;
				$certificacion->hora = $hora;
				$certificacion->entidad = $entidad;
				$certificacion->estado = $estado;
				$certificacion->fechadoc = $fecha_doc;
				$certificacion->personas = $personas;
				$certificacion->tipodoc = $tipdoc;
				$certificacion->observacion = $obs;
				array_push($datos, $certificacion);
			}
			$resultado = array();
			$resultado["certificaciones"] = $datos;
		break;
		case 'listarCertificacion1':
			$n1 = $body["n1"]; 
			$n2 = $body["n2"];
			$datos = array();
			$c00 = "SELECT * FROM certificacion_new as c, documento as d where c.id_dodumento= d.id_documento and id_certificacion>='".$n1."' and id_certificacion<='".$n2."' group by c.id_certificacion order by fecha desc";
			$all = $DB->consultaAll($c00);
			
			for ($i = 0; $i < $all["size"]; $i++){
				$idc = $all["data"][$i]->ID_CERTIFICACION;
				$concepto = $all["data"][$i]->CONCEPTO;
				$fecha = $all["data"][$i]->FECHA;
				$hora = $all["data"][$i]->HORA;
				$entidad = $all["data"][$i]->ENTIDAD;
				$fecha_doc = $all["data"][$i]->FECHA_DOC;
				$estado = $all["data"][$i]->ESTADO;
				$obs = $all["data"][$i]->OBSERVACION;
				$idtipodoc = $all["data"][$i]->ID_TIPO_DOC;
				$c01 = "SELECT * from persona where id_certificacion='".$idc."' ";
				$personas = $DB->consultaAll($c01);
				$c02 = " SELECT nombre_documento FROM tipo_documento WHERE ID_TIPO_DOC='".$idtipodoc."';";
				$resSelect = $DB->consultaOne($c02);
				$tipdoc = isset($resSelect->nombre_documento) ? $resSelect->nombre_documento : '';
				$certificacion = new stdClass();
				$certificacion->idc = $idc;
				$certificacion->concepto = $concepto;
				$certificacion->fecha = $fecha;
				$certificacion->hora = $hora;
				$certificacion->entidad = $entidad;
				$certificacion->estado = $estado;
				$certificacion->fechadoc = $fecha_doc;
				$certificacion->personas = $personas;
				$certificacion->tipodoc = $tipdoc;
				$certificacion->observacion = $obs;
				array_push($datos, $certificacion);
			}
			$resultado = array();
			$resultado["certificaciones"] = $datos;
			$resultado["query"] = $c02;
		break;
		case 'reporteCertificacion':
			$n1 = $body["n1"]; 
			$n2 = $body["n2"];
			$countper=0;$countcer=0;
			$datos = array();
			$c00 = "SELECT * FROM certificacion_new as c, documento as d where c.id_dodumento= d.id_documento and id_certificacion>='".$n1."' and id_certificacion<='".$n2."' group by c.id_certificacion";
			$all = $DB->consultaAll($c00);
			
			for ($i = 0; $i < $all["size"]; $i++){
				$idc = $all["data"][$i]->ID_CERTIFICACION;
				$concepto = $all["data"][$i]->CONCEPTO;
				$fecha = $all["data"][$i]->FECHA;
				$hora = $all["data"][$i]->HORA;
				$entidad = $all["data"][$i]->ENTIDAD;
				$fecha_doc = $all["data"][$i]->FECHA_DOC;
				$c01 = "SELECT * from persona where id_certificacion='".$idc."' ";
				$personas = $DB->consultaAll($c01);
				$countper = $countper + $personas["size"];
				$c02 = "SELECT * from persona where id_certificacion='".$idc."' and tipo='1' ";
				$personasC = $DB->consultaAll($c01);
				if($personasC["size"]<=4){
					$countcer = $countcer +1;
				}
				if($personasC["size"]>4 && $personasC["size"]<=8){
					$countcer = $countcer +2;
				}
				if($personasC["size"]>8 && $personasC["size"]<=12){
					$countcer = $countcer +3;
				}
				if($personasC["size"]>12 && $personasC["size"]<=16){
					$countcer = $countcer +4;
				}
				$certificacion = new stdClass();
				$certificacion->idc = $idc;
				$certificacion->concepto = $concepto;
				$certificacion->fecha = $fecha;
				$certificacion->hora = $hora;
				$certificacion->entidad = $entidad;
				$certificacion->fechadoc = $fecha_doc;
				$certificacion->personas = $personas;
				$certificacion->nropersonas= $countper;
				$certificacion->nrocer= $countcer;
				array_push($datos, $certificacion);
			}
			$resultado = array();
			$resultado["certificaciones"] = $datos;
		break;
		case 'reporteIngresos':
			$f1 = $body["f1"]; 
			$f2 = $body["f2"];
			$countper=0;$countcer=0;
			$datos = array();
			$c00 = "SELECT * FROM certificacion_new where fecha>='".$f1."' and fecha<='".$f2."' group by id_certificacion";
			$all = $DB->consultaAll($c00);
			$totalIngreso=0;
			for ($i = 0; $i < $all["size"]; $i++){
				$idc = $all["data"][$i]->ID_CERTIFICACION;
				$nro = $all["data"][$i]->NRO;
				$estado = $all["data"][$i]->ESTADO;
				if($estado==0){
					$costo = 60;
				}else{
					$costo = 10;
				}
				$totalIngreso=$totalIngreso+$costo;
				$certificacion = new stdClass();
				$certificacion->idc = $idc;
				$certificacion->nro = $nro;
				$certificacion->costo = $costo;
				array_push($datos, $certificacion);
			}
			$resultado = array();
			$resultado["certificaciones"] = $datos;
			$resultado["totalIngreso"] = $totalIngreso;
			$resultado["query"] = $c00;
		break;
		/* ---------------------Personas Certificaciones ---------------------------- */
		case 'listarPersonas':
			$idc = $body["idc"]; 
			$datos = array();
			$c00 = "SELECT * FROM persona where id_certificacion='".$idc."'";
			$all = $DB->consultaAll($c00);
			
			$resultado = array();
			$resultado["personas"] = $all;
			$resultado["query"] = $c00;
		break;
		case 'newPersona': 
			$idc = $body["idc"]; 
			$ide = $body["ide"]; 
			$app = $body["app"]; 
			$apm = $body["apm"]; 
			$nom = $body["nom"]; 
			$ci = $body["ci"]; 
			$ciudad = $body["ciudad"]; 
			$tipo = $body["tipo"];
			$tipoper = $body["tipoper"];
			$tipocli = $body["tipocli"];
			$rol = $body["rol"];
			$ide = $body["ide"];
			
			$c00 = " INSERT INTO persona values(default,'".$idc."','".$ide."','".$app."','".$apm."','".$nom."','".$ci."','".$ciudad."','".$tipo."','1','".$tipoper."','".$tipocli."','".$rol."');";
			$insertPer = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertPer;
		break;
		case 'updPersona': 
			$idp = $body["idp"]; 
			$app = $body["app"]; 
			$apm = $body["apm"]; 
			$nom = $body["nom"]; 
			$ci = $body["ci"]; 
			$ciudad = $body["ciudad"]; 
			$tipo = $body["tipo"]; 
			$tipoper = $body["tipoper"];
			$tipocli = $body["tipocli"];
			$rol = $body["rol"];
			
			$c00 = " update persona  set ap_paterno='".$app."', ap_materno='".$apm."', nombres='".$nom."' ,  rol= '".$rol."', ci='".$ci."',ciudad='".$ciudad."', tipo='".$tipo."' , tipo_persona='".$tipoper."', tipo_cliente='".$tipocli."' where id_persona='".$idp."';";
			$insertPer = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertPer;
		break;
		case 'deletePersona': 
			$idp = $body["idp"];

			$c00 = "select ID_CERTIFICACION  FROM persona WHERE id_persona = '".$idp."'";
			$idce = $DB->consultaOne($c00);
			$idcerti = $idce->ID_CERTIFICACION;
			
			$c01 = " DELETE FROM persona WHERE id_persona = '".$idp."'";
			$deletePer = $DB->consulta($c01);
			
			$resultado = array();
			$resultado["ok"] = $deletePer;
			$resultado["idc"] = $idcerti;
		break;
		case 'printPersonas': 
			$idc = $body["idc"]; 
			$c00 = "select * from persona where id_certificacion='".$idc."'";
			$all = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["personas"] = $all;
		break;
		/* ---------------------Personas Escrituras ---------------------------- */
		case 'listarPersonas1':
			$idc = $body["idc"]; 
			$ide = $body["ide"];
			$datos = array();
			$c00 = "SELECT * FROM persona where id_certificacion='".$idc."' and id_escritura='".$ide."'";
			$all = $DB->consultaAll($c00);
			
			$resultado = array();
			$resultado["personas"] = $all;
			$resultado["query"] = $c00;
		break;
		case 'newPersona1': 
			$idc = $body["idc"]; 
			$ide = $body["ide"]; 
			$app = $body["app"]; 
			$apm = $body["apm"]; 
			$nom = $body["nom"]; 
			$ci = $body["ci"]; 
			$ciudad = $body["ciudad"]; 
			$tipo = $body["tipo"];
			$tipoper = $body["tipoper"];
			$tipocli = $body["tipocli"];
			$rol = $body["rol"];
			$ide = $body["ide"];
			
			$c00 = " INSERT INTO persona values(default,'".$idc."','".$ide."','".$app."','".$apm."','".$nom."','".$ci."','".$ciudad."','".$tipo."','1','".$tipoper."','".$tipocli."','".$rol."');";
			$insertPer = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertPer;
		break;
		case 'updPersona1': 
			$idp = $body["idp"]; 
			$app = $body["app"]; 
			$apm = $body["apm"]; 
			$nom = $body["nom"]; 
			$ci = $body["ci"]; 
			$ciudad = $body["ciudad"]; 
			$tipo = $body["tipo"]; 
			$tipoper = $body["tipoper"];
			$tipocli = $body["tipocli"];
			$rol = $body["rol"];
			
			$c00 = " update persona  set ap_paterno='".$app."', ap_materno='".$apm."', nombres='".$nom."' ,  rol= '".$rol."', ci='".$ci."',ciudad='".$ciudad."', tipo='".$tipo."' , tipo_persona='".$tipoper."', tipo_cliente='".$tipocli."' where id_persona='".$idp."';";
			$insertPer = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $insertPer;
		break;
		case 'deletePersona1': 
			$idp = $body["idp"];

			$c00 = "select ID_ESCRITURA  FROM persona WHERE id_persona = '".$idp."'";
			$idce = $DB->consultaOne($c00);
			$idesc = $idce->ID_ESCRITURA;
			
			$c01 = " DELETE FROM persona WHERE id_persona = '".$idp."'";
			$deletePer = $DB->consulta($c01);
			
			$resultado = array();
			$resultado["ok"] = $deletePer;
			$resultado["ide"] = $idesc;
		break;
		case 'printPersonas': 
			$idc = $body["idc"]; 
			$c00 = "select * from persona where id_certificacion='".$idc."'";
			$all = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["personas"] = $all;
		break;
		/* ---------------------Notaria---------------------------- */
		case 'datosNotaria':  
			$c00 = "select * from notaria where id_notaria='1'";
			$notaria = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["notaria"] = $notaria;
		break;
		case 'updNotaria': 
			$nro = $body["nro"]; 
			$notario = $body["notario"]; 
			$ciudad = $body["ciudad"]; 
			$provincia = $body["provincia"]; 
			$c00 = "update notaria set nro='".$nro."' , encargado='".$notario."' , ciudad='".$ciudad."' , provincia='".$provincia."' where id_notaria='1' ";
			$updNotaria = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updNotaria;
		break;
		case 'updEstado': 
			$idc = $body["idc"]; 
			$idp = $body["idp"]; 
			$estado = $body["estado"]; 
			if($estado == 0){
				$c00 = "update persona set oculto='1' where id_persona='".$idp."' ";
				$updEstado = $DB->consulta($c00);
			}else{
				$c00 = "update persona set oculto='0' where id_persona='".$idp."' ";
				$updEstado = $DB->consulta($c00);
			}
			$resultado = array();
			$resultado["idc"] = $idc;
		break;
		case 'updEstado1': 
			$ide = $body["ide"]; 
			$idp = $body["idp"]; 
			$estado = $body["estado"]; 
			if($estado == 0){
				$c00 = "update persona set oculto='1' where id_persona='".$idp."' ";
				$updEstado = $DB->consulta($c00);
			}else{
				$c00 = "update persona set oculto='0' where id_persona='".$idp."' ";
				$updEstado = $DB->consulta($c00);
			}
			$resultado = array();
			$resultado["ide"] = $ide;
		break;
		case 'buscarCi': 
			$ci = $body["ci"]; 
			$c00 = "select  ap_paterno, ap_materno, nombres from persona where ci='".$ci."' order by id_persona desc ";
			$persona = $DB->consultaOne($c00);
			
			$resultado = array();
			$resultado["persona"] = $persona;
		break;
	}
	
	/* ---------------------------------------------------- */
	$DB->commit();
    $DB->close();
    Response::sendOne($resultado);
} catch (Exception $e) {
	/* ---------------------------------------------------- */
	$DB->rollback();
    $DB->close();
    Response::sendError($e);
}

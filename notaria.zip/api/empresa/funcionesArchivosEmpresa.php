<?php
session_start(); 
date_default_timezone_set("America/La_Paz"); 
header('Content-Type: text/html; charset=UTF-8');  
include "../api.php";
try {
	
    $body = Response::getBody();
	/* ---------------------------------------------------- */
    $DB = new DB();
    $DB->conectar();
    $DB->begin();
	/* ---------------------------------------------------- */
	$fechareg= date("Y-m-d H:i:s");
	$newfecha = date("Y-m-d");
	$newhora = date("G:i:s");
	$resultado = array();
	$mensaje = "";
	$funcion = $_POST['funcion'];
	
	switch($funcion) {
		/* --------------------- Empresa ---------------------------- */
		case 'updLogoEmpresa': 
			$id = $_POST['idemp'];
			$logo = $_FILES["newLogo"]["name"];
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_FILES["newLogo"]["type"])){
				$target_dir = "../../img/empresa/";
				$carpeta=$target_dir;
				if (!file_exists($carpeta)) {
					mkdir($carpeta, 0777, true);
				}
				$target_file = $carpeta . basename($_FILES["newLogo"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check file size
				if ($_FILES["newLogo"]["size"] > 524288) {
					$mensaje = "Lo sentimos, el archivo es demasiado grande.  Tamaño máximo admitido: 0.5 MB";
					$uploadOk = 0;
				}else{
					if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
					&& $imageFileType != "gif" ) {
						$mensaje = "Lo sentimos, sólo archivos JPG, JPEG, PNG & GIF  son permitidos.";
						$uploadOk = 0;
					}else{
						if (move_uploaded_file($_FILES["newLogo"]["tmp_name"], $target_file)) {
							$c00 = "UPDATE empresa set logo = '".$logo."' WHERE id_empresa = '".$id."';";
							$updLogo = $DB->consulta($c00);
							$mensaje = "El Archivo ha sido subido correctamente.";
						} else {
							$mensaje = "Lo sentimos, hubo un error subiendo el archivo.";
						}
					}
				}
			}
			$resultado["subido"] = $uploadOk;
			$resultado["mensaje"] = $mensaje;
		break;
		case 'updIcoEmpresa': 
			$id = $_POST['idemp'];
			$icono = $_FILES["newIco"]["name"];
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_FILES["newIco"]["type"])){
				$target_dir = "../../img/empresa/";
				$carpeta=$target_dir;
				if (!file_exists($carpeta)) {
					mkdir($carpeta, 0777, true);
				}
				$target_file = $carpeta . basename($_FILES["newIco"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check file size
				if ($_FILES["newIco"]["size"] > 524288) {
					$mensaje = "Lo sentimos, el archivo es demasiado grande.  Tamaño máximo admitido: 0.5 MB";
					$uploadOk = 0;
				}else{
					if($imageFileType != "ico" && $imageFileType != "png"  ) {
						$mensaje = "Lo sentimos, sólo archivos PNG & ICO  son permitidos.";
						$uploadOk = 0;
					}else{
						if (move_uploaded_file($_FILES["newIco"]["tmp_name"], $target_file)) {
							$c00 = "UPDATE empresa set icono = '".$icono."' WHERE id_empresa = '".$id."';";
							$updIcono = $DB->consulta($c00);
							$mensaje = "El Archivo ha sido subido correctamente.";
						} else {
							$mensaje = "Lo sentimos, hubo un error subiendo el archivo.";
						}
					}
				}
			}
			$resultado["subido"] = $uploadOk;
			$resultado["mensaje"] = $mensaje;
		break;
		case 'updFondoSlider': 
			$id = $_POST['id'];
			$fondo = $_FILES["newFondo"]["name"];
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_FILES["newFondo"]["type"])){
				$target_dir = "../../img/fondo/";
				$carpeta=$target_dir;
				if (!file_exists($carpeta)) {
					mkdir($carpeta, 0777, true);
				}
				$target_file = $carpeta . basename($_FILES["newFondo"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check file size
				if ($_FILES["newFondo"]["size"] > 1048576) {
					$mensaje = "Lo sentimos, el archivo es demasiado grande.  Tamaño máximo admitido: 0.5 MB";
					$uploadOk = 0;
				}else{
					if( $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" ) {
						$mensaje = "Lo sentimos, sólo archivos PNG & ICO  son permitidos.";
						$uploadOk = 0;
					}else{
						if (move_uploaded_file($_FILES["newFondo"]["tmp_name"], $target_file)) {
							$c00 = "UPDATE slider_web set fondo = '".$fondo."' WHERE id_slider = '".$id."';";
							$updSlider = $DB->consulta($c00);
							$mensaje = "El Archivo ha sido subido correctamente.";
						} else {
							$mensaje = "Lo sentimos, hubo un error subiendo el archivo.";
						}
					}
				}
			}
			$resultado["subido"] = $uploadOk;
			$resultado["mensaje"] = $mensaje;
		break;
		case 'updPortadaSlider': 
			$id = $_POST['id'];
			$portada = $_FILES["newPortada"]["name"];
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_FILES["newPortada"]["type"])){
				$target_dir = "../../img/portada/";
				$carpeta=$target_dir;
				if (!file_exists($carpeta)) {
					mkdir($carpeta, 0777, true);
				}
				$target_file = $carpeta . basename($_FILES["newPortada"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check file size
				if ($_FILES["newPortada"]["size"] > 524288) {
					$mensaje = "Lo sentimos, el archivo es demasiado grande.  Tamaño máximo admitido: 0.5 MB";
					$uploadOk = 0;
				}else{
					if( $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" ) {
						$mensaje = "Lo sentimos, sólo archivos PNG & ICO  son permitidos.";
						$uploadOk = 0;
					}else{
						if (move_uploaded_file($_FILES["newPortada"]["tmp_name"], $target_file)) {
							$c00 = "UPDATE slider_web set imagen = '".$portada."' WHERE id_slider = '".$id."';";
							$updPortada = $DB->consulta($c00);
							$mensaje = "El Archivo ha sido subido correctamente.";
						} else {
							$mensaje = "Lo sentimos, hubo un error subiendo el archivo.";
						}
					}
				}
			}
			$resultado["subido"] = $uploadOk;
			$resultado["mensaje"] = $mensaje;
		break;
		case 'newMultimedia': 
			$tipo = $_POST['tipo'];
			$video = $_POST['video'];
			$tamano = $_POST['tam'];
			if($tipo == "VIDEO"){
				$c00 = "INSERT INTO multimedia VALUES(default, now(), '".$video."', '".$tipo."', 'ACTIVO');";
				$insertVideo = $DB->consulta($c00);
				$uploadOk = 1;
				$mensaje = "El Archivo ha sido subido correctamente.";
			}else{
				for($i = 0; $i < $tamano; $i++){
					$uploadOk = 1;
					$mensaje = "El Archivo ha sido subido correctamente.";
					$img = $_FILES["file".$i.""]["name"];
					if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_FILES["file".$i.""]["type"])){
						$target_dir = "../../img/multimedia/";
						$carpeta=$target_dir;
						if (!file_exists($carpeta)) {
							mkdir($carpeta, 0777, true);
						}
						$target_file = $carpeta . basename($_FILES["file".$i.""]["name"]);
						$uploadOk = 1;
						$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
						// Check file size
						if ($_FILES["file".$i.""]["size"] > 524288) {
							$mensaje = "Lo sentimos, el archivo es demasiado grande.  Tamaño máximo admitido: 0.5 MB";
							$uploadOk = 0;
						}else{
							if( $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" ) {
								$mensaje = "Lo sentimos, sólo archivos PNG & ICO  son permitidos.";
								$uploadOk = 0;
							}else{
								if (move_uploaded_file($_FILES["file".$i.""]["tmp_name"], $target_file)) {
									$c00 = "INSERT INTO multimedia VALUES(default, now(), '".$img."', '".$tipo."', 'ACTIVO');";
									$insertImg = $DB->consulta($c00);
									$mensaje = "El Archivo ha sido subido correctamente.";
								} else {
									$mensaje = "Lo sentimos, hubo un error subiendo el archivo.";
								}
							}
						}
					}
				}
			}
			$resultado["subido"] = $uploadOk;
			$resultado["mensaje"] = $mensaje;
			$resultado["img"] = $img;
		break;
		
	
	}
	
	$DB->commit();
    $DB->close();
    Response::sendOne($resultado);
	
} catch (Exception $e) {
	$DB->rollback();
    $DB->close();
    Response::sendError($e);
}
?>
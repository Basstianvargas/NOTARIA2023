<?php
session_start(); 
date_default_timezone_set("America/La_Paz"); 
header('Content-Type: text/html; charset=UTF-8');  
include "../api.php";
try {
	
    $body = Response::getBody();
	/* ---------------------------------------------------- */
    $DB = new DB();
    $DB->conectar();
    $DB->begin();
	/* ---------------------------------------------------- */
	$fechareg= date("Y-m-d H:i:s");
	$newfecha = date("Y-m-d");
	$newhora = date("G:i:s");	
	$funcion = $body["funcion"];

	switch($funcion) {
		/* --------------------- Empresa ---------------------------- */
		case 'editEmpresa': 
			$c00 = "SELECT * from empresa where id_empresa='1'";
			$empresa = $DB->consultaOne($c00);
			$c01 = "SELECT * from sucursal where id_sucursal='1'";
			$sucursal = $DB->consultaOne($c01);
			$resultado = array();
			$resultado["empresa"] = $empresa;
			$resultado["sucursal"] = $sucursal;
		break;
		case 'updEmpresa': 
			$id = '1';  
			$empresa = $body["empresa"]; 
			$sigla = $body["sigla"];
			$responsable = $body["responsable"]; 
			$email = $body["email"];
			$telefono = $body["telf"]; 
			$celular = $body["cel"];
			
			$c00 = "UPDATE empresa set empresa = '".$empresa."', sigla = '".$sigla."' WHERE id_empresa = '".$id."';";
			$updEmpresa = $DB->consulta($c00);
			
			$c01 = "UPDATE sucursal  set empresa = '".$empresa."', responsable = '".$responsable."', email = '".$email."', telefono = '".$telefono."', celular = '".$celular."' WHERE id_sucursal = '".$id."';";
			$updSucursal = $DB->consulta($c01);
			
			$resultado = array();
			$resultado["ok"] = $updEmpresa;
		break;
		case 'updEmpresaIns': 
			$id = $body["idemp"];  
			$mision = $body["mision"]; 
			$vision = $body["vision"];
			$objeto = $body["objeto"];
			
			$c00 = "UPDATE empresa set mision = '".$mision."', vision = '".$vision."', objeto = '".$objeto."' WHERE id_empresa = '".$id."';";
			$updEmpresa = $DB->consulta($c00);
			
			$resultado = array();
			$resultado["ok"] = $updEmpresa;
		break;
		case 'updEmpresaRedes': 
			$id = $body["idemp"];  
			$facebook = $body["facebook"]; 
			$instagram = $body["instagram"];
			$twitter = $body["twitter"];
			$linkedin = $body["linkedin"];
			
			$c00 = "UPDATE empresa set facebook = '".$facebook."', instagram = '".$instagram."', twitter = '".$twitter."', linkedin = '".$linkedin."' WHERE id_empresa = '".$id."';";
			$updEmpresa = $DB->consulta($c00);
			
			$resultado = array();
			$resultado["ok"] = $updEmpresa;
		break;
		case 'updDireccion': 
			$id = $body["idemp"];  
			$latitud = $body["latitud"]; 
			$longitud = $body["longitud"];  
			$direccion = $body["direccion"];
			$pais = $body["pais"];
			$ciudad = $body["ciudad"];
			$localidad = $body["localidad"];
			
			$c01 = "UPDATE sucursal set latitud = '".$latitud."', longitud = '".$longitud."', direccion = '".$direccion."', pais = '".$pais."', ciudad = '".$ciudad."', localidad = '".$localidad."' WHERE id_sucursal = '".$id."';";
			$updSucursal = $DB->consulta($c01);
			
			$resultado = array();
			$resultado["ok"] = $updSucursal;
		break;
		/* --------------------- Gestiones  ---------------------------- */
		case 'listarGestion': 
			$c00 = "SELECT * from gestion";
			$gestiones = $DB->consultaAll($c00);
			$resultado = array();
			$resultado["gestiones"] = $gestiones;
		break;
		case 'newGestion':
			$gestion = $body["gestion"];
			$inicio = $body["inicio"];
			$fin = $body["fin"];
			
			$c00 = "UPDATE gestion set estado='INACTIVO' WHERE 1 ";
			$updGestion = $DB->consulta($c00);
			
			$c01 = " INSERT INTO gestion values(default,'".$gestion."','".$inicio."','".$fin."','ACTIVO');";
			$insertGestion= $DB->consulta($c01);
			
			$resultado = array();
			$resultado["ok"] = $insertGestion;
		break;
		case 'editGestion': 
			$id = $body["idgestion"]; 
			$c00 = "SELECT * from gestion where id_gestion='".$id."'";
			$gestion = $DB->consultaOne($c00);
			$resultado = array();
			$resultado["gestion"] = $gestion;
		break;
		case 'updGestion': 
			$id = $body["idgestion"];
			$gestion = $body["gestion"];
			$inicio = $body["inicio"];
			$fin = $body["fin"];		
			
			$c00 = "UPDATE gestion set gestion='".$gestion."', inicio = '".$inicio."', fin = '".$fin."' WHERE id_gestion = '".$id."';";
			$updGestion = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updGestion;
		break;
		case 'cambiarEstadoGestion': 
			$id = $body["id"];  
			$estado = $body["estado"]; 
			$campo = $body["campo"];
			if($estado=='A'){$nestado='INACTIVO';}else{$nestado='ACTIVO';}
			
			$c00 = "UPDATE gestion set ".$campo." = '".$nestado."' WHERE id_gestion = '".$id."';";
			$updEstado = $DB->consulta($c00);
			$resultado = array();
			$resultado["ok"] = $updEstado;
		break;
		
	}

	$DB->commit();
    $DB->close();
    Response::sendOne($resultado);
	
} catch (Exception $e) {
	$DB->rollback();
    $DB->close();
    Response::sendError($e);
}
?>
<?php

/**
 * Class DB
 * Solo para tablas del tipo INNODB
 * Esta Clase no puede aplicarse a tipos de tablas no transaccionales (como MyISAM o ISAM).
 */
class DB
{
    private $host;
    private $user;
    private $password;
    private $database;
    private $link;
    
    public function DB($host = "localhost", $user = "root", $password = "", $database = "sistema_notaria")
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->database = $database;
    }
    
    public function conectar()
    {
        $this->link = new mysqli($this->host, $this->user, $this->password, $this->database);
        if (mysqli_connect_errno()) {
            throw new Exception('[DB error] la conexión a la base de datos fallo');
        }
        _log("[sql] conectar", "sql.log", true);
    }
    
    public function consultaAll($consultaSql, $close = false)
    {
        $resultado = array();
        $coleccionDeDatos = array();
        $resultadoConsulta = $this->consulta($consultaSql, $close);
        while ($dato = $this->convertirAObjeto($resultadoConsulta)) {
            array_push($coleccionDeDatos, $dato);
        }
        $resultado["size"] = $this->obtenerNumeroFilas($resultadoConsulta);
        $resultado["data"] = $coleccionDeDatos;
        return $resultado;
    }
    
    public function consultaOne($consultaSql, $close = false)
    {
        return $this->convertirAObjeto($this->consulta($consultaSql, $close));
    }
    
    public function consulta($consultaSql)
    {
        _log('[sql] ' . $consultaSql, "sql.log", true);;
        if ($resultadoConsulta = mysqli_query($this->link, $consultaSql)) {
            return $resultadoConsulta;
        } else {
            $errorSql = mysqli_error($this->link);
            _log('[DB error] ' . $errorSql, "sql.log");
            throw  new Exception('[DB error: ' . $errorSql . ' ] sql: ' . $consultaSql, 500);
        }
    }
    
    public function convertirAObjeto($variable)
    {
        return mysqli_fetch_object($variable);
    }
    
    public function obtenerNumeroFilas($resultadoConsulta)
    {
        $resultado = mysqli_num_rows($resultadoConsulta);
        if ($resultado === false) {
            throw  new Exception('[DB error: Error al recuperar numero de filas ] ', 500);
        } else {
            return $resultado;
        }
    }
    
    public function obtenerNumeroColumnas($resultadoConsulta)
    {
        if ($resultado = $resultadoConsulta->field_count) {
            return $resultadoConsulta->field_count;
        } else {
            throw new Exception('[DB error: Error al recuperar numero de columnas ] ', 500);
        }
    }
    
    public function obtenerFila($reulstadoConsulta, $opcion = MYSQLI_NUM)
    {
        if ($fila = mysqli_fetch_array($reulstadoConsulta, $opcion)) {
            return $fila;
        } else {
            throw new Exception('[DB error: Error al recuperar fila ] ', 500);
        }
    }
    
    public function begin()
    {
        mysqli_autocommit($this->link, FALSE);
        _log("[sql] begin", "sql.log", true);
    }
    
    public function commit()
    {
        mysqli_commit($this->link);
        _log("[sql] commit", "sql.log", true);
    }
    
    public function rollback()
    {
        mysqli_rollback($this->link);
        _log("[sql] rollback", "sql.log");
    }
    
    public function close()
    {
        mysqli_close($this->link);
        _log("[sql] close", "sql.log", true);
    }
    
}

class UpdateSql
{
    private $nombreTabla;
    private $set;
    private $condicion;
    
    public function UpdateSql($nombreTabla = "")
    {
        $this->nombreTabla = $nombreTabla;
        $this->set = "";
        $this->where = "";
    }
    
    public function setTabla($nombreTabla = "")
    {
        $this->nombreTabla = $nombreTabla;
        return $this;
    }
    
    public function update($objeto = null)
    {
        $resultado = "";
        foreach ($objeto as $clave => $valor) {
            if ($resultado == "") {
                $resultado = " SET $clave = '$valor' ";
            } else {
                $resultado = $resultado . ", $clave = '$valor' ";
            }
        }
        $this->set = $resultado;
        return $this;
    }
    
    public function where($condicion = "")
    {
        $this->condicion = " WHERE " . $condicion;
        return $this;
    }
    
    public function toString()
    {
        return "UPDATE $this->nombreTabla $this->set $this->condicion";
    }
}

class InsertSql
{
    
    private $nombreTabla;
    private $campos;
    private $valores;
    
    public function InsertSql($nombreTabla = "")
    {
        $this->nombreTabla = $nombreTabla;
        $this->campos = array();
        $this->valores = array();
    }
    
    public function setTabla($nombreTabla)
    {
        $this->nombreTabla = $nombreTabla;
        return $this;
    }
    
    public function clear()
    {
        $this->nombreTabla = "";
        $this->campos = array();
        $this->valores = array();
        return $this;
    }
    
    public function insert($campo, $valor = "_undefined")
    {
        if ($valor <> "_undefined") {
            array_push($this->campos, $campo);
            array_push($this->valores, $valor);
        }
        return $this;
    }
    
    public function reset($nombreTabla = "")
    {
        $this->clear();
        $this->setTabla($nombreTabla);
        return $this;
    }
    
    public function toString()
    {
        $textoCampos = "(";
        $textoValores = "(";
        $catidadInserciones = count($this->campos);
        $error = "";
        for ($i = 0; $i < $catidadInserciones; ++$i) {
            if (!isset($this->valores[$i])) {
                $error = $error . "," . $this->campos[$i];
                $this->valores[$i] = "undefined";
            }
            if ($i == 0) {
                $textoCampos = $textoCampos . $this->campos[$i];
                $textoValores = $textoValores . "'" . $this->valores[$i] . "'";
            } else {
                $textoCampos = $textoCampos . "," . $this->campos[$i];
                $textoValores = $textoValores . ",'" . $this->valores[$i] . "'";
            }
            
        }
        $textoCampos = $textoCampos . ")";
        $textoValores = $textoValores . ")";
        $result = "INSERT INTO " . $this->nombreTabla . " " . $textoCampos . " VALUES " . $textoValores;
        if ($error <> "") {
            throw new Exception("[DB error] la consulta: " . $result . ", tiene las siguientes variables no definidas: " . $error, 500);
        }
        return $result;
    }
    
}



<?php
include "../Response.php";
include "../DB.php";
try {
    
    
    $metodo = Response::getMetodo();
    $arr = Response::getParamas();
    $query = Response::getQuery();
    $respuesta = array();
    $respuesta['metodo'] = $metodo;
    $respuesta['parametros'] = $arr;
    $respuesta['query'] = $query;

    Response::sendOne($respuesta);
} catch (Exception $e) {
    Response::sendError($e);
}


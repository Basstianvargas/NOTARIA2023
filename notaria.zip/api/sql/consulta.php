<?php
include "../api.php";
try {
    $DB = new DB();
    $DB->conectar();
    $body = Response::getBody();
    if ($body["tipo"] == "all") {
        Response::sendAll($DB->consultaAll($body["sql"], true));
    } else {
        Response::sendOne($DB->consultaOne($body["sql"], true));
    }
} catch (Exception $e) {
    Response::sendError($e);
}


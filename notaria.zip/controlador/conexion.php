<?php
	function Conectar()
	{
		$host = 'localhost';
	    $user = 'root';
	    $password = '';
		$conn = mysqli_connect($host, $user, $password) or die('error de conexion ');
		mysqli_select_db($conn, 'sistema_notaria') or die('Error en base de datos');
	    mysqli_set_charset($conn, 'utf-8');
		return $conn;	
	}
	function Desconectar($conn)
	{
		mysqli_close($conn);
	}
?>

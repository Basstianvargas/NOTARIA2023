<!DOCTYPE html>
<html>
<head>
    <?php
		include('includes/cabecera.inc');
	?>
	<style> 
		.select2-dropdown {
		  z-index: 9001;
		}
	</style>
</head>
<body class="pace-done mini-navbar skin-3">
    <div id="wrapper">
		<?php
			include('includes/menu_izq.inc');
		?>
        <div id="page-wrapper" class="gray-bg">
			<div class="row border-bottom">
				<?php
					include('includes/menu_top.inc');
				?>
			</div>
			<div class="row wrapper border-bottom white-bg page-heading">
				<div class="col-lg-12">
					<br>
					<ol class="breadcrumb">
						<li>
							<a href="home">Inicio</a>
						</li>
						<li class="active">
							<strong> Perfil Empresa </strong>
						</li>
					</ol>
				</div>
			</div>
			<div class="wrapper wrapper-content ">
				<div class="row">
					<div class="col-lg-12">
						<div class="ibox float-e-margins">
							<div class="ibox-title">
								<h5>Sucursal : <b id='nomSucursal'></b></h5>
								<div class="ibox-tools">
								</div>
							</div>	
						</div>
						<div class="ibox float-e-margins">
							<div class="tabs-container">
								<ul class="nav nav-tabs">
									<li class="active "><a id="tabempresa" href="#tab-1" onclick="cargarDatosEmpresa();" ><label class="text-navy" > <i class="fa fa-briefcase"></i> Empresa </a></label></li>
									<li><a id="tabdatos" href="#tab-2" onclick="cargarDatosInstitucion();"><label class="text-navy" ><i class="fa fa-bank"></i> Datos Institucionales </a></label></li>	
									<li><a id="tabgestion" href="#tab-3" onclick="cargarDatosGestion();"><label class="text-navy" ><i class="fa fa-calendar"></i> Datos Gestion </a></label></li>	
								</ul>
								<div class="tab-content">
									<div id="tab-1" class="tab-pane active" style="font-size:11px;">
										<div class="ibox-content">
											<div class="row">
												<div class="col-md-5">
													<div class="ibox ">
														<div class="col-md-6">
															<div class="ibox-title">
																<h5>ICONO</h5>
																<div class="ibox-tools">
																	<button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#updIco">
																		<i class="fa fa-camera" aria-hidden="true"></i>
																	</button>
																</div>
															</div>
															<div class="ibox-content  ">
																<center>
																	<img alt="image" class="img-thumbnail" width="100px" src="" id="icoemp">
																	<h6><p>Tamaño máximo de archivo: 500 KB.</p><p> Formatos aceptados: ICO </p><p> Fotografia con dimensiones Iguales. </p></h6>
																</center>
															</div>
														</div>
														<div class="col-md-6">
															<div class="ibox-title">
																<h5>LOGO</h5>
																<div class="ibox-tools">
																	<button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#updLogo">
																		<i class="fa fa-camera-retro" aria-hidden="true"></i>
																	</button>
																</div>
															</div>
															<div class="ibox-content  ">
																<center>
																	<img alt="image" class="img-thumbnail" width="200px" src="" id="logemp">
																	<h6><p>Tamaño máximo de archivo: 2Mb.</p><p> Formatos aceptados: JPG / PNG. </p><p> Fotografia con dimensiones Iguales. </p></h6>
																</center>
															</div>
														</div>
														
													</div>
												</div>
												<div class="col-md-7">
													<div class="ibox ">
														<div class="ibox-title">
															<h5>Contacto</h5>
															<div class="ibox-tools">
																<button type="button" class="btn btn-warning btn-xs" title="Editar Ubicacion" onclick="editarDireccion();" id="btnubi" >
																	<i class="fa fa-map-marker"></i>
																</button>
																<button class="btn btn-info btn-xs" style="display:none" title="Guardar Datos" onclick="guardarDatos();" id="btnguardar" >
																	<i class="fa fa-save" aria-hidden="true"></i>
																</button>
																<button class="btn btn-success btn-xs" title="Editar Datos" onclick="habilitarDatos();" id="btneditar">
																	<i class="fa fa-edit" aria-hidden="true"></i>
																</button>
															</div>
														</div>
														<div class="ibox-content ">
															<div class="form-group row">
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Empresa:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled id="demp" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-briefcase text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Sigla:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="dsig" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-coffee text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Responsable:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="dres" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-user-circle  text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Email:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="demail" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-envelope text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Telefono:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="dtelf" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-phone text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Celular:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="dcel" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-mobile text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div id="tab-2" class="tab-pane" style="font-size:11px;">
										<div class="ibox-content">
											<div class="row">
												<div class="col-md-6">
													<div class="ibox-title">
														<h5> Institucion </h5>
														<div class="ibox-tools">
															<button class="btn btn-info btn-xs" style="display:none" title="Guardar Datos" onclick="guardarDatosIns();" id="btng" >
																<i class="fa fa-save" aria-hidden="true"></i>
															</button>
															<button class="btn btn-success btn-xs" title="Editar Datos" onclick="habilitarDatosIns();" id="btne">
																<i class="fa fa-edit" aria-hidden="true"></i>
															</button>
														</div>
													</div>
													<div class="ibox-content">
														<div class="form-horizontal form-label-left" >	
															<div class="form-group">  
															  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Quienes Somos:
															  </label>
															  <div class="col-md-9 col-sm-9 col-xs-12">
																<textarea id="qsomos" disabled class="form-control insti col-md-7 col-xs-12"></textarea>
															  </div>
															</div>
															<div class="form-group">  
															  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Mision:
															  </label>
															  <div class="col-md-9 col-sm-9 col-xs-12">
																<textarea id="mision" disabled class="form-control insti  col-md-7 col-xs-12"></textarea>
															  </div>
															</div>
															<div class="form-group">  
															  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Vision:
															  </label>
															  <div class="col-md-9 col-sm-9 col-xs-12">
																<textarea id="vision" disabled class="form-control insti col-md-7 col-xs-12"></textarea>
															  </div>
															</div>
																										
														</div>		
													</div>
												</div>
												<div class="col-md-6">
													<div class="ibox-title">
														<h5> Redes Sociales </h5>
														<div class="ibox-tools">
															<button class="btn btn-info btn-xs" style="display:none" title="Guardar Datos" onclick="guardarDatosRedes();" id="btngred" >
																<i class="fa fa-save" aria-hidden="true"></i>
															</button>
															<button class="btn btn-success btn-xs" title="Editar Datos" onclick="habilitarDatosRedes();" id="btnered">
																<i class="fa fa-edit" aria-hidden="true"></i>
															</button>
														</div>
													</div>
													<div class="ibox-content">
														<div class="row" style="margin:15px" >
															<label class="control-label col-md-3 col-sm-3 col-xs-12" > Facebook:
															</label>
															<div class="col-md-9 col-sm-9 col-xs-12">
																<div class="input-group">
																  <input type="text" disabled id="face" class="form-control input-sm redes"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm btn-facebook"><i class="fa fa-facebook"></i></button></span>
																</div>
															</div>
														</div>
														<div class="row" style="margin:15px" >
															<label class="control-label col-md-3 col-sm-3 col-xs-12" > Instagram:
															</label>
															<div class="col-md-9 col-sm-9 col-xs-12">
																<div class="input-group">
																  <input type="text" disabled  id="insta" class="form-control input-sm redes"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm btn-instagram"><i class="fa fa-instagram"></i></button></span>
																</div>
															</div>
														</div>
														<div class="row" style="margin:15px" >
															<label class="control-label col-md-3 col-sm-3 col-xs-12" > Twitter:
															</label>
															<div class="col-md-9 col-sm-9 col-xs-12">
																<div class="input-group">
																  <input type="text" disabled id="twitter" class="form-control input-sm redes"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm btn-twitter"><i class="fa fa-twitter"></i></button></span>
																</div>
															</div>
														</div>
														<div class="row" style="margin:15px" >
															<label class="control-label col-md-3 col-sm-3 col-xs-12" > Linkedin:
															</label>
															<div class="col-md-9 col-sm-9 col-xs-12">
																<div class="input-group">
																  <input type="text" disabled  id="linkedin" class="form-control input-sm redes"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm btn-linkedin"><i class="fa fa-linkedin"></i></button></span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div id="tab-3" class="tab-pane" style="font-size:11px;">
										<div class="ibox-content">
											<div class="row">
												<div class="col-md-12">
													<div class="ibox-title">
														<h5> Gestiones </h5>
														<div class="ibox-tools">
															<button class="btn btn-primary btn-xs" title="Nueva Gestion" data-toggle="modal" data-target="#newGestion">
																<i class="fa fa-plus" aria-hidden="true"></i>
															</button>
														</div>
													</div>
													<div class="ibox-content">
														<div class="ibox table-responsive" style="font-size:10px; max-height: 500px; ">
															<table class="table table-striped table-bordered table-hover lisgestion">
															</table>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="updLogo" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-camera"></i> Actualizar Logo</h4>
							<small>Actualizar Logo de la empresa</small>
						</div>
						<div class="modal-body">
							<div class="row">
								<form  method="post" action="" enctype="multipart/form-data" id="logoForm">
									
									<div class="col-md-8 col-sm-8 col-xs-12">
										<input type="file" onchange="vistaPreviaLogo(this);" id="newLogo" class="form-control">
										<input type="hidden"  id="updid" class="form-control col-md-7 col-xs-12">
									</div>
									<div class="col-md-4 col-sm-4 col-xs-12" id="logoAnt">
										<center><img alt="image" class="img-thumbnail" id="imglogo" width="100px" src=""></center>
									</div>
								</form>
							</div>
							
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button onclick="updLogoEmpresa();" type="submit" class="btn btn-success btn-sm" ><i class="fa fa-refresh"></i> Actualizar Datos</button>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="updIco" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-camera"></i> Actualizar Icono</h4>
							<small>Actualizar Icono de la empresa</small>
						</div>
						<div class="modal-body">
							<div class="row">
								<form  method="post" action="" enctype="multipart/form-data" id="icoForm">
									
									<div class="col-md-8 col-sm-8 col-xs-12">
										<input type="file" onchange="vistaPreviaIco(this);" id="newIco" class="form-control">
									</div>
									<div class="col-md-4 col-sm-4 col-xs-12" id="icoAnt">
										<center><img alt="image" class="img-thumbnail" id="imgico" width="100px" src=""></center>
									</div>
								</form>
							</div>
							
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button onclick="updIcoEmpresa();" type="submit"  class="btn btn-success btn-sm" ><i class="fa fa-refresh"></i> Actualizar Datos</button>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="editDireccion" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-map-marker"></i> Editar Direccion</h4>
							<small>Edita la direccion Actual de su Empresa.</small>
						</div>
						<div class="modal-body">
							<div class="row">
								<div class="col-md-6">
									<div class="ibox ">
										<div class="ibox-title">
											<h5>Mapa</h5>
										</div>
										<div class="ibox-content  ">
											<center>
												<div id="myMap" style="height: 400px"></div>
												<h6><p> <i class="fa fa-info text-navy"></i> Mueva el marcador y seleccione su direccion exacta</p></h6>
											</center>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="ibox ">
										<div class="ibox-title">
											<h5>Datos Direccion</h5>
										</div>
										<div class="ibox-content ">
											<div class="form-group row">
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Direccion:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <input type="text" id="dirmap" class="form-control input-sm"  ><span class="input-group-btn"> <button type="button"  style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-map-marker text-navy"></i></button></span>
														</div>
													</div>
												</div>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Pais:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <input type="text" id="paismap" value="BOLIVIA" class="form-control input-sm"  ><span class="input-group-btn"> <button type="button" style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-bank text-navy"></i></button></span>
														</div>
													</div>
												</div>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Ciudad:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <select class="form-control" style="width: 100%;" id="ciumap"><option value="COCHABAMBA">COCHABAMBA</option><option value="LA PAZ">LA PAZ</option><option value="SANTA CRUZ">SANTA CRUZ</option></select><span class="input-group-btn"> <button type="button" style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-building text-navy"></i></button></span>
														</div>
													</div>
												</div>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Localidad:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <input type="text" id="locmap" value="CERCADO" class="form-control input-sm"  ><span class="input-group-btn"> <button type="button" style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-crosshairs text-navy"></i></button></span>
														</div>
													</div>
												</div>	
												<input type="hidden"  id="latmapa" class="form-control">
												<input type="hidden"  id="lngmapa" class="form-control">
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
													<button onclick="updDireccion();" class="btn btn-success btn-sm" ><i class="fa fa-refresh"></i> Actualizar Datos</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>	
						</div>
					</div>
				</div>	
			</div>
			<div class="modal inmodal" id="newGestion" tabindex="-1" role="dialog" aria-hidden="true" >
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-plus"></i> Nueva Gestion</h4>
							<small> Registro de gestiones del sistema. </small>
						</div>
						<div class="modal-body">
							<div class="form-horizontal form-label-left">
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12"> Gestion:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text" id="nomges" class="form-control col-md-7 col-xs-12 gests">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12"> Fecha Inicio:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="date" id="iniges" class="form-control col-md-7 col-xs-12 gests">
								  </div>
								</div>
								
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12"> Fecha Fin:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="date" id="finges" class="form-control col-md-7 col-xs-12 gests">
								  </div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button onclick="newGestion();" class="btn btn-success btn-sm"><i class="fa fa-check"></i> Insertar Datos</button>
								</div>												
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="updGestion"  role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-edit"></i> Actualizar Gestion </h4>
							<small> Actualizar Datos de la Gestion </small>
						</div>
						<div class="modal-body">
							<div class="form-horizontal form-label-left" >
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12"> Gestion:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text" id="updnomges" class="form-control col-md-7 col-xs-12 gests">
									<input type="hidden" id="updidges" class="form-control col-md-7 col-xs-12 gests">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12"> Fecha Inicio:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="date" id="updiniges" class="form-control col-md-7 col-xs-12 gests">
								  </div>
								</div>
								
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12"> Fecha Fin:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="date" id="updfinges" class="form-control col-md-7 col-xs-12 gests">
								  </div>
								</div>
																	
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button onclick="updGestion();" class="btn btn-success btn-sm" ><i class="fa fa-refresh"></i> Actualizar Datos</button>
						</div>
					</div>
				</div>
			</div>
			<div class="footer">
				<?php
					include('includes/footer.inc');
				?>
			</div>
        </div>
    </div>	
    <?php
	include('includes/pie.inc');
	?>
	<script>		
		var ids = "<?php echo $ids;?>";
		var idu = "<?php echo $idu;?>";
		var idr = "<?php echo $idr;?>";
		var aps = "<?php echo $aps;?>";
		var nom = "<?php echo $nom;?>";
		var rol = "<?php echo $rol;?>";
		var ico = "<?php echo $ico;?>";
		var emp = "<?php echo $emp;?>";
		var foto = "<?php echo $foto;?>";
		var logo = "<?php echo $logo;?>";
		var nomSuc = "<?php echo $suc;?>";
		
		function initializer() {
			document.getElementById('nomSucursal').innerHTML = nomSuc;
			document.getElementById('nomUser').innerHTML = nom+' '+aps;
			document.getElementById('rolUser').innerHTML = rol;
			document.getElementById("fotousr").src="img/usuario/"+foto+"";
			cargarDatosEmpresa(); cargarDatosWeb(); 
		}
		
		function editarDireccion(){
			Empresa.showSpinner();
			var funcion = "editEmpresa";
			var body = { funcion: funcion};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					Empresa.hideSpinner();
					$("#editDireccion").modal("show");
					var sucursal = respuesta.sucursal;
					$("#updid").val(sucursal.ID_SUCURSAL);
					$("#paismap").val(sucursal.PAIS);
					$("#dirmap").val(sucursal.DIRECCION);
					$("#ciumap").val(sucursal.CIUDAD);
					$("#locmap").val(sucursal.LOCALIDAD);	
					
					mapboxgl.accessToken = 'pk.eyJ1IjoiYW5kcmVldXNkYiIsImEiOiJja2VrcTJ2M2YwZGRoMzFxeG1xYmtvcHJzIn0.eWdITbhyklGEVNiqeqphVw';
					var map = new mapboxgl.Map({
					container: 'myMap',
					style: 'mapbox://styles/mapbox/streets-v11',
					center: [sucursal.LONGITUD, sucursal.LATITUD],
					zoom: 15
					});
					 
					var marker = new mapboxgl.Marker({
					draggable: true
					})
					.setLngLat([sucursal.LONGITUD, sucursal.LATITUD])
					.addTo(map);
					 
					marker.on("dragend", function(e) {
						var lngLat = marker.getLngLat();
						$("#latmapa").val(lngLat.lat);
						$("#lngmapa").val(lngLat.lng);
					});	
				}
			});
			
		}
		function updDireccion(){
			Empresa.showSpinner();
			var idemp = document.getElementById("updid").value;
			var latitud = document.getElementById("latmapa").value;
			var longitud = document.getElementById("lngmapa").value;
			var direccion = document.getElementById("dirmap").value;
			var pais = document.getElementById("paismap").value;
			var ciudad = document.getElementById("ciumap").value;
			var localidad = document.getElementById("locmap").value;
			if(direccion === ""){
				$('#dirmap').val('').focus();
				Empresa.notificationWarning(" El campo direccion es obligatorio .");
				return;
			}
			var funcion = "updDireccion";
			var body = { funcion: funcion, latitud: latitud , longitud: longitud , direccion: direccion, pais: pais, ciudad: ciudad, localidad: localidad, idemp: idemp};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					Empresa.hideSpinner();
					$("#editDireccion").modal("hide");;
					Empresa.notificationInfo("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se ingreso el nuevo registro intente de nuevo por favor");
				}
			});
		}
		function cargarDatosEmpresa(){
			Empresa.showSpinner();
			$('#tabempresa').tab('show');
			var funcion = "editEmpresa";
			var body = { funcion: funcion};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					var empresa = respuesta.empresa;
					var sucursal = respuesta.sucursal;
					Empresa.hideSpinner();
					$("#updid").val(empresa.ID_EMPRESA);
					$("#demp").val(empresa.EMPRESA);
					$("#dsig").val(empresa.SIGLA);
					$("#mision").val(empresa.MISION);
					$("#vision").val(empresa.VISION);
					$("#qsomos").val(empresa.OBJETO);
					$("#face").val(empresa.FACEBOOK);
					$("#insta").val(empresa.INSTAGRAM);
					$("#twitter").val(empresa.TWITTER);
					$("#linkedin").val(empresa.LINKEDIN);
					$("#dres").val(sucursal.RESPONSABLE);
					$("#dtelf").val(sucursal.TELEFONO);
					$("#demail").val(sucursal.EMAIL);
					$("#dcel").val(sucursal.CELULAR);
					$("#logemp").attr("src","img/empresa/"+empresa.LOGO+"");
					$("#imglogo").attr("src","img/empresa/"+empresa.LOGO+"");
					$("#icoemp").attr("src","img/empresa/"+empresa.ICONO+"");
					$("#imgico").attr("src","img/empresa/"+empresa.ICONO+"");
				}
			});
		}
		function vistaPreviaLogo(input) {
			$('#logoAnt').hide(); 
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('#logoForm + div').remove();
					$('#logoForm').after('<div class="col-md-4 col-sm-4 col-xs-12"><center><img alt="image" class="img-thumbnail" width="100px" src="'+e.target.result+'"></center></div>');
				};
				reader.readAsDataURL(input.files[0]);
			}
		}
		function updLogoEmpresa(){	
			Empresa.showSpinner();
			var inputFileImage = document.getElementById("newLogo");
			var idemp = document.getElementById("updid").value;
			var file = inputFileImage.files[0];
			var archivo = file.name;
			var data = new FormData();
			var funcion = "updLogoEmpresa";
			data.append('newLogo',file);data.append('idemp',idemp);data.append('funcion',funcion);
			Empresa.restImg({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesArchivosEmpresa.php"),
				data: data, 
				funcionExito: function (respuesta) {
					Empresa.hideSpinner();
					var subido = respuesta.subido; var msj = respuesta.mensaje;
					if(subido==1){
						$("#updLogo").modal("hide");
						$("#newLogo").val("");
						Empresa.notificationSuccess(msj);
						cargarDatosEmpresa();
					}else{
						Empresa.notificationError(msj);
					}
				}
			});			
		}
		function vistaPreviaIco(input) {
			$('#icoAnt').hide(); 
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('#icoForm + div').remove();
					$('#icoForm').after('<div class="col-md-4 col-sm-4 col-xs-12"><center><img alt="image" class="img-thumbnail" width="100px" src="'+e.target.result+'"></center></div>');
				};
				reader.readAsDataURL(input.files[0]);
			}
		}
		function updIcoEmpresa(){	
			Empresa.showSpinner();
			var inputFileImage = document.getElementById("newIco");
			var idemp = document.getElementById("updid").value;
			var file = inputFileImage.files[0];
			var archivo = file.name;
			var data = new FormData();
			var funcion = "updIcoEmpresa";
			data.append('newIco',file);data.append('idemp',idemp);data.append('funcion',funcion);
			Empresa.restImg({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesArchivosEmpresa.php"), 
				data: data, 
				funcionExito: function (respuesta) {
					Empresa.hideSpinner();
					var subido = respuesta.subido; var msj = respuesta.mensaje;
					if(subido==1){
						$("#updIco").modal("hide");
						$("#newIco").val("");
						Empresa.notificationSuccess(msj);
						cargarDatosEmpresa();
					}else{
						Empresa.notificationError(msj);
					}
				}
			});			
		}
		function habilitarDatos() {
			$('#btneditar').hide(); $('#btnguardar').show();
			Empresa.habilitarCampos("edit");
		}
		function guardarDatos() {
			Empresa.showSpinner();
			$('#btnguardar').hide(); $('#btneditar').show();
			var idemp = document.getElementById("updid").value;
			var empresa = document.getElementById("demp").value;
			var sigla = document.getElementById("dsig").value;
			var responsable = document.getElementById("dres").value;
			var email = document.getElementById("demail").value;
			var telf = document.getElementById("dtelf").value;
			var cel = document.getElementById("dcel").value;
			var funcion = "updEmpresa";
			var body = { funcion: funcion, idemp: idemp, empresa: empresa , sigla: sigla, responsable: responsable , email: email , telf: telf , cel: cel};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					cargarDatosEmpresa();
					Empresa.deshabilitarCampos("edit");
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se actualizo el registro intente de nuevo por favor");
				}
			});
		}
		// --------------------------- Gestiones  --------------
		function cargarDatosGestion(){
			$('#tabgestion').tab('show');
			Empresa.showSpinner();
			var columnsName = [{title: "#"},{title: "Gestion"},{title: "Fecha Inicio"},{title: "Fecha Fin"},{title: "Estado"},{title: "Editar"}];
			var lisgestion =[]; 
			var funcion = "listarGestion";
			var body = { funcion: funcion };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					var gestiones = respuesta.gestiones.data;
					for (var i = 0; i < gestiones.length; i++) {
						lisgestion.push([
							i+1,
							gestiones[i].GESTION,
							gestiones[i].FEC_INI,
							gestiones[i].FEC_FIN,
							Empresa.createButtonEstado(gestiones[i].ID_GESTION,gestiones[i].ESTADO,"Gestion","estado"),
							Empresa.createButtonsEdit(gestiones[i].ID_GESTION,"Gestion")
						]);
						
					}
					Empresa.inicializarTablaSinFormato({
						selector: ".lisgestion",
						data: lisgestion,
						columnas: columnsName
					});
					Empresa.refrescarTablaDeDatos({
						selector: ".lisgestion",
						data: lisgestion
					});
				}
			});
		}
		function newGestion(){
			Empresa.showSpinner();
			var gestion = document.getElementById("nomges").value;
			var inicio = document.getElementById("iniges").value;
			var fin = document.getElementById("finges").value;
			var funcion = "newGestion";
			var body = { funcion: funcion, gestion : gestion , inicio: inicio, fin: fin };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					$("#newGestion").modal("hide");
					$('.gests').val('');
					cargarDatosGestion();
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se ingreso correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se ingreso el nuevo registro intente de nuevo por favor");
				}
			});
		}
		function modalEditGestion(id){
			Empresa.showSpinner();
			var funcion = "editGestion";
			var body = { funcion: funcion , idgestion: id};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					var gestion = respuesta.gestion;
					Empresa.hideSpinner();
					$("#updGestion").modal("show");
					$("#updidges").val(gestion.ID_GESTION);
					$("#updnomges").val(gestion.GESTION);
					$("#updiniges").val(gestion.FEC_INI);
					$("#updfinges").val(gestion.FEC_FIN);

				},
				funcionError: function (e) {
					Empresa.hideSpinner();
				}
			});
		}
		function cambiarEstadoGestion(id,estado,campo){
			Empresa.showSpinner();
			var funcion = "cambiarEstadoGestion";
			var body = { funcion: funcion, id: id, estado: estado, campo: campo };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					Empresa.hideSpinner();
					cargarDatosGestion();
					Empresa.notificationSuccess("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se actualizo el registro intente de nuevo por favor");
				}
			});
		}
		function updGestion(){
			Empresa.showSpinner();
			var idgestion = document.getElementById("updidges").value;
			var gestion = document.getElementById("updnomges").value;
			var inicio = document.getElementById("updiniges").value;
			var fin = document.getElementById("updfinges").value;
			var funcion = "updGestion";
			var body = { funcion: funcion, gestion : gestion , inicio: inicio, fin: fin };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					$("#updGestion").modal("hide");
					$('.gests').val('');
					cargarDatosGestion();
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se ingreso el nuevo registro intente de nuevo por favor");
				}
			});
		}
		//---------------------------------- Tab quienes somos -----------------------------------
		function cargarDatosInstitucion(){
			$('#tabdatos').tab('show');
		}
		function habilitarDatosIns() {
			$('#btne').hide(); $('#btng').show();
			Empresa.habilitarCampos("insti");
		}
		function guardarDatosIns() {
			Empresa.showSpinner();
			$('#btng').hide(); $('#btn').show();
			var idemp = document.getElementById("updid").value;
			var mision = document.getElementById("mision").value;
			var vision = document.getElementById("vision").value;
			var objeto = document.getElementById("qsomos").value;
			var funcion = "updEmpresaIns";
			var body = { funcion: funcion, idemp: idemp, mision: mision , vision: vision, objeto: objeto };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					cargarDatosEmpresa();cargarDatosInstitucion();
					Empresa.deshabilitarCampos("insti");
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se actualizo el registro intente de nuevo por favor");
				}
			});
		}
		function habilitarDatosRedes() {
			$('#btnered').hide(); $('#btngred').show();
			Empresa.habilitarCampos("redes");
		}
		function guardarDatosRedes() {
			Empresa.showSpinner();
			$('#btngred').hide(); $('#btnered').show();
			var idemp = document.getElementById("updid").value;
			var facebook = document.getElementById("face").value;
			var instagram = document.getElementById("insta").value;
			var twitter = document.getElementById("twitter").value;
			var linkedin = document.getElementById("linkedin").value;
			var funcion = "updEmpresaRedes";
			var body = { funcion: funcion, idemp: idemp, facebook: facebook , instagram: instagram, twitter: twitter , linkedin: linkedin};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/empresa/funcionesEmpresa.php"),
				data: body,
				funcionExito: function (respuesta) {
					cargarDatosEmpresa();cargarContacto();
					Empresa.deshabilitarCampos("redes");
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se actualizo el registro intente de nuevo por favor");
				}
			});
		}
		this.initializer();		
	</script>
</body>
</html>

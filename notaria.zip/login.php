<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title id="nombreempresa"></title>
	<link rel="shortcut icon" id="iconoempresa" href="" />

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg skin-2">

    <div class="middle-box text-center loginscreen ">
        <div>
			<div class='m-t' id='inilog'>
				<img class='logo-name' width='100%' id="logoempresa" src=''>
			</div>
			<h3>OLVIDE MI CONTRASEÑA</h3>
			<div class="m-t" role="form" >
                <div class="form-group">
					<input type="text" class="form-control"  id="mail" placeholder="Correo Electronico" />
                </div>
                <button class="btn btn-info block full-width m-b" onclick="recuperarContraseña()"><i class='fa fa-send'></i> Recuperar Contraseña </button>
            </form>
            <p class="m-t"> <small><a href="#"> Derechos Reservados &copy; 2023 </a> </small> </p>
        </div>
    </div>
	<footer>
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/empresa.js"></script>
	</footer>
</body>
<script>
    function recuperarContraseña(){
        var funcion = "recuperarContrasena";
        var mail = document.getElementById("mail").value;
        
        var body = {funcion: funcion , mail: mail};
        Empresa.rest(
        {
            verbo: 'POST',
			url: Empresa.armarUrl("api/usuario/funcionesUsuarios.php"),
			data: body,
            funcionExito: function (respuesta) 
            {
                
                Empresa.notificationSuccess("Se Envio un correo para recuperar Contraseña"); 
            }
        })
    }

	this.cargarDatosWeb();	
</script>
</html>

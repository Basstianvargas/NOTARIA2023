<!DOCTYPE html>
<html>
<head>
    <?php
		include('includes/cabecera.inc');
	?>
</head>
<body class="pace-done mini-navbar skin-3 ">
    <div id="wrapper">
		<?php
			include('includes/menu_izq.inc');
		?>
        <div id="page-wrapper" class="gray-bg">
			<div class="row border-bottom">
				<?php
					include('includes/menu_top.inc');
				?>
			</div>
			<div class="row wrapper border-bottom white-bg page-heading">
				<div class="col-lg-12">
					<br>
					<ol class="breadcrumb">
						<li class="active">
							<a href="home">Inicio</a>
						</li>
					</ol>
				</div>
			</div>
			<div class="wrapper wrapper-content ">
				<div class="row">
					<div class="col-lg-12">
						<div class="ibox float-e-margins">
							<div class="ibox-title">
								<h5>Sucursal : <b id='nomSucursal'></b></h5>
								<div class="ibox-tools">
								</div>
							</div>	
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-9" >
						<div class="ibox float-e-margins" >
							<div class="ibox-title" >
								<h5> Dashboard <small class="m-l-sm" > (<span id="rolusr"></span>) </small></h5>
							  
							</div>
						</div>
						<div class="ibox float-e-margins" style='margin-top:-15px;'>
							<div class="ibox-content" id="itemdash">
								<div class="row">
									<div class="col-lg-4">
										<div class="widget style1 bg-info">
											<div class="row">
												<div class="col-xs-4">
													<a style="color:white;" href="escritura"><i class="fa fa-edit fa-5x"></i></a>
												</div>
												<div class="col-xs-8 text-right"><span> Escrituras </span>
													<h2 class="font-bold" id="countesc">0</h2><small> Escrituras del mes. </small>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="widget style1 bg-success">
											<div class="row">
												<div class="col-xs-4">
													<a style="color:white;" href="certificado"><i class="fa fa-book fa-5x"></i></a>
												</div>
												<div class="col-xs-8 text-right"><span> Certificaciones</span>
													<h2 class="font-bold" id="countcer">0</h2><small> Certificaciones del mes.</small>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="widget style1 bg-primary">
											<div class="row">
												<div class="col-xs-4">
													<a style="color:white;" href=""><i class="fa fa-usd fa-5x"></i></a>
												</div>
												<div class="col-xs-8 text-right"><span> Recaudado</span>
													<h2 class="font-bold" id="totdinero">0</h2><small> Dinero recaudado Mes.</small>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-3" >
						<div class="ibox float-e-margins" >
							<div class="ibox-title" >
							  <h5> Calendario <small class="m-l-sm" > (Sistema) </small></h5>
							</div>
						</div>
						<div class="ibox float-e-margins" style='margin-top:-15px;'>
							<div class="ibox-content">
								<center> <div id="data_1"> </div></center>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer">
				<?php
					include('includes/footer.inc');
				?>
			</div>
        </div>
    </div>	
    <?php
		include('includes/pie.inc');
	?>
	<script>		
		var ids = "<?php echo $ids;?>";
		var idu = "<?php echo $idu;?>";
		var idr = "<?php echo $idr;?>";
		var aps = "<?php echo $aps;?>";
		var nom = "<?php echo $nom;?>";
		var rol = "<?php echo $rol;?>";
		var ico = "<?php echo $ico;?>";
		var emp = "<?php echo $emp;?>";
		var foto = "<?php echo $foto;?>";
		var logo = "<?php echo $logo;?>";
		var nomSuc = "<?php echo $suc;?>";
		
		function initializer() {
			document.getElementById('nomSucursal').innerHTML = nomSuc;
			document.getElementById('nomUser').innerHTML = nom+' '+aps;
			document.getElementById('rolUser').innerHTML = rol;
			document.getElementById('rolusr').innerHTML = rol;
			document.getElementById("fotousr").src="img/usuario/"+foto+"";
			cargarDatosWeb();
			$('#data_1').datepicker({
				todayHighlight: true
			});
		}
		
		this.initializer();		
	</script>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <?php
		include('includes/cabecera.inc');
	?>
	<style> 
		.select2-dropdown {
		  z-index: 9001;
		}
	</style>
</head>
<body class="pace-done mini-navbar skin-3 skin-2">
    <div id="wrapper">
		<?php
			include('includes/menu_izq.inc');
		?>
        <div id="page-wrapper" class="gray-bg">
			<div class="row border-bottom">
				<?php
					include('includes/menu_top.inc');
				?>
			</div>
			<div class="row wrapper border-bottom white-bg page-heading">
				<div class="col-lg-12">
					<br>
					<ol class="breadcrumb">
						<li>
							<a href="home">Inicio</a>
						</li>
						<li class="active">
							<strong> Perfil Usuario </strong>
						</li>
					</ol>
				</div>
			</div>
			<div class="wrapper wrapper-content ">
				<div class="row">
					<div class="col-lg-12">
						<div class="ibox float-e-margins">
							<div class="ibox-title">
								<h5>Sucursal : <b id='nomSucursal'></b></h5>
								<div class="ibox-tools">
								</div>
							</div>	
						</div>
						<div class="ibox float-e-margins">
							<div class="tabs-container">
								<ul class="nav nav-tabs">
									<li class="active "><a data-toggle="tab" href="#tab-1" ><label class="text-navy" > <i class="fa fa-user"></i> Perfil Usuario </a></label></li>
									<li><a id="tabdir" href="#tab-2" onclick="cargarDireccion();"><label class="text-navy" ><i class="fa fa-map-marker"></i> Direcciones</a></label></li>
									
								</ul>
								<div class="tab-content">
									
									<div id="tab-1" class="tab-pane active" style="font-size:11px;">
										<div class="ibox-content">
											<div class="row">
												<div class="col-md-5">
													<div class="ibox ">
														<div class="ibox-title">
															<h5>Foto</h5>
															<div class="ibox-tools">
																<button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#updFoto">
																	<i class="fa fa-camera" aria-hidden="true"></i>
																</button>
															</div>
														</div>
														<div class="ibox-content  ">
															<label class="control-label col-xs-6 text-navy" > <i class="fa fa-user"></i> <b id="nomusr"></b> </label>
															<label class="control-label col-xs-6 text-navy" > <i class="fa fa-users"></i> <b id="rolusr"></b>  </label><hr>
															<center>
																<img alt="image" class="img-thumbnail" width="200px" src="img/usuario/usr.png" id="imgport">
																<h6><p>Tamaño máximo de archivo: 2Mb.</p><p> Formatos aceptados: JPG / PNG. </p><p> Fotografia con dimensiones Iguales. </p></h6>
															</center>
														</div>
													</div>
												</div>
												<div class="col-md-7">
													<div class="ibox ">
														<div class="ibox-title">
															<h5>Perfil de Usuario</h5>
															<div class="ibox-tools">
																<button class="btn btn-info btn-xs" style="display:none" title="Guardar Datos" onclick="guardarDatos();" id="btnguardar" >
																	<i class="fa fa-save" aria-hidden="true"></i>
																</button>
																<button class="btn btn-success btn-xs" title="Editar Datos" onclick="habilitarDatos();" id="btneditar">
																	<i class="fa fa-edit" aria-hidden="true"></i>
																</button>
																<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#updPassword">
																	<i class="fa fa-unlock"></i>
																</button>
															</div>
														</div>
														<div class="ibox-content ">
															<div class="form-group row">
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Nombres:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled id="noms" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-user text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Apellidos:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="aps" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-users text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > CI:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="ci" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-vcard text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Genero:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <select class="form-control edit" disabled style="width: 100%;" id="selectgen"><option value="MASCULINO">MASCULINO</option><option value="FEMENINO">FEMENINO</option></select><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-child text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Fecha Nacimiento:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="date" disabled  id="fecnac" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-calendar text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Email:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="email" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-envelope text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Telefono:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="telf" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-phone text-navy"></i></button></span>
																		</div>
																	</div>
																</div>
																<div class="row" style="margin:15px" >
																	<label class="control-label col-md-3 col-sm-3 col-xs-12" > Celular:
																	</label>
																	<div class="col-md-9 col-sm-9 col-xs-12">
																		<div class="input-group">
																		  <input type="text" disabled  id="cel" class="form-control input-sm edit"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-mobile text-navy"></i></button></span>
																		</div>
																	</div>
																</div>												
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div id="tab-2" class="tab-pane" style="font-size:11px;">
										<div class="ibox-content">
											<div class="ibox-title">
												<h5> Direcciones </h5>
												<div class="ibox-tools">
													<button class="btn btn-primary btn-xs" title="Nueva Direccion" onclick="modalDireccion();">
														<i class="fa fa-plus" aria-hidden="true"></i>
													</button>
												</div>
											</div>
											<div class="ibox-content">
												<div class="row" id="diruser">
													
												</div>
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="updFoto" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-camera"></i> Actualizar Foto</h4>
							<small>Actualizar fotografia del Usuario</small>
						</div>
						<div class="modal-body">
							<div class="row">
								<form  method="post" action="" enctype="multipart/form-data" id="fotoForm">
									
									<div class="col-md-8 col-sm-8 col-xs-12">
										<input type="file" onchange="vistaPreviaFoto(this);" id="newFoto" class="form-control">
										<input type="hidden"  id="updid" class="form-control col-md-7 col-xs-12">
										<input type="hidden"  id="updusr" class="form-control col-md-7 col-xs-12">
									</div>
									<div class="col-md-4 col-sm-4 col-xs-12" id="fotoAnt">
										<center><img alt="image" class="img-thumbnail" id="imgmodal" width="100px" src="img/usuario/usr.png"></center>
									</div>
								</form>
							</div>
							
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button onclick="updFotoUser();" type="submit" form="CreateForm" class="btn btn-success btn-sm" ><i class="fa fa-refresh"></i> Actualizar Datos</button>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="updPassword" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-refresh"></i> Actualizar Contraseña</h4>
							<small>Cambiar Contraseña de Usuario</small>
						</div>
						<div class="modal-body">
							<div class="form-horizontal form-label-left" >
								<div class="form-group">  
								  <label class="control-label col-md-5 col-sm-5 col-xs-12" > Contraseña Anterior:
								  </label>
								  <div class="col-md-7 col-sm-7 col-xs-12">
									<input type="password"  id="pwdant" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-5 col-sm-5 col-xs-12" > Contraseña Nueva:
								  </label>
								  <div class="col-md-7 col-sm-7 col-xs-12">
									<input type="password"  id="pwdnue" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-5 col-sm-5 col-xs-12" > Repetir Contraseña:
								  </label>
								  <div class="col-md-7 col-sm-7 col-xs-12">
									<input type="password"  id="pwdnue1" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button onclick="updPwdUser();" class="btn btn-success btn-sm" ><i class="fa fa-refresh"></i> Actualizar Datos</button>
								</div>												
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="newDir" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-map-marker"></i> Nueva Direccion</h4>
							<small>Registro de una nueva direccion.</small>
						</div>
						<div class="modal-body">
							<div class="row">
								<div class="col-md-6">
									<div class="ibox ">
										<div class="ibox-title">
											<h5>Mapa</h5>
										</div>
										<div class="ibox-content  ">
											<center>
												<div id="myMap" style="height: 400px"></div>
												<h6><p> <i class="fa fa-info text-navy"></i> Mueva el marcador y seleccione su direccion exacta</p></h6>
											</center>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="ibox ">
										<div class="ibox-title">
											<h5>Datos Direccion</h5>
										</div>
										<div class="ibox-content ">
											<div class="form-group row">
												<center>
													<h6><p> <i class="fa fa-info text-navy"></i> La etiqueta es la informacion por la cual reconocera su direccion.</p></h6>
												</center>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Etiqueta:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <input type="text" id="etimap" class="form-control input-sm"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-tag text-navy"></i></button></span>
														</div>
													</div>
												</div>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Direccion:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <input type="text" id="dirmap" class="form-control input-sm"  ><span class="input-group-btn"> <button type="button" disabled style="width:35px;" class="btn btn-default btn-sm"><i class="fa fa-map-marker text-navy"></i></button></span>
														</div>
													</div>
												</div>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Pais:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <input type="text" id="paismap" value="BOLIVIA" class="form-control input-sm"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-bank text-navy"></i></button></span>
														</div>
													</div>
												</div>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Ciudad:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <select class="form-control" style="width: 100%;" id="ciumap"><option value="COCHABAMBA">COCHABAMBA</option><option value="LA PAZ">LA PAZ</option><option value="SANTA CRUZ">SANTA CRUZ</option></select><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-building text-navy"></i></button></span>
														</div>
													</div>
												</div>
												<div class="row" style="margin:15px" >
													<label class="control-label col-md-3 col-sm-3 col-xs-12" > Localidad:
													</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<div class="input-group">
														  <input type="text" id="locmap" value="CERCADO" class="form-control input-sm"  ><span class="input-group-btn"> <button type="button" style="width:35px;" disabled class="btn btn-default btn-sm"><i class="fa fa-crosshairs text-navy"></i></button></span>
														</div>
													</div>
												</div>	
												<input type="hidden"  id="latmapa" class="form-control">
												<input type="hidden"  id="lngmapa" class="form-control">
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
													<button onclick="newDireccion();" class="btn btn-success btn-sm" ><i class="fa fa-check"></i> Insertar Datos</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>	
						</div>
					</div>
				</div>
			</div>
			<div class="footer">
				<?php
					include('includes/footer.inc');
				?>
			</div>
			
        </div>
    </div>	
    <?php
	include('includes/pie.inc');
	?>
	<script>		
		var ids = "<?php echo $ids;?>";
		var idu = "<?php echo $idu;?>";
		var idr = "<?php echo $idr;?>";
		var aps = "<?php echo $aps;?>";
		var nom = "<?php echo $nom;?>";
		var rol = "<?php echo $rol;?>";
		var ico = "<?php echo $ico;?>";
		var emp = "<?php echo $emp;?>";
		var foto = "<?php echo $foto;?>";
		var logo = "<?php echo $logo;?>";
		var nomSuc = "<?php echo $suc;?>";
		var lat=""; var lng="";
		
		function initializer() {
			document.getElementById('nomSucursal').innerHTML = nomSuc;
			document.getElementById('nomUser').innerHTML = nom+' '+aps;
			document.getElementById('rolUser').innerHTML = rol;
			document.getElementById("fotousr").src="img/usuario/"+foto+"";
			cargarDatosWeb();cargarDatosUser();
		}
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(mostrarUbicacion);
		}

		function mostrarUbicacion (ubicacion) {
			lng = ubicacion.coords.longitude;
			lat = ubicacion.coords.latitude;
			$("#latmapa").val(lat);
			$("#lngmapa").val(lng);
		}
		
		function modalDireccion(){
			$("#newDir").modal("show");
			mapboxgl.accessToken = 'pk.eyJ1IjoiYW5kcmVldXNkYiIsImEiOiJja2VrcTJ2M2YwZGRoMzFxeG1xYmtvcHJzIn0.eWdITbhyklGEVNiqeqphVw';
			var map = new mapboxgl.Map({
			container: 'myMap',
			style: 'mapbox://styles/mapbox/streets-v11',
			center: [lng, lat],
			zoom: 15
			});
			 
			var marker = new mapboxgl.Marker({
			draggable: true
			})
			.setLngLat([lng, lat])
			.addTo(map);
			 
			marker.on("dragend", function(e) {
				var lngLat = marker.getLngLat();
				$("#latmapa").val(lngLat.lat);
				$("#lngmapa").val(lngLat.lng);
			});	
		}
		function newDireccion(){
			Empresa.showSpinner();
			var latitud = document.getElementById("latmapa").value;
			var longitud = document.getElementById("lngmapa").value;
			var etiqueta = document.getElementById("etimap").value;
			var direccion = document.getElementById("dirmap").value;
			var pais = document.getElementById("paismap").value;
			var ciudad = document.getElementById("ciumap").value;
			var localidad = document.getElementById("locmap").value;
			if(etiqueta === ""){
            $('#etimap').val('').focus();
				Empresa.notificationWarning(" El campo etiqueta es obligatorio .");
				return;
			}
			if(direccion === ""){
				$('#dirmap').val('').focus();
				Empresa.notificationWarning(" El campo direccion es obligatorio .");
				return;
			}
			var funcion = "newDireccion";
			var body = { funcion: funcion, latitud: latitud , longitud: longitud , etiqueta: etiqueta, direccion: direccion, pais: pais, ciudad: ciudad, localidad: localidad, iduser: idu};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					$("#newDir").modal("hide");
					$('#latmap').val('');$('#lngmap').val('');$('#dirmap').val('');$('#etimap').val('');
					cargarDireccion();
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se ingreso correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se ingreso el nuevo registro intente de nuevo por favor");
				}
			});
		}
		function cargarDireccion(){
			$('#tabdir').tab('show');
			var diruser = $("#diruser");  
			diruser.hide(); 
			diruser.empty();
			var funcion = "listarDireccion";
			var body = { funcion: funcion, iduser: idu};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					var direcciones = respuesta.direcciones.data;					
					for (var i = 0; i < direcciones.length; i++) {
						var paneldir = '<div class="row"><div class="col-md-5"><div id="dirsmap'+i+'" style="height:250px; margin:20px"></div> </div><div class="col-md-4" style="height:250px; margin:20px"><p><span class="label label-primary"> <i class="fa fa-tag"></i> '+direcciones[i].ETIQUETA+' </span></p><br><p><i class="fa fa-map-marker"></i> '+direcciones[i].DIRECCION+' </p><br><p><i class="fa fa-crosshairs"></i> '+direcciones[i].LOCALIDAD+' </p><br><p><i class="fa fa-building"></i> '+direcciones[i].CIUDAD+' - '+direcciones[i].PAIS+'</p></div><div class="col-md-2" style="height:250px; margin:20px"><button class="btn btn-danger btn-xs" title="Nueva Direccion" onclick = "deleteDireccion( '+direcciones[i].ID_DIRECCION+');"><i class="fa fa-trash-o" aria-hidden="true"></i></button></div></div><hr>';	
						diruser.append(paneldir);
						diruser.show();
					}
					for (var i = 0; i < direcciones.length; i++) {
						mapboxgl.accessToken = 'pk.eyJ1IjoiYW5kcmVldXNkYiIsImEiOiJja2VrcTJ2M2YwZGRoMzFxeG1xYmtvcHJzIn0.eWdITbhyklGEVNiqeqphVw';
						var map = new mapboxgl.Map({
						container: 'dirsmap'+i+'',
						style: 'mapbox://styles/mapbox/streets-v11',
						center: [direcciones[i].LONGITUD, direcciones[i].LATITUD],
						zoom: 14
						});
						 
						var marker = new mapboxgl.Marker()
						.setLngLat([direcciones[i].LONGITUD, direcciones[i].LATITUD])
						.addTo(map);
					}
				}
			});
		}
		function deleteDireccion(id){
			swal({
				title: "Eliminar Item",
				text: "Desea eliminar este Item",
				type: "warning",
				showCancelButton: true,
				confirmButtonClass: "btn-danger",
				confirmButtonText: "Eliminar",
				cancelButtonText: "Cancelar",
				closeOnConfirm: false,
				closeOnCancel: false
			},
			function(isConfirm) {
				if (isConfirm) {
					swal.close();
					var funcion = "deleteDireccion";
					var body = { funcion: funcion , id: id};
					Empresa.rest({
						verbo: 'POST',
						url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
						data: body,
						funcionExito: function (respuesta) {
							cargarDireccion();
							Empresa.notificationSuccess("Se elimino correctamente el registro.");
						}
					});	
				} else {
					swal.close();	
				}
			});
		}
		function cargarDatosUser(){
			Empresa.showSpinner();
			var funcion = "editUser";
			var body = { funcion: funcion , iduser: idu};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					var user = respuesta.user;
					Empresa.hideSpinner();
					$("#updid").val(user.ID_USER);
					$("#updusr").val(user.USUARIO);
					$("#ci").val(user.CI);
					$("#noms").val(user.NOMBRES);
					$("#aps").val(user.APELLIDOS);
					$("#email").val(user.EMAIL);
					$("#telf").val(user.TELEFONO);
					$("#cel").val(user.CELULAR);
					$("#fecnac").val(user.FECHA_NAC);
					$("#selectgen").val(user.GENERO);
					$("#imgport").attr("src","img/usuario/"+user.FOTO+"");
					$("#imgmodal").attr("src","img/usuario/"+user.FOTO+"");
					document.getElementById('nomusr').innerHTML = user.USUARIO;
					document.getElementById('rolusr').innerHTML = rol;
				}
			});
		}
		function vistaPreviaFoto(input) {
			$('#fotoAnt').hide(); 
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('#fotoForm + div').remove();
					$('#fotoForm').after('<div class="col-md-4 col-sm-4 col-xs-12"><center><img alt="image" class="img-thumbnail" width="100px" src="'+e.target.result+'"></center></div>');
				};
				reader.readAsDataURL(input.files[0]);
			}
		}
		function updFotoUser(){	
			Empresa.showSpinner();
			var inputFileImage = document.getElementById("newFoto");
			var iduser = document.getElementById("updid").value;
			var file = inputFileImage.files[0];
			var archivo = file.name;
			var data = new FormData();
			var funcion = "updFotoUser";
			data.append('newFoto',file);data.append('iduser',iduser);data.append('funcion',funcion);
			Empresa.restImg({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesArchivosUsuarios.php"),  
				data: data, 
				funcionExito: function (respuesta) {
					Empresa.hideSpinner();
					var subido = respuesta.subido; var msj = respuesta.mensaje;
					if(subido==1){
						$("#updFoto").modal("hide");
						$("#newFoto").val("");
						Empresa.notificationSuccess(msj);
						cargarDatosUser();
					}else{
						Empresa.notificationError(msj);
					}
					
				}
			});			
		}
		function habilitarDatos() {
			$('#btneditar').hide(); $('#btnguardar').show();
			Empresa.habilitarCampos("edit");
		}
		function guardarDatos() {
			Empresa.showSpinner();
			$('#btnguardar').hide(); $('#btneditar').show();
			var iduser = document.getElementById("updid").value;
			var user = document.getElementById("updusr").value;
			var ci = document.getElementById("ci").value;
			var noms = document.getElementById("noms").value;
			var aps = document.getElementById("aps").value;
			var genero = document.getElementById("selectgen").value;
			var fecnac = document.getElementById("fecnac").value;
			var email = document.getElementById("email").value;
			var telf = document.getElementById("telf").value;
			var cel = document.getElementById("cel").value;
			var funcion = "updUser";
			var body = { funcion: funcion, iduser: iduser, user: user , ci: ci, noms: noms , aps: aps, email: email , telf: telf , cel: cel, fecnac: fecnac, genero: genero};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					cargarDatosUser();
					Empresa.deshabilitarCampos("edit");
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se actualizo el registro intente de nuevo por favor");
				}
			});
		}
		function updPwdUser(){
			Empresa.showSpinner();
			var iduser = document.getElementById("updid").value;
			var apwd = document.getElementById("pwdant").value;
			var pwd1 = document.getElementById("pwdnue").value; 
			var pwd2 = document.getElementById("pwdnue1").value;
			if(pwd1 != pwd2){
				$('#pwdnue1').focus();
				Empresa.notificationError("Las contraseñas no coinciden.");
				return;
			}
			var funcion = "updPwdUser";
			var body = { funcion: funcion, iduser: iduser, user: user , apwd: apwd, npwd: pwd1};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					var valor = respuesta.valor;
					$("#updPassword").modal("hide");
					Empresa.hideSpinner();
					if(valor==1){
						Empresa.notificationSuccess("Contraseña Actualizada correctamente.");
					}else{
						Empresa.notificationError("Lo sentimos, tu anterior contraseña no es correcta.");
					}
				}
			});
		}	
		this.initializer();		
	</script>
</body>
</html>

<?php

function _log($msg, $filename = "./logger.log", $solodesarrollo=false)
{
    $modeDesrrollo = false;
    if($solodesarrollo && !$modeDesrrollo ) return;
    $fd = fopen($filename, "a");
    $str = "[" . date("Y/m/d h:i:s", mktime()) . "] " . $msg;
    fwrite($fd, $str . "\n");
    fclose($fd);
}



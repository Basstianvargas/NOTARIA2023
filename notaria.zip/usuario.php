<!DOCTYPE html>
<html>
<head>
    <?php
	include('includes/cabecera.inc');
	?>
</head>
<body class="pace-done mini-navbar skin-3 skin-2">
    <div id="wrapper">
		<?php
			include('includes/menu_izq.inc');
		?>
        <div id="page-wrapper" class="gray-bg">
			<div class="row border-bottom">
				<?php
					include('includes/menu_top.inc');
				?>
			</div>
			<div class="row wrapper border-bottom white-bg page-heading">
				<div class="col-lg-12">
					<br>
					<ol class="breadcrumb">
						<li>
							<a href="home">Inicio</a>
						</li>
						<li class="active">
							<strong> Usuarios Empresa </strong>
						</li>
					</ol>
				</div>
			</div>
			<div class="wrapper wrapper-content ">
				<div class="row">
					<div class="col-lg-12">
						<div class="ibox float-e-margins">
							<div class="ibox-title">
								<h5>Sucursal : <b id='nomSucursal'></b></h5>
								<div class="ibox-tools">
								</div>
							</div>	
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12" >
						<div class="ibox float-e-margins" >
							<div class="ibox-title" >
							  <h5> Listado <small class="m-l-sm" > (Usuarios)  </small></h5>
							  <div class="ibox-tools">
								<button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#newUser">
									<i class="fa fa-plus" aria-hidden="true"></i>
								</button>
							  </div>
							</div>
						</div>
						<div class="ibox float-e-margins" style='margin-top:-15px;'>
							<div class="ibox-content">
							  <div id="contenedortablaprincipal" class="ibox ">
								<div id="toogle-columns"></div>
								<div class="ibox table-responsive" style="font-size:10px; max-height: 500px; ">
									<table class="table table-striped table-bordered table-hover lisUser" style="font-size:10px;" >
									</table>
								</div>
							  </div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<div class="modal inmodal" id="newUser" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-plus"></i> Nuevo Usuario</h4>
							<small>Registro de usuarios del sistema</small>
						</div>
						<div class="modal-body">
							<div class="form-horizontal form-label-left" >
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Sucursal :
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<select class="select2_demo_1 form-control"  id="selectSucursal" style="width: 100%;"  required></select>
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Rol :
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<select class="select2_demo_2 form-control"  id="selectRol" style="width: 100%;"  required></select>
								  </div>
								</div><hr>	
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Usuario:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="usr" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > CI:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="ci" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Nombres:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="noms" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Apellidos:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="aps" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Genero:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<select class="form-control col-md-7 col-xs-12" id="gen">
										<option value="MASCULINO">MASCULINO</option>
										<option value="FEMENINO">FEMENINO</option>
									</select>
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Fecha Nacimiento:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="date"  id="fecnac" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Email:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="email" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Telefono:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="telf" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Celular:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="cel" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button onclick="newUser();" class="btn btn-success btn-sm" ><i class="fa fa-check"></i> Insertar Datos</button>
								</div>												
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="updUser" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-edit"></i> Editar Usuario</h4>
							<small>Editar usuarios del sistema</small>
						</div>
						<div class="modal-body">
							<div class="form-horizontal form-label-left" >
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Usuario:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="hidden"  id="updid" class="form-control col-md-7 col-xs-12">
									<input type="text"  id="updusr" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > CI:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="updci" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Nombres:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="updnoms" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Apellidos:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="updaps" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Genero:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<select class="select2_demo_5 form-control" style="width: 100%;" id="updgen">
										<option value="MASCULINO">MASCULINO</option>
										<option value="FEMENINO">FEMENINO</option>
									</select>
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Fecha Nacimiento:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="date"  id="updfecnac" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Email:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="updemail" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Telefono:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="updtelf" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Celular:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="updcel" class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button onclick="updUser();" class="btn btn-success btn-sm" ><i class="fa fa-refresh"></i> Actualizar Datos</button>
								</div>												
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="newRolUser" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-plus"></i> Asignar Rol-Usuario</h4>
							<small>Asignar Rol a un Usuario del sistema</small>
						</div>
						<div class="modal-body">
							<div class="form-horizontal form-label-left">	
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Usuario:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="rolusr" readonly class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Rol :
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<select class="select2_demo_3 form-control"  id="selectRol1" style="width: 100%;"  required></select>
								  </div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button onclick="newRolUser();" class="btn btn-success btn-sm" ><i class="fa fa-check"></i> Insertar Datos</button>
								</div>												
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="newSucUser" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-plus"></i> Asignar Sucursal-Usuario</h4>
							<small>Asignar Sucursal a un Usuario del sistema</small>
						</div>
						<div class="modal-body">
							<div class="form-horizontal form-label-left"> 	
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Usuario:
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<input type="text"  id="sucusr" readonly class="form-control col-md-7 col-xs-12">
								  </div>
								</div>
								<div class="form-group">  
								  <label class="control-label col-md-3 col-sm-3 col-xs-12" > Sucursal :
								  </label>
								  <div class="col-md-9 col-sm-9 col-xs-12">
									<select class="select2_demo_4 form-control"  id="selectSucursal1" style="width: 100%;"  required></select>
								  </div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									<button onclick="newSucUser();" class="btn btn-success btn-sm" ><i class="fa fa-check"></i> Insertar Datos</button>
								</div>												
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal inmodal" id="verDir" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content animated bounceInRight">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title"> <i class="fa fa-map-marker"></i> Direccion </h4>
							<small>Muestra el mapa de direccion del usuario.</small>
						</div>
						<div class="modal-body">
							<div class="row">
								<div class="col-md-6">
									<div class="ibox ">
										<div class="ibox-title">
											<h5>Mapa</h5>
										</div>
										<div class="ibox-content  ">
											<div id="myMap" style="height: 250px;" ></div>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="ibox ">
										<div class="ibox-title">
											<h5>Datos Direccion</h5>
										</div>
										<div class="ibox-content ">
											<p><span class="label label-primary"> <i class="fa fa-tag"></i><span id="etid"> </span></p><br>
											<p><i class="fa fa-map-marker"></i> <span id="dird"> </span></p><br>
											<p><i class="fa fa-crosshairs"></i> <span id="locd"> </span></p><br>
											<p><i class="fa fa-building"></i> <span id="ciud"> </span></p>
										</div>	
									</div>
								</div>
							</div>	
						</div>
					</div>
				</div>
			</div>
			<div class="footer">
				<?php
					include('includes/footer.inc');
				?>
			</div>
        </div>	
    </div>
    <?php
	include('includes/pie.inc');
	?>
	<script>
		var ids = "<?php echo $ids;?>";
		var idu = "<?php echo $idu;?>";
		var idr = "<?php echo $idr;?>";
		var aps = "<?php echo $aps;?>";
		var nom = "<?php echo $nom;?>";
		var rol = "<?php echo $rol;?>";
		var ico = "<?php echo $ico;?>";
		var emp = "<?php echo $emp;?>";
		var foto = "<?php echo $foto;?>";
		var logo = "<?php echo $logo;?>";
		var nomSuc = "<?php echo $suc;?>";
		var lisUser = [];
	
		function initializer() {
			cargarDatosWeb();
			document.getElementById('nomSucursal').innerHTML = nomSuc;
			document.getElementById('nomUser').innerHTML = nom+' '+aps;
			document.getElementById('rolUser').innerHTML = rol;
			document.getElementById("fotousr").src="img/usuario/"+foto+"";
			document.getElementById('nomUser').innerHTML = nom+' '+aps;
			document.getElementById('rolUser').innerHTML = rol;
			selectSucursal(); selectRol(); selectSucursal1(); selectRol1();
			headerUsuarios(); cargarUsuarios(); 
		}
		
		// -------------------------- Cargar Selects ---------------------------- //
		function selectSucursal(){
		    Empresa.actualizarSelect({
			selector: "#selectSucursal",
			sql: "select id_sucursal as id, concat(sucursal) as etiqueta from sucursal",
			callback: function (data) {
				$(".select2_demo_1").select2();
			}
		   });
		}
		function selectRol(){
		    Empresa.actualizarSelect({
			selector: "#selectRol",
			sql: "select id_rol as id, concat(rol) as etiqueta from rol where id_rol<>'1'",
			callback: function (data) {
				$(".select2_demo_2").select2();
			}
		   });
		}
		function selectRol1(){
		    Empresa.actualizarSelect({
			selector: "#selectRol1",
			sql: "select id_rol as id, concat(rol) as etiqueta from rol where id_rol<>'1'",
			callback: function (data) {
				$(".select2_demo_3").select2();
			}
		   });
		}
		function selectSucursal1(){
		    Empresa.actualizarSelect({
			selector: "#selectSucursal1",
			sql: "select id_sucursal as id, concat(sucursal) as etiqueta from sucursal",
			callback: function (data) {
				$(".select2_demo_4").select2();
			}
		   });
		}
		// -------------------------- Controles Tabla Rol ---------------------------- //
		function headerUsuarios() {
			var columnsName = [
				{title: "#"},
				{title: " "},
				{title: " Usuario"},
				{title: " Rol(es)"},
				{title: " Sucursal(es)"},
				{title: " Nombres"},
				{title: " Apellidos"},
				{title: " CI "},
				{title: " Telefono"},
				{title: " Email"},
				{title: " Direccion"},
				{title: " Estado"},
				{title: " "}
			];
			var columnsLinks = Empresa.createToogleColumns(columnsName);
			$("#toogle-columns").append(columnsLinks);
			Empresa.inicializarTablaDeDatos({
				selector: ".lisUser",
				data: lisUser,
				columnas: columnsName
			});
		}
		function cargarUsuarios() {
			Empresa.showSpinner();
			lisUser = [];
			var body = { funcion: "listarUsuarios"};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					var users = respuesta.users;					
					for (var i = 0; i < users.length; i++) {
						var idrol = users[i].id_rol;
						if(idrol!='1'){
							lisUser.push([
								i+1,
								crearImgDet(users[i].foto),
								users[i].user,
								createDivDatos(users[i].roles,"UserRol"),
								createDivDatos(users[i].sucursales,"UserSuc"),
								users[i].noms,
								users[i].aps,
								users[i].ci,
								users[i].telf,
								users[i].email,
								createDivDir(users[i].direcciones,"Direccion"),
								createButtonEstado(users[i].id_user,users[i].estado,"User"),
								createButtonsEdit(users[i].id_user,users[i].user,"User")
							]);
						}
					}
					Empresa.refrescarTablaDeDatos({
						selector: ".lisUser",
						data: lisUser
					});
					Empresa.hideSpinner();
				},
				funcionError: function (e) {
					Empresa.notificationError("No se cargo correctamente el listado");
					Empresa.hideSpinner();
				}
			});
		}
		function newUser(){
			Empresa.showSpinner();
			var rol = document.getElementById("selectRol").value;
			var sucursal = document.getElementById("selectSucursal").value;
			var user = document.getElementById("usr").value;
			var ci = document.getElementById("ci").value;
			var noms = document.getElementById("noms").value;
			var aps = document.getElementById("aps").value;
			var genero = document.getElementById("gen").value;
			var fecnac = document.getElementById("fecnac").value;
			var email = document.getElementById("email").value;
			var telf = document.getElementById("telf").value;
			var cel = document.getElementById("cel").value;

			// ------------------------ validar usuario letras y numeros --------------------------------
			const regex = /^[a-zA-Z0-9]{4,12}$/;
			if (regex.test(user)) {
			} else {
				$('#usr').focus();
				Empresa.notificationError("El campo usuario solo debe contener letras y numeros minimo 4 caracteres maximo 12.");
				Empresa.hideSpinner();
				return;
			}
			// ------------------------ validar que no este vacio los campos  --------------------------------
			if(rol === ""){
				$('#selectRol').focus();
				Empresa.notificationError("Este campo es obligatorio");
				Empresa.hideSpinner();
				return;
			}
			if(sucursal === ""){
				$('#selectSucursal').focus();
				Empresa.notificationError("Este campo es obligatorio");
				Empresa.hideSpinner();
				return;
			}
			if(user === ""){
				$('#usr').focus();
				Empresa.notificationError("Este campo es obligatorio");
				Empresa.hideSpinner();
				return;
			}
			if(ci === ""){
				$('#ci').focus();
				Empresa.notificationError("Este campo es obligatorio");
				Empresa.hideSpinner();
				return;
			}
			if(noms === ""){
				$('#selectRol').focus();
				Empresa.notificationError("Este campo es obligatorio");
				Empresa.hideSpinner();
				return;
			}
			if(noms === ""){
				$('#noms').focus();
				Empresa.notificationError("Este campo es obligatorio");
				Empresa.hideSpinner();
				return;
			}
			if(aps === ""){
				$('#aps').focus();
				Empresa.notificationError("Este campo es obligatorio");
				Empresa.hideSpinner();
				return;
			}
			// ------------------------ validar campo tipo Email  --------------------------------
			const regex1 = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
			if (regex1.test(email)) {
			} else {
				$('#email').focus();
				Empresa.notificationError("No cumple el formato correcto de un campo tipo email.");
				Empresa.hideSpinner();
				return;
			}
			var funcion = "newUser";
			var body = { funcion: funcion, rol: rol , sucursal: sucursal, user: user , ci: ci, noms: noms , aps: aps, email: email , telf: telf, cel: cel, fecnac: fecnac, genero: genero };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					var valor = respuesta.valor;
					$("#newUser").modal("hide");
					cargarUsuarios(); 
					Empresa.hideSpinner();
					if(valor==0){
						Empresa.notificationSuccess("Se ingreso correctamente el registro.");
					}
					if(valor==1){
						Empresa.notificationError("Este usuario ya tiene una cuenta en el sistema");
					}
				}
			});
		}
		function modalEditUser(id){
			Empresa.showSpinner();
			var funcion = "editUser";
			var body = { funcion: funcion , iduser: id};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					var user = respuesta.user;
					Empresa.hideSpinner();
					$("#updUser").modal("show");
					$("#updid").val(user.ID_USER);
					$("#updci").val(user.CI);
					$("#updusr").val(user.USUARIO);
					$("#updnoms").val(user.NOMBRES);
					$("#updaps").val(user.APELLIDOS);
					$("#updemail").val(user.EMAIL);
					$("#updtelf").val(user.TELEFONO);
					$("#updcel").val(user.CELULAR);
					$("#updfecnac").val(user.FECHA_NAC);
					
					$("#updgen").val(user.GENERO);
					$(".select2_demo_5").select2();
				}
			});
		}
		function updUser(){
			Empresa.showSpinner();
			var iduser = document.getElementById("updid").value;
			var user = document.getElementById("updusr").value;
			var ci = document.getElementById("updci").value;
			var noms = document.getElementById("updnoms").value;
			var aps = document.getElementById("updaps").value;
			var genero = document.getElementById("updgen").value;
			var fecnac = document.getElementById("updfecnac").value;
			var email = document.getElementById("updemail").value;
			var telf = document.getElementById("updtelf").value;
			var cel = document.getElementById("updcel").value;
			var funcion = "updUser";
			var body = { funcion: funcion, iduser: iduser, user: user , ci: ci, noms: noms , aps: aps, email: email , telf: telf , cel: cel, fecnac: fecnac, genero: genero};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					$("#updUser").modal("hide");
					cargarUsuarios();
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se actualizo el registro intente de nuevo por favor");
				}
			});
		}
		function verDireccion(id){
			Empresa.showSpinner();
			var funcion = "verDireccion";
			var body = { funcion: funcion , id: id};
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					var direccion = respuesta.direccion;
					Empresa.hideSpinner();
					$("#verDir").modal("show");
					let myMap = L.map('myMap').setView([direccion.LATITUD, direccion.LONGITUD], 15)

					L.tileLayer(`https://maps.wikimedia.org/osm-intl/{z}/{x}/{y}.png`, {
						maxZoom: 18,
					}).addTo(myMap);
					//crear un marcador draggable
					var marker = L.marker([direccion.LATITUD, direccion.LONGITUD]).addTo(myMap);
					myMap.invalidateSize();
					
					document.getElementById('dird').innerHTML = direccion.DIRECCION;
					document.getElementById('etid').innerHTML = direccion.ETIQUETA;
					document.getElementById('ciud').innerHTML = direccion.CIUDAD+' - '+direccion.PAIS;
					document.getElementById('locd').innerHTML = direccion.LOCALIDAD;
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
				}
			});
			
		}
		// -------------------------- Funciones para eliminar Roles-Sucursales ---------------------------- //
		function deleteUserRol(id){
			swal({
				title: "Eliminar Item",
				text: "Desea eliminar este Rol",
				type: "warning",
				showCancelButton: true,
				confirmButtonClass: "btn-danger",
				confirmButtonText: "Eliminar",
				cancelButtonText: "Cancelar",
				closeOnConfirm: false,
				closeOnCancel: false
			},
			function(isConfirm) {
				if (isConfirm) {
					swal.close();
					var funcion = "deleteUserRol";
					var body = { funcion: funcion , id: id};
					Empresa.rest({
						verbo: 'POST',
						url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
						data: body,
						funcionExito: function (respuesta) {
							Empresa.notificationSuccess("Se elimino correctamente el registro.");
						}
					});	
				} else {
					swal.close();	
				}
			});
		}
		function deleteUserSuc(id){
			swal({
				title: "Eliminar Item",
				text: "Desea eliminar esta Sucursal",
				type: "warning",
				showCancelButton: true,
				confirmButtonClass: "btn-danger",
				confirmButtonText: "Eliminar",
				cancelButtonText: "Cancelar",
				closeOnConfirm: false,
				closeOnCancel: false
			},
			function(isConfirm) {
				if (isConfirm) {
					swal.close();
					var funcion = "deleteUserSuc";
					var body = { funcion: funcion , id: id};
					Empresa.rest({
						verbo: 'POST',
						url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
						data: body,
						funcionExito: function (respuesta) {
							Empresa.notificationSuccess("Se elimino correctamente el registro.");
						}
					});	
				} else {
					swal.close();	
				}
			});
		}
		// -------------------------- Funciones para insertar Roles-Sucursales ---------------------------- //
		function newRolUser(){
			Empresa.showSpinner();
			var iduser = document.getElementById("updid").value;
			var rol = document.getElementById("selectRol1").value;
			var funcion = "newRolUser";
			var body = { funcion: funcion, iduser: iduser , rol: rol  };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					$("#newRolUser").modal("hide");
					cargarUsuarios();
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se ingreso correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se ingreso el nuevo registro intente de nuevo por favor");
				}
			});
		}
		
		function newSucUser(){
			Empresa.showSpinner();
			var iduser = document.getElementById("updid").value;
			var sucursal = document.getElementById("selectSucursal1").value;
			var funcion = "newSucUser";
			var body = { funcion: funcion, iduser: iduser , sucursal: sucursal  };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					$("#newSucUser").modal("hide");
					cargarUsuarios();
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se ingreso correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se ingreso el nuevo registro intente de nuevo por favor");
				}
			});
		}
		// -------------------------- Boton para Cambiar Estado ---------------------------- //
		function cambiarEstadoUser(id,estado){
			Empresa.showSpinner();
			var funcion = "cambiarEstadoUser";
			var body = { funcion: funcion, iduser: id, estado: estado  };
			Empresa.rest({
				verbo: 'POST',
				url: Empresa.armarUrl("/api/usuario/funcionesUsuarios.php"),
				data: body,
				funcionExito: function (respuesta) {
					cargarUsuarios();
					Empresa.hideSpinner();
					Empresa.notificationSuccess("Se Actualizo correctamente el registro.");
				},
				funcionError: function (e) {
					Empresa.hideSpinner();
					Empresa.notificationError("No se actualizo el registro intente de nuevo por favor");
				}
			});
		}
		// -------------------------- Boton para Cambiar Estado ---------------------------- //
		
		function createButtonEstado(id,estado,tabla){
			var btns = "";	var estado = estado.charAt(0); $("#updid").val(id);
			if(estado=='A'){
				btns = "<button class='btn btn-primary btn-xs' style='font-size:8px'  title='Cambiar Estado' onclick='cambiarEstado"+tabla+"(\"" + id + "\",\"" + estado + "\")'>"+estado+"</button>";
			}else{
				btns = "<button class='btn btn-danger btn-xs' style='font-size:8px'  title='Cambiar Estado' onclick='cambiarEstado"+tabla+"(\"" + id + "\",\"" + estado + "\")'>"+estado+"</button>";
			}
			
			return btns;
		}
		
		// -------------------------- Boton Editar para todas las entidades ---------------------------- //
		
		function createButtonsEdit(id,user,tabla){
			$("#updid").val(id); $("#rolusr").val(user); $("#sucusr").val(user);
			var btns = "";		
			btns = " <button class='btn btn-primary btn-xs' style='font-size:8px'  title='Asignar Sucursal' data-toggle='modal' data-target='#newSucUser' ><i class='fa fa-bank'></i></button> <button class='btn btn-success btn-xs' style='font-size:8px'  title='Asignar Rol' data-toggle='modal' data-target='#newRolUser' ><i class='fa fa-user-circle-o'></i></button> <button class='btn btn-info btn-xs' style='font-size:8px'  title='Editar' onclick='modalEdit"+tabla+"(\"" + id + "\")'><i class='fa fa-edit'></i></button>";
			return btns;
		}
			
		// -------------------------- Div para mostrar Datos ---------------------------- //
		function createDivDatos(datos,tabla){
			var datos = datos.data;
			var divDatos = "";
			for (var i = 0; i < datos.length; i++) {
				divDatos += "<p style='margin:3px; line-height:10px;'><a class='text-navy' title='Eliminar' onclick='delete"+tabla+"(\"" + datos[i].id + "\")' >"+datos[i].item+"</a></p>";
			}
			return divDatos;
		}
		// -------------------------- Div para mostrar Direccion ---------------------------- //
		function createDivDir(datos,tabla){
			var datos = datos.data;
			var divDatos = "";
			for (var i = 0; i < datos.length; i++) {
				if(i%2==0){
					divDatos += "<p style='font-size:8px' ><a class='label label-info' title='ver Direccion' onclick='ver"+tabla+"(\"" + datos[i].id + "\")' >"+datos[i].item+"</a></p>";
				}else{
					divDatos += "<p style='font-size:8px' ><a class='label label-success' title='ver Direccion' onclick='ver"+tabla+"(\"" + datos[i].id + "\")' >"+datos[i].item+"</a></p>";
				}
				
			}
			return divDatos;
		}
		// -------------------------- Objeto para imgenes ---------------------------- //
		function crearImgDet(url,tam,lug) {
			var imgurl = "<img class='img-thumbnail' src='img/usuario/"+url+"'  width='70' id='imageModel' /> ";
			return imgurl;
		}
		
		
		this.initializer();		
	</script>
</body>
</html>
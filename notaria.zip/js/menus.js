
	function salirSistema() {
		var body = { funcion: "logout"};
		Empresa.rest(
		{
			verbo: 'POST',
			url: Empresa.armarUrl("api/usuario/funcionesUsuarios.php"),
			data: body,
			funcionExito: function (respuesta) 
			{
				var sesion = respuesta.sesion;
				if(sesion=='0'){
					window.location="http://localhost/transporte/index";     
				}
			}
		})
	}
	function datosIniciales(){
		document.getElementById('nomSucursal').innerHTML = nomSuc;
		document.getElementById('nomUser').innerHTML = nom+' '+aps;
		document.getElementById('rolUser').innerHTML = rol;
		
	}
	function menuSistema(){
		if(screen.width<600){
			$( "body" ).removeClass("pace-done mini-navbar skin-3");
		}
		var funcion = "menuSistema";
		var divMenu = "";	
		var menuSis = $("#side-menu");
		menuSis.empty();
		divMenu = "<li class='nav-header'><div class='dropdown profile-element'> <span><img alt='image' class='img-thumbail' src='img/usuario/usr.png' width='30px' /></span><a data-toggle='dropdown' class='dropdown-toggle' href='#'><span class='clear'><span class='block m-t-xs'><strong class='font-bold' id='nomUser'></strong></span><span class='text-muted text-xs block' ><span id='rolUser'></span> <b class='caret'></b></span></span></a><ul class='dropdown-menu animated fadeInRight m-t-xs'>'<li><a href='perfil'><i class='fa fa-user'></i> Perfil de Usuario</a></li><li class='divider'></li><li><a onclick='salirSistema();'><i class='fa fa-sign-out'></i> Salir Sistema</a></li></ul></div><div class='logo-element'><img alt='image' class='img-thumbail' src='img/empresa/logo.png' width='50px' /></div></li>";
		var body = { funcion: funcion ,idu: idu };
		Empresa.rest(
		{
			verbo: 'POST',
			url: Empresa.armarUrl("api/configuracion/funcionesConfiguracion.php"),
			data: body,
			funcionExito: function (respuesta) 
			{
				const padre = respuesta.menus;
				var server = location.pathname;
				var arr = server.split("/");
				var url = arr[2];
				if(padre.length>0){
					for (i in padre) {
						
						divMenu += '<li><a> '+padre[i].icono+' <span class="nav-label"> '+padre[i].modulo+' </span> <span class="fa arrow"></span></a><ul class="nav nav-second-level " id="item-menu'+i+'"></ul></li>';	
					}
					menuSis.append(divMenu);
					for (i in padre) {
						var hijo = padre[i].items.data;
						var menuItem = "";	
						var itemMenu = $("#item-menu"+i+"");
						itemMenu.empty();
						for (j in hijo) {
							var ruta = hijo[j].ruta;
							if(url == ruta){
								itemMenu.addClass('in');
								menuItem += '<li class="active"><a href="'+ruta+'" > '+hijo[j].formulario+' </a></li>';
							}else{
								menuItem += '<li><a href="'+ruta+'" > '+hijo[j].formulario+' </a></li>';
							}
								
						}
						itemMenu.append(menuItem);
					}
					
					menuSis.show();						
				}	
			}
		})
		
	}
	function cargarMenu(){
		menuSistema();
		datosIniciales();
	}
window.onload=cargarMenu()
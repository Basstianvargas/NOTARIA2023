	$(document).ready(function () {
		var ancho=$('#page-top').width();
		if(ancho>=769){
			$('.carousel-caption').show();
			$("#inSlider").removeClass("ajustemenu");
			
		}else{
			$('.carousel-caption').hide();
			$("#inSlider").addClass("ajustemenu"); 
		}
		if(ancho<550){$("#inSlider").height(180);}
		if(ancho>=550 && ancho<1024){$("#inSlider").height(280);}
		if(ancho>=1024){$("#inSlider").height(450);}
        $('body').scrollspy({
            target: '#navbar',
            offset: 80
        });

        // Page scrolling feature
        $('a.page-scroll').bind('click', function(event) {
            var link = $(this);
            $('html, body').stop().animate({
                scrollTop: $(link.attr('href')).offset().top - 50
            }, 500);
            event.preventDefault();
            $("#navbar").collapse('hide');
        });
		$('.carousel').carousel({
		  interval: 5000
		})
    });

    var cbpAnimatedHeader = (function() {
        var docElem = document.documentElement,
                header = document.querySelector( '.navbar-default' ),
                didScroll = false,
                changeHeaderOn = 200;
        function init() {
            window.addEventListener( 'scroll', function( event ) {
                if( !didScroll ) {
                    didScroll = true;
                    setTimeout( scrollPage, 250 );
                }
            }, false );
        }
        function scrollPage() {
            var sy = scrollY();
			
            if ( sy >= changeHeaderOn ) {
                $(header).addClass('navbar-scroll');
				$(".nav-link").addClass("colormenu"); 
            }
            else {
                $(header).removeClass('navbar-scroll');	
				$(".nav-link").removeClass("colormenu");
            }
            didScroll = false;
        }
        function scrollY() {
            return window.pageYOffset || docElem.scrollTop;
        }
        init();

    })();

    // Activate WOW.js plugin for animation on scrol
    new WOW().init();

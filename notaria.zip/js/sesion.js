function confirmarCierre() {
//aquí hacemos unbind de todos para que no se vuelvan a ejecutar
      
    //le doy un tiempo a la funcion cerrar sesion para que el usuario tenga un tiempo para confirmar, sino lo hizo en el tiempo se cerrara la sesion automaticamente
    var cerrar = setTimeout(cerrarSesion,20000 );//5 segs de prueba
    alertify.confirm(
        'Cierre de Sesión',
        'Su Sesión Expirara, presione OK para prolongar la Sesión 3 minutos',
        function(){
            //si presiona OK
            clearTimeout(cerrar); //elimino el tiempo a la funcion cerrarSesion
            clearTimeout(temp); //elimino el tiempo a la funcion confirmarCierre 
            alertify.success('Su sesión ha sido prolongada 3 minutos');
           //damos los eventos de nuevo
           bindEvents(420000);
        },
        function(){
            cerrarSesion(); //si presiono Cancel, pues ejecuta la funcion cerrarSesion y posteriormente la cierra.
            $(document).unbind();
        }
    );
}

function cerrarSesion() {
    window.location = "controlador/unlog.php?m=2";
    alertify.error('SESION CERRADA'); //coloco una notificacion para observar el momento en el q se ejecuta
    //NOTA: esto no va solo es de demostracion
}
 
var temp = null;

function bindEvents(milisegundos){
  temp = setTimeout(confirmarCierre, milisegundos);
  // cuando se detecte actividad en cualquier parte de la app
  $( document ).on('click keyup keypress keydown blur change', function(e) {
      
      // borrar el temporizador de la funcion confirmarCierre
      clearTimeout(temp);
      // y volver a iniciarlo con 10segs
      temp = setTimeout(confirmarCierre,milisegundos);
      console.log('actividad detectada1');
  });
}
//primera llamada
 
window.onload=bindEvents(420000);

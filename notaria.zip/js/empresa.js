const Empresa = function () {

    return {
		nombreEmp: 'NOTARIA',
		urlBase: 'http://localhost/notaria/',
        spinner: false,
        dataimg:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAMzklEQVR4Xu3de7AedX3H8ffhEAUDFMMQhQYv5aIB8VqoVEuQQm3rZUa8oYKIDmqhVrHqgOg4sZ2OeO90QqjYUauDElFUEAVvqMOI4ihqFJVCsLXREAVEjpJAcvznu8OPn7vf3eeck+ckJ+/XzDPP2d3v7jmE/ez+9vfbZx+QJEmSJEmSJEmSJEn3mugrmAOvAxb3FUljtrKvgDEFZAOwtK9IGrNB+/6ufQVz5DfAaX1F0hi8Czigr2icNsRL2h6sBab7ihq79BVIOzMDIiUMiJQwIFLCgEgJAyIlDIiUMCBSwoBIiVFuNXluX0GH+8f7TNeXutwDXNJXNBuDbtgKg4fnpTGZAvboK6qsBQ4buu+PcgYBuB14b19R5fXx/o6eOmkUrwEW9RWN0zSwrq+ohTcraltYB9zZV9TCmxWluWJApIQBkRIGREoYEClhQKSEAZESBkRKGBApYUCkhAGREgZEShgQKWFApIQBkRIGREoYEClhQKSEAZESBkRKGBApYUCkhAGREgZEShgQKWFApIQBkRIGREoYEClhQKSEAZESBkRKGBApMepXsC0kZwGPj5+vAd6d1D4VeFkx/R7gG0n9UcDzgL8AlsUXma4HrgcuBT4JbKrW2Qt4f8f2+pwN3Ngy/2TgGcX0B4HLW+pKZ8bf3+bO+Law/wU+B9zcUVf/e60CvtpR2zgbeFwx/TbgO0n9dmehfQXbZfHf1LxelNSeXtV2fWPvQ4AvVbVtr/8D/qZad98B63W9jmj5WxYBP6/qrmupq60Z8Pua1xeAQ1q2Uf97ndJSU9of2Fyts6ZnHb+Cbcwu6NjRhnoK8D3g2L7COKt8HviXvsJZOBH402reYwb+fUMdB1wLPLqvsMc/tXwh5wnAwzrqx2ZnbmLVdo+mz5HAL/qKK38GXAzsXcy7A/gY8M04Oh4IvLA44k4Ab4qm0QfjaHhGy7bfBOwXP2+OJlDtZy3z2uoAXgt8uWNZm38t/j2WAAcBz4omIfH+MeBwYEuynS6LgdNa5k/GN9m+pmXZdml6gTexmtc34pqh1NfE+nq1/JpoNtQmgbdXtb/vOVKuLWqHNimOqX7HRcXPW4Hlybp1E+vQlpqlwE1V3d8Xy0dpYp1R1N0DfLyY/k110CnZxJonTwT+s6+o8OR4NdbHhfH6ltotwBuAC4t5uyVH+5n65+LnHwEvB34b0xNz8PtuiaCXHttRm5mszhCXxRmz2YH36ji7jI0Budc9xc+nRFNkiBOq6fcAGztqG+fEkbxRb2M2HgE8rZg+P47EHynmnRSdArPx/9X0AzvqMs+IJltjNfCTqgn4qpbrk7ExIPcqj7oA57b0NLU5rJr+XEdd6Wbgx8X0MuBPkvpRvDrOEgBTwH/Hz+cVNbtHM2g26q7gn3fUZcoz2Q3AlfHzqmL+AUmv4TZnQO71fuA/iuldo+1+cLIOLUfOtqZVm7puJkfg2j7AS4rpC+PsQbS9v1YsOz2CMqpJ4KXVAWUauCJZp80RwNHF9OqiafWZ6ApvzLZJOGMG5L7OBL5YTO8d/7Oyo3t9oTi06VLXzeSCs/YP1U6/ulpeHpmX9oz9ND4d4VoL/DSuZf4LuF9R85HqjDhE2YT9XfTkNbYA7yum/xxYwTywm/e+tsQI+DVFd+wjgTcm6/w4xkAaK2JHyuxb9Q5tBH6V1A9xv6rZtClGp0t1W/7M2NmzXp3yGqHNpdEJMIoDgGcX01MtHSNLqunXDhiNn1fTC7yb9wHFsuXA7dXy8lW2iZ9WLfvhgKbLudU65dGzNrSb9yXJ35u9/q7azigj6Ss7/pa+bt53DNh2/dpSjdrbzTuPro/mx5CBr89XzYtDo8mxuKP+NOB1xfRW4L0dtUNNjNDrVqs7J2rPjI6Iw+Ieq/Ieshck/51d9pxh1+0u0QExVjaxun02mih1f39tSxwhv1YMMJ4APCGuAb4bo+rLgRfHIF5p5cB7pDLHxUh2Y1UMuHV5QzGwd2zcKvL9jtobYyyFeH9z8W9ycNzk+YqOddu8tLqmOwe4OqlfVfQUnhq//9akft5M70RNrNKHWk73bd2OJ7fccNf3+uiAs/iQJtblRc3mjlH80rHV31E28fpG0ieBq6qa8o5hkibWZDUCf0t1sd/mjGpb58T8sTSxRjG9kwZkt7hoL2u7+uWPBP6nqm17/T7+x0/Qry8gh0YzranJzhyNiWgWNutsLu736gsIwEOj+7ip2QA8qFjeFZDnVPP/rWXbtb3iDNyssz5CNZaA7MxNrB9U7eeu64274ua8DxRNqK6R8m9Fc+D50UtzJPDgWPa7aG5dEWMuQ2+IvLb4fXe1LF9R9e4MuZ5pds5Ti3nHxBnth1UX9FTL+j+LZlXZtHpxXHwTo+xXFct+Ge9HVPPPp98d0alxXDHviUn9vJleYGcQ7djGcgbpa/9KOzUDIiUMiJTYmS/StW3tEjdPNrYCv07qF0UHx35xJ8It0anR1kmwXfIiXaN4Y9Wl+9aOuv3jfrDbWrrDN0XP2gEt643lIn0UBkRDHQXcXezoV8cgYe3p1XhK12tDy9NTDIh2SEtinKTZuW+LgcXaQ2NsqAzCXTHQ+suWkFzJfRkQ7XAm4vb3csfOPg14THzEdjPwemCPYtlfRwDKbZWj9QZEO5xXVzv0BX0rxK08f9mx7KPV9sonLxoQ7VCOiIvqZme+fga3wtc+XQVkWbFsLAGxm1dzoXl4XHNn7qZ4suNUfIakecjcxuperMwjgb8tpn80wwdDjI1nEHW5qDrSv6pYVt6N/JVkG6WlcQYqt3lSVTOWM8goDIja1Le2X1rdxj9qQPaPO637rmXGEhCbWJqNRwPvLKY3xQfMysf5lNchexdPJ7mh5dFHD4unyhxYzPsw8Ep2AJ5BVBvyVQ9dr/rBdctbvq5hdXK/4FjOIN6sqNnYs69goCfEZ/rLr2s4N0JUPqJ17GxiaTZuSj6q3FheHIinim+lah68cHRctzQ9XcTnzod8HHebMyCajRP7CqIZ1FyHXFs9ZO944FNVyKZi/vH8sevG/RhSA6L59MKWM9DilkcjzRuvQaSEZxBtaycX+1n9NJjzBnzrbqnve1fmld282p7YzSvNNwMiJQyIlDAgUsKASAkDIiUMiJQwIFLCgEgJAyIlDIiUMCBSwoBICQMiJQyIlDAgUsKASAkDIiUMiJQwIFLCgEgJAyIlDIiUMCBSwoBICQMiJQyIlDAgUsKASAkDIiUMiJQwIFLCgEgJAyIlDIiUMCBSwoBICQMiJQyIlDAgUsKASAkDIiUMiJQwIFLCgEgJAyIlDIiUMCBSwoBICQMiJQyIlDAgUsKASAkDIiUMiJQwIFLCgEgJAyIlDIiUMCBSYr4Dsj9wEHD/juWLgIcDe3QsXwwcAizpWA6wL/AQYCKpkWZtGljXV9RiQ7xKLwJuim1OA78FVhY78QRwFnBbLN8CfKIIwjLgEmBzsY2vAwcXv+Nw4FvF8puBZ6KFYh1wZ19Ri7WxP8y5uQrIQRGIu2Inv7jY0U+Jmn+M6Ttj+Y0xfVWE56KYvg74ULH827H+PvE7p4FrgcuBrcDdwJEtf6N2PAs2IAAHVjvq+bH9f49m3/qYPjGWLwF+FfP+CpgEnhXvAI+IZVtj3lkxfXVR866Y9wm0EIwlIPN1DXJjNH8ah8b7DdFM2g+4J84eALcCV8bPK6LJdUm8Azwq3tfFvBUxfXFRc1G8H4000HwFpDEBvDPOCj8BPlBcZ9waIWncEu/1BfnjgffFUeHsmLdPtQ7AxmqZ1GvXvoJtaBdgNfDyOHMcC0wBt8fyB0bzqDkDNDt2sxzgScBngT2BM4A1Mf+2ah2KYDXLpDk1l9cgi4ALY5vfAx5ULJuMo/008PSYtxj4Rcw7PuYdH23Qu4GTqu2/JWq/UPSMrYx5l6GFYCzXIKOYy4B8puh+/WIc+dcAF8Tys2PZr4HzgO8WPVKTwFOBTUX37ZridVSMr9wey6+Inq674yL+KS1/o3Y8Czog0x2vpm4yep3qcY5lsfztyTaeGzVPir+3mX8rcCpaKMYSkFFGl5uj9cP7CivNTl82o/btqN0aZ42y7pBocv20mL8YeEDL+gB3xNmFCNrhMVK/Nq5xtDCsi/2j6y6LLmuBw4bu+/N1kb6RYTZ21E4N3Nm3xGCiNCPz3c0rbdcMiJQYVxNrd+D0viJpBHvGcMGo+1V25/cfGXShEmZzkb60r0gas0H7/jjOIGfFGUSaS2+Ns8iZfYXjMtNxEGlbmOk4yEi8SJcSBkRKGBApYUCkhAGREgZEShgQKWFApIQBkRKj3mqyW/FIHWk+7dZXMBcG3bAVBn9MURqTqRl8onAko5xBVvUVSGO2ua9AkiRJkiRJkiRJkiTNpT8APCnV/kEeYJkAAAAASUVORK5CYII=",
		/**
			* funciones de spinner
        */
        showSpinner: function (div) {
			var spin = $('#'+div+''); 
			spin.hide(); spin.empty(); 
			var panelspin = '<div class="sk-spinner sk-spinner-three-bounce" id="spinoff"><br><br><br><br><br><br> <center><h5> Cargando Datos</h5></center><div class="sk-bounce1"></div><div class="sk-bounce2"></div><div class="sk-bounce3"></div></div>';
			spin.append(panelspin);
			spin.show();
            if (!this.spinner) {
                $('#'+div+'').children('.ibox-content').toggleClass('sk-loading');
                this.spinner = true;
            }
        },
        hideSpinner: function (div) {
			var spinoff = $('#spinoff'); 
			spinoff.hide();
            if (this.spinner) {
                $('#'+div+'').children('.ibox-content').toggleClass('sk-loading');
                this.spinner = false;
            }
        },
		/**
			* funciones para manejar fechas 
        */
		formatoImpuestos : function(string){
			var info = string.split('-');
			return info[2] + '/' + info[1] + '/' + info[0];
		},
		fechaActual: function() {
			var f = new Date(); var dia = f.getDate(); var mes = f.getMonth() + 1; var anio = f.getFullYear();
			var fechaActual = anio+"-"+mes+"-"+dia;
			return fechaActual;
		},
		mesActual: function() {
			var f = new Date(); var dia = f.getDate(); var mes = f.getMonth() + 1; var anio = f.getFullYear();
			if (mes.length < 2) mes = '0' + mes;
			return [anio, mes].join('-');
		},
		formatDate: function(date) {
			var d = new Date(date),
				month = '' + (d.getMonth() + 1),
				day = '' + d.getDate(),
				year = d.getFullYear();

			if (month.length < 2) month = '0' + month;
			if (day.length < 2) day = '0' + day;

			return [year, month, day].join('-');
		},		
		diasMes: function(anno , mes){
		    mes = parseInt(mes);
		    anno = parseInt(anno);
		    switch (mes) {
			  case 1 : case 3 : case 5 : case 7 : case 8 : case 10 : case 12 : return 31;
			  case 2 : return (anno % 4 == 0) ? 29 : 28;
		    }
		    return 30;
	    },
		primerDiaDia: function(anno,mes){
			var day ='01';
		    return [anno, mes, day].join('-');
	    },
		fechaLiteral: function() { 
			var meses = new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"); var f=new Date(); var fecha = f.getDate() + " de " + meses[f.getMonth()] + " de " + f.getFullYear(); 
			return fecha; 
		},
		agregarCero: function (i)
        {
        	if (i < 10) 
        	{
            	i = "0" + i;
	        }
	        return i;
        },
        cambiarFechas: function(dato,idIni,idFin)
		{
			var anio = parseInt(dato.split('-')[0]);
			var mes = parseInt(dato.split('-')[1]);
			
			var primerDia = new Date(anio, mes-1, 1).getDate();
			var ultimoDia = new Date(anio, mes, 0).getDate();
			$(idIni).val(anio + "-" + this.agregarCero(mes) + "-" + this.agregarCero(primerDia));
			$(idFin).val(anio + "-" + this.agregarCero(mes) + "-" + this.agregarCero(ultimoDia));
		},
		
        /**
			* funciones para armar la ruta de la consulta BD
        */
        armarUrl: function (rutaRelativa) {
            return this.urlBase + rutaRelativa;
        },
		/**
			* funciones para recuperar la respuesta
        */
        rest: function (setRest) {
            var vi = this;
            if (setRest.funcionError === undefined) {
                setRest.funcionError = function (error) {
                    console.log(error);
                 
                }
            }
            if (setRest.funcionExito === undefined) {
                setRest.funcionExito = function (data) {
                    console.info(data);
                }
            }
            $.ajax({
                type: setRest.verbo,
                url: setRest.url,
                data: JSON.stringify(setRest.data),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: setRest.funcionExito,
                error: function (error) {
                    var dataError;
                    if (error.responseJSON) dataError = error.responseJSON;
                    else if (error.responseText) {
                        dataError = {mensaje: error.responseText};
                    }
                    setRest.funcionError(dataError);
                }
            });
        },
		/**
         * funciones para subir imagenes
        */
        restImg: function (setRest) {
            var vi = this;
            if (setRest.funcionError === undefined) {
                setRest.funcionError = function (error) {
                    console.log(error);
                 
                }
            }
            if (setRest.funcionExito === undefined) {
                setRest.funcionExito = function (data) {
                    console.info(data);
                }
            }
			$.ajax({
				url: setRest.url,      
				type: setRest.verbo,            
				data: setRest.data, 			  
				contentType: false,       
				cache: false,             
				processData:false,        
				success: setRest.funcionExito,
                error: function (error) {
                    var dataError;
                    if (error.responseJSON) dataError = error.responseJSON;
                    else if (error.responseText) {
                        dataError = {mensaje: error.responseText};
                    }
                    setRest.funcionError(dataError);
                }
			});
        },
		/**
			* funciones para realizar la consulta a la BD
        */
        sqlQuery: function ( tipo, retornoPorDefecto, consultaSql, funcionExito, funcionError) {
            if (consultaSql) {
                this.rest({
                    verbo: "POST",
                    url: this.armarUrl("/api/sql/consulta.php"),
                    data: {
                        tipo: tipo,
                        sql: consultaSql
                    },
                    funcionExito: funcionExito,
                    funcionError: funcionError
                });
            } else {
                return retornoPorDefecto;
            }
        },
		/**
			* funcion para devolver una sola fila de la consulta bd01
        */
        sqlOne: function (sqlData) {
            this.sqlQuery("one", {}, sqlData.sql, sqlData.funcionExito, sqlData.funcionError);
        },
		/**
			* funcion para devolver todas las filas de la consulta bd01
        */
        sqlAll: function (sqlData) {
            this.sqlQuery("all", [], sqlData.sql, sqlData.funcionExito, sqlData.funcionError);
        },
		       
		/**        
			* funcion para devolver el tipo de error ocurrido
        */
        error: function (mensaje, callback) {
            alert(mensaje);
            if (callback) {
                callback();
            }
        },
		/**
			* funcion para recuperar checkbox tickeados segun su nombre de clase
        */
        recuperarCheckBox: function (nombreDeClase) {
            var resultado = [];
            $("." + nombreDeClase + ":checked").each(function () {
                resultado.push($(this).val());
            });
            return resultado;
        },
		getDataByIndex: function(listValues, index) {
			var result = [];
			for(var i=0; i < listValues.length; i++){
				var stringSplited = listValues[i].split(';');
				result.push(stringSplited[index]);
			}
			return result;
		},
		
        /**
			* funcion para imprimir un div
        */
   
        impDiv: function (iDiv,url,cabeza,pie)
        {
            
            $(iDiv).printThis({
		        importCSS: true,
		        header: cabeza,
		        footer: pie,
		        importStyle: true,
		        removeScripts: false,
		        canvas: true,
		        copyTagClasses: true,
		        base: url
		    });
        },

        /**
			* arma los select solo con una opcion
        */
        actualizarSelect: function (configuracion) {
            var elementoSelect = $(configuracion.selector);
            elementoSelect.hide();
            elementoSelect.find('option').remove().end().append('<option value=null>Seleccione una opcion</option>').val('');
            Empresa.sqlAll({
                sql: configuracion.sql,
                funcionExito: function (response) {
                    var i;
                    const data = response.data;
                    if (data) {
                        for (i in data) {
                            var optionDinamico = '<option value="' + data[i].id + '">' + data[i].etiqueta + '</option>';
                            elementoSelect.append(optionDinamico);
                        }
                        elementoSelect.show();
                    }
                    if (configuracion.callback) configuracion.callback(data);
                }
            });
        },
		 /**
			* arma los select solo con varias opciones
        */
		multiSelect: function (configuracion) {
            var elementoSelect = $(configuracion.selector);
            elementoSelect.hide();
            elementoSelect.find('option').remove().end().append('<option value="0"> Seleccione todos </option>').val('');
            Empresa.sqlAll({
                sql: configuracion.sql,
                funcionExito: function (response) {
                    var i;
                    const data = response.data;
                    if (data) {
                        for (i in data) {
                            var optionDinamico = '<option value="' + data[i].id + '">' + data[i].etiqueta + '</option>';
                            elementoSelect.append(optionDinamico);
                        }
                        elementoSelect.show();
                    }
                    if (configuracion.callback) configuracion.callback(data);
                }
            });
        }, 
		        
		/**
			* opciones para dar formato a los numeros 
        */     
		roundNumber: function(num, scale) {
			if(!("" + num).includes("e")) {
				return +(Math.round(num + "e+" + scale)  + "e-" + scale);
			} else {
				var arr = ("" + num).split("e");
				var sig = ""
				if(+arr[1] + scale > 0) {
				  sig = "+";
				}
				return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
			}
		},
		dar_formato : function(num){
			var cadena = ""; var aux;
			var cont = 1,m,k;
			if(num<0) aux=1; else aux=0;
			num=num.toString();
			for(m=num.length-1; m>=0; m--){
				cadena = num.charAt(m) + cadena;
				if(cont%3 == 0 && m >aux)  cadena = "." + cadena; else cadena = cadena;
				if(cont== 3) cont = 1; else cont++;
			}
			cadena = cadena.replace(/.,/,',');
			return cadena;

		},
		/**
			* opciones para crear las diferentes notificaciones
        */
		notificationSuccess: function(message) {
            if(message) {
                $(document).ready(function() {
                    setTimeout(function() {
                        toastr.options = {
                            closeButton: true,
                            progressBar: true,
                            showMethod: 'slideDown',
                            timeOut: 4000
                        };
                        toastr.success('Notificacion Sistema', message);
                    }, 100);
                });
            }
        },
        notificationInfo: function(message) {
            if(message) {
                $(document).ready(function() {
                    setTimeout(function() {
                        toastr.options = {
                            closeButton: true,
                            progressBar: true,
                            showMethod: 'slideDown',
                            timeOut: 4000
                        };
                        toastr.info('Notificacion Sistema', message);
                    }, 100);
                });
            }
        },
		notificationWarning: function(message) {
            if(message) {
                $(document).ready(function() {
                    setTimeout(function() {
                        toastr.options = {
                            closeButton: true,
                            progressBar: true,
                            showMethod: 'slideDown',
                            timeOut: 4000
                        };
                        toastr.warning('Notificacion Sistema', message);
                    }, 100);
                });
            }
        },
        notificationError: function(message) {
            if(message) {
                $(document).ready(function() {
                    setTimeout(function() {
                        toastr.options = {
                            closeButton: true,
                            progressBar: true,
                            showMethod: 'slideDown',
                            timeOut: 4000
                        };
                        toastr.error('Notificacion Sistema', message);
                    }, 100);
                });
            }
        },
		/**
			* herramientas para validar formularios
        */
		validarEmail: function (valor) {
		  if (/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(valor)){
		   var res = true;
		  } else {
		   var res = false;
		  }
		  return res;
		},
		validarPassword: function (pwd,pwd1) {
		  if (pwd != "" && pwd1 == pwd ){
			var res = true;
		  } else {
			var res = false;
		  }
		  return res;
		},
		/**
			* herramientas para habilitar y deshabilitar campos de un formulario
        */
		habilitarCampos: function (campo) {
			elementos=document.getElementsByClassName(campo);
			for(var i = 0; i < elementos.length; i++)
			{
				elementos[i].disabled = false;
			}
		},
		deshabilitarCampos: function (campo) {
			elementos=document.getElementsByClassName(campo);
			for(var i = 0; i < elementos.length; i++)
			{
				elementos[i].disabled = true;
			}
		},
		/**
			* herramientas para crear un objeto de imagen | id: id de tabla, url: nombre archivo, tam: tamaño imagen, lug: carpeta donde se aloja
        */
		crearImagenEdit: function(id,url,tam,lug) {
			var imgurl = "<a onclick='editImage"+lug+"(\"" + id + "\",\"" + url + "\")' ><img class='img-thumbnail' src='img/"+lug+"/"+url+"'  width='"+tam+"' id='image' /> </a>";
			return imgurl;
		},
		/**
			* Funcion para crear un checkbox 
        */
		crearCheckBox: function(identificador, valor) {
			return "<div class='checkbox checkbox-success'><input id='chk' class='form-check-input " + identificador + "' type='checkbox' value='" + valor + "'><label for='chk'></label></div>";
		},				
		/**
			* herramientas para crear un objeto de imagen | id: id de tabla, url: nombre archivo, tam: tamaño imagen, lug: carpeta donde se aloja
        */
		createButtonEstado: function(id,estado,tabla,campo){
			var btns = "";	var estado = estado.charAt(0); $("#updid").val(id);
			if(estado=='A'){
				btns = "<button class='btn btn-primary btn-xs' style='font-size:8px'  title='Cambiar Estado' onclick='cambiarEstado"+tabla+"(\"" + id + "\",\"" + estado + "\",\"" + campo + "\")'>"+estado+"</button>";
			}else{
				btns = "<button class='btn btn-danger btn-xs' style='font-size:8px'  title='Cambiar Estado' onclick='cambiarEstado"+tabla+"(\"" + id + "\",\"" + estado + "\",\"" + campo + "\")'>"+estado+"</button>";
			}
			
			return btns;
		},
		/**
			* herramientas para crear un objeto de imagen | id: id de tabla, url: nombre archivo, tam: tamaño imagen, lug: carpeta donde se aloja
        */
		createButtonArchivo: function(id,archivo,tabla,campo){
			var imgurl = "<a class='btn btn-warning btn-xs' style='font-size:8px'  title='Subir Archivo'onclick='editArchivo"+tabla+"(\"" + id + "\",\"" + archivo + "\")' ><i class='fa fa-upload'></i> </a>";
			return imgurl;
		},
		/**
			* herramientas para crear boton editar | id: id de tabla, tabla  de la cual se hace el llamado
        */
		createButtonsEdit: function(id,tabla){
			var btns = "";		
			btns = " <button class='btn btn-info btn-xs' style='font-size:8px'  title='Editar' onclick='modalEdit"+tabla+"(\"" + id + "\")'><i class='fa fa-edit'></i></button>";
			return btns;
		},
		/**
			* herramientas para crear boton editar | id: id de tabla, tabla  de la cual se hace el llamado
        */
		createButtons: function(id,tabla){
			var btns = "";		
			btns = " <button class='btn btn-success btn-xs' style='font-size:8px'  title='Nueva "+tabla+"' onclick='modalNew"+tabla+"(\"" + id + "\")'><i class='fa fa-plus'></i> </button> <button class='btn btn-info btn-xs' style='font-size:8px'  title='Editar' onclick='modalEdit"+tabla+"(\"" + id + "\")'><i class='fa fa-edit'></i></button>";
			return btns;
		},
		
		/**
			* herramientas para crear un div de datos | datos : arreglo de datos a mostrar, tabla  de la cual se hace el llamado
        */
		createDivDatos: function(datos,tabla){
			var datos = datos.data;
			var divDatos = "";
			for (var i = 0; i < datos.length; i++) {
				divDatos += "<p style='margin:3px; line-height:10px; text-align:left;'><a class='text-navy' title='Eliminar' onclick='delete"+tabla+"(\"" + datos[i].id + "\")' >"+datos[i].item+"</a></p>";
			}
			return divDatos;
		},
		/**
			* Funcion para mostrar u ocultar un div
        */
		mostrarOcultarDiv: function(div) {
			var x = document.getElementById(div);
			if (x.style.display === "none") {
				x.style.display = "block";
			} else {
				x.style.display = "none";
			}
		},
		/**
			* Funcion para mostrar u ocultar un div
        */
		PopupCenter: function(pageURL, title,w,h) {
			var left = (screen.width/2)-(w/2);
			var top = (screen.height/2)-(h/2);
			var targetWin = window.open (pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width='+w+', height='+h+', top='+top+', left='+left);
		},
		/**
			* herramientas para crear un objeto de Video |  url: nombre archivo, tam: tamaño video
        */
		crearVistaVideo: function(url,tam) {
			var videourl = "<center><figure><iframe src='http://www.youtube.com/embed/"+url+"' frameborder='0' allowfullscreen='' data-aspectratio='0.8211764705882353' style='width:"+tam+"px; height: "+tam+"px; ' > </iframe> </figure> </center>";
			return videourl;
		},
		/**
			* herramientas para gestion de tablas sin formato 
        */
        inicializarTablaSinFormato: function (configuracion) {
            var tableDynamic = $(configuracion.selector).DataTable({
                destroy: true,
                paging: true,
                retrieve: true,
                autoWidth: false,
                data: configuracion.data,
                columns: configuracion.columnas,
                responsive: true,
                searching: false,
				paging:   false,
				ordering: false,
				info:     false
            });
        },
		/**
			* herramientas para gestion de tablas con formato 
        */
		inicializarTablaformato: function (configuracion) {
            var tableDynamic = $(configuracion.selector).DataTable({
                destroy: true, 
                retrieve: true,
                autoWidth: false,
				columnDefs: [ {
					visible : false,
					targets: '-1'
				} ],
                data: configuracion.data,
                responsive: true,
                searching: false,
				paging:   false,
				ordering: false,
				info:     false
            });
        },
		inicializarTablaDeDatos: function (configuracion) {
            var IMAGE_NOVAMODA = this.dataimg;
            var CODE_BARRE = 'codeBarre';
            var tableDynamic = $(configuracion.selector).DataTable({
                destroy: true,
                paging: true,
                retrieve: true,
                autoWidth: false,
				order: [[ 0, "desc" ]],
                data: configuracion.data,
                columns: configuracion.columnas,
                lengthMenu: [[100, 200, 500, 1000, 2000, 5000, -1], [100, 200, 500, 1000, 2000, 5000, "Todo"]],
                 createdRow: function( row, data, dataIndex ) 
				 {
					if ( data[1] == 'P' ) 
					{        
						$(row).addClass('red');
			 
					}
				},
                footerCallback: function ( row, data, start, end, display ) {
                    var api = this.api(), data;

                    // ******************* COUPLES *****************
                    var pageTotal = api
                            .column(configuracion.columnCouple, { page: 'current'} )
                        .data()
                        .reduce( function (a, b) {
                            return parseFloat(a) + parseFloat(b);
                        }, 0 );
                    // ******************* BOXES *****************
                    var pageTotalBoxes = api
                        .column(configuracion.columnBoxes, { page: 'current'} )
                        .data()
                        .reduce( function (a, b) {
                            return parseFloat(a) + parseFloat(b);
                        }, 0 );
                    // ******************* DOLLARS *****************
                    var pageTotalDollars = api
                        .column(configuracion.columnDollars, { page: 'current'} )
                        .data()
                        .reduce( function (a, b) {
                            return parseFloat(a) + parseFloat(b);
                        }, 0 );
                    $('.idTotalCouplesInventory').text(`${pageTotal.toFixed(2)}`).toLocaleString('es');
                    $('.idTotalBoxsInventory').text(`${pageTotalBoxes.toFixed(2)}`).toLocaleString('es');
                    $('.idTotalDollarsInventory').text(`${pageTotalDollars.toFixed(2)}`).toLocaleString('es');
                },
                pageLength: 100,
                responsive: true,
                searching: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    {
                        extend: 'excel',
                        footer: true,
                        exportOptions: {
                            stripHtml: false,
                            columns: configuracion.columnsToShow
                        },
                        text: '<i class="fa fa-file-excel-o"></i> <E>Excel</E>',
                        message: configuracion.headerTitlePrint
                    },
                    {
                        extend: 'print',
                        footer: false,
                        title: '',
                        exportOptions: {
                            stripHtml: false,
                            columns: ':visible',
                        },
                        text: '<i class="fa fa-print"></i> Imprimir',
                        message: function () {
                            if(configuracion.from == 'codeBarre') {
                                return `<p>Codigo de Barras</p>`
                            } else {
                                return `
								  <div class="col-md-12" style="background:white;">
									<div class="col-xs-6">
										<img src=${IMAGE_NOVAMODA} width="160" height="80" style="border-radius: 10%;">
									</div>
									<div class="col-xs-6">
										<p style="float: center; font-weight: bold">Fecha de Impresion: ${new Date().toDateString()}</p>
									</div>
								  </div>`
                            }
                        }
                    }
                ],
            });
            $('configuracion.selector td').css('white-space','initial');
            $('a.toggle-vis').on( 'click', function (e) {
                e.preventDefault();

                // Get the column API object
                var column = tableDynamic.column( $(this).attr('data-column') );

                // Toggle the visibility
                column.visible( ! column.visible() );
            });
        },
		/**
			* herramientas para el manejo de columnas
        */
		createToogleColumns: function (arrayNameOfColumns) {
			var tagLink = '';
			for(var i = 0; i < arrayNameOfColumns.length; i++) {
				var nameColumn = arrayNameOfColumns[i].title;
				if(i === arrayNameOfColumns.length) {
					tagLink += '<li><a class="toggle-vis btn btn-primary column-visible" data-column="'+i+'"><i class="fa fa-tag"></i>' +nameColumn+ '</a>';
				} else {
					tagLink += '<a class="toggle-vis btn btn-primary btn-xs column-visible" data-column="'+i+'"><i class="fa fa-tag"></i>' +nameColumn+ '</a>';
				}
			}
			return tagLink;
		},
		/**
			* herramientas para recrgar una tabla
        */
		refrescarTablaDeDatos: function (configuracion) {
            var datatable = $(configuracion.selector).DataTable();
            datatable.clear();
            datatable.rows.add(configuracion.data);
            datatable.columns.adjust().draw();
            datatable.draw();
        }
    }
}();
